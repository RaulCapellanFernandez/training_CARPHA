### Questions and bug reports

If you have questions about the usage of a function or would like to report a bug, please follow these steps:

1. Use the search function in GitLab to see if a similar problem has already been reported and/or solved.

2. Rather than including a long script, try to run your code in small blocks to narrow down where the problem is coming from as much as possible.

3. Open an issue tagging the maintainers (@tkariyat), and include a descriptive title and a piece of code to reproduce your problem (if applicable).

### How to contribute

If you would like to add a bugfix, an enhancement or a new functions, follow these steps:

1. Open an issue to ask for help or describe a feature to be integrated

2. Agree with the maintainers (@tkariyat) on the requirements

3. Create a new branch from master with a meaningful name

4. Once the development is finished, open a merge request to merge the branch on master

*Note: Remember to work with multidimensional arrays with named dimensions when possible and use multiApply (https://earth.bsc.es/gitlab/ces/multiApply)*

### Adding a function

To add a new function in this R package, follow these considerations:

* Each function exposed to the users should be in its own separate file in the R folder
* The name of the function should match the name of the file (e.g.: `Function()` included in file **Function.R**
* The documentation should be in roxygen2 format as a header of the function
* Once the function and the documentation are finished, run the command `devtools::document()` in your R terminal to automatically generate the **Function.Rd** file
* When doing the development, please use an R version between R/4.1.2 and R/4.3.x 

### Style guide

* Use `<-` for variable assignment
* Include spaces between operators (e.g. `+`, `-`, `&`), before `{`, and after `for`, `if`, `while`, `,` and `)`.
* When possible, maximum line length should be 100 characters (soft limit of 80 characters).
* Number of indentation spaces is 2, using tabs for indentation is forbidden.
* Double quotes are recommended for strings. When writing quotes within quoted text, use double quotes outside and single quotes inside. E.g.: `“Parameter 'na.rm' is missing.”`
* Self-explanatory names are preferred for variables. Try to be consistent with the variable naming style. Generally: avoid special characters (except underscores) and reserved words (ex: if, for, else, …)
* Remember to include short comments to make the code easier to understand. Comments should be in their own line and they should start with `#` followed by a space. Comments that start with `##` and a space are for details not needed to understand the general procedure but useful to make note of more technical aspects of the code.

#### Examples:

```r
# Proper spacing, indentation spaces and text quotes:
NewFunction <- function(text = "default", uppercase = TRUE) {
  # Check uppercase parameter
  if (!is.logical(uppercase)) {
    stop("Parameter 'uppercase' should be TRUE or FALSE.")
  }
  # Only transform text if needed
  if (uppercase && is.character(text)) {
    text <- toupper(text)
  }
  return(text)
}

# How to format line breaks to avoid long lines:
my_strings <- list(one = "one",
                   two = "two",
                   three = "three",
                   four = "four")
```
