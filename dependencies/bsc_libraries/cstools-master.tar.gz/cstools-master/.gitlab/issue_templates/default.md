(This is a template to report errors and bugs.  Please fill in the relevant information and delete the rest.)

Hi @vagudets and @abatalla,

#### R and packages Version
(Which R version are you using? ex. 4.1.2)  
(Which R packages versions are you using? use sessionInfo(). ex. CSTools_5.0.1, ClimProjDiags_0.3.2, ...)  
(Which machine are you using? WS, Nord3, other...)  

#### Summary
(Bug: Summarize the bug and explain briefly the expected and the current behavior.)  
(New development: Summarize the development needed.)  

#### Example
(Bug: Provide a **minimal reproducible example** and the error message.)  
(New development: Provide an example script or useful piece of code if needed.)  

```
Example:
[ERROR!]: Something went really wrong!
This is the error message that showed up on the terminal.
```

#### Other Relevant Information
(Additional information.)
