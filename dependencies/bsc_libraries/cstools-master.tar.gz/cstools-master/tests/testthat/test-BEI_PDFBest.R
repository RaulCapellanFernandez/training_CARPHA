##############################################
test_that("basic use case", {
  index_obs<- c(2, 3, 0.6)
  dim(index_obs) <- c(time = 3)
  index_hind1 <- c(-2.4, 3.6, -5, -1, -0.5, -0.2, 3,  0.6,  1, 0, -0.5, 2)
  dim(index_hind1) <- c(time = 3, member = 4)
  index_hind2 <- c(4, -10,  1.7,  1, -2,  3,  -2,  -1.5, 2.9)
  dim(index_hind2) <- c(time = 3, member = 3)
  index_fcst1 <- c(-2.6, -0.6,  1.4, -2.4,  8.1)
  dim(index_fcst1) <- c(time = 1, member = 5)
  index_fcst2 <- c(0, 4, -10, 2, -6, 3)
  dim(index_fcst2) <- c(time = 1, member = 6)
  
  result <- array(c(2.574303, 0.8630711),
                  dim=c(time = 1, statistic = 2))
                 
  expect_equal(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = 'ME'), result, tolerance=1e-4)
  
 
  result <- array(c(0.1282658, 0.4108197),
                  dim=c(time = 1, statistic = 2))
  
  expect_equal(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('LMEV', 'ME')), result, 
               tolerance=1e-4)
  
  result <- array(c(0.4923944, 1.73306),
                  dim=c(time = 1, statistic = 2))
  
  expect_equal(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = 'none'), result, 
               tolerance=1e-4)
  
  index_obs<- c(2, 3, 0.6)
  dim(index_obs) <- c(time = 3)
  index_hind1 <- c(-2.4, 3.6, -5, -1, -0.5, -0.2, 3,  0.6,  1, 0, -0.5, 2)
  dim(index_hind1) <- c(time = 3, member = 4)
  index_hind2 <- c(1.194390, 4.298768, -1.222586, 4.419386,  3.972776, 3.998928)
  dim(index_hind2) <- c(time = 3, statistic=2)
  index_fcst1 <- c(-2.6, -0.6,  1.4, -2.4,  8.1)
  dim(index_fcst1) <- c(time = 1, member = 5)
  index_fcst2 <- as.array(c(2.94, 4.08))
  dim(index_fcst2) <- c(time = 1, statistic = 2)

  result <- array(c(1.774329, 1.475816),
                  dim=c(time = 1, statistic = 2))
  
  expect_equal(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none',"ME")), result, 
               tolerance=1e-4)
  
  result <- array(c(0.2415013, 4.2232416, -0.9925062, 1.5508469, 0.9097119, 
                    1.5486845), dim=c(time = 3, statistic = 2))
  
  expect_equal(BEI_PDFBest(index_obs, index_hind1, index_hind2, 
                       method_BC = c('none',"ME")), result, 
               tolerance=1e-4)
   
})

test_that("Sanity checks", {
  index_obs<- c(2, 3, 0.6)
  dim(index_obs) <- c(time = 3)
  index_hind1 <- c(-2.4, 3.6, -5, -1, -0.5, -0.2, 3,  0.6,  1, 0, -0.5, 2)
  dim(index_hind1) <- c(time = 3, member = 4)
  index_hind2 <- c(1.194390, 4.298768, -1.222586, 4.419386,  3.972776, 3.998928)
  dim(index_hind2) <- c(time = 3, statistic=2)
  index_fcst1 <- c(-2.6, -0.6,  1.4, -2.4,  8.1)
  dim(index_fcst1) <- c(time = 1, member = 5)
  index_fcst2 <- as.array(c(2.94, 4.08))
  dim(index_fcst2) <- c(time = 1, statistic = 2)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
              index_fcst2, method_BC = c('none',"ME"), na.rm = 2), 
              "Parameter 'na.rm' must be a logical value.")

  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none',"ME"), 
                       time_dim_name = 2),
               paste0("Parameter 'time_dim_name' must be a character string ",
                      "indicating the name of the temporal dimension."))
  
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = list('none',"ME")),
               paste0("Parameter 'method_BC' must be a character vector."))
  
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME','ME')),
               "Length of parameter 'method_BC' must be 1 or 2.")
  
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','HME')),
               paste0("Elements of parameter 'method_BC' must be equals to ",
               "'none, 'ME' or 'LMEV'"))
  
  expect_error(BEI_PDFBest(index_obs = 2, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
               "Parameter 'index_obs' must be an array.")
  
  expect_error(BEI_PDFBest(index_obs, index_hind1 = 3, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
               "Parameter 'index_hind1' must be an array.")
  
  index_hind1 <- 1:15
  dim(index_hind1) <- c(3, 5)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
               paste0("Parameters 'index_obs', 'index_hind1' and 'index_hind2' ",
                      "should have dimmension names."))

  dim(index_hind1) <- c(pepe = 3, member = 5)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')), 
               "Parameter 'index_hind1' must have temporal dimension.")

  index_hind1 <- 1:8
  dim(index_hind1) <- c(time = 2, member = 4)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
               paste0("Length of temporal dimensions ",
                  "of parameter 'index_obs' and 'index_hind1' must be equals."))
  
  index_hind1 <- 1:12
  dim(index_hind1) <- c(time = 3, season = 4)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
             "Parameter 'index_hind1' must have dimension 'member' or 'statistic'")
  
  dim(index_hind1) <- c(time = 3, member = 4, statistic = 1)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')), 
               paste0("Parameter 'index_hind1' must have at least dimension ",
                      "'member' or 'statistic', not 'member' and 'statistic' ",
                      "together."))
  index_hind1 <- 1:9
  dim(index_hind1) <- c(time = 3, member = 1, season = 3)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
               paste0("Length of dimension 'member' ",
                      "of parameter 'index_hind1' must be greater than 1."))
  
  
  index_hind1 <- 1:12
  dim(index_hind1) <- c(time = 3, member = 4)
  index_hind2 <- 1:9
  dim(index_hind2) <- c(time = 3, statistic=3)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
               paste0("Length of dimension 'statistic' ",
                      "of parameter 'index_hind2' must be equal to 2."))
  
  index_hind2 <- 1:6
  dim(index_hind2) <- c(time = 3, statistic=2)
  index_fcst1 <- 1:8
  dim(index_fcst1) <- c(time = 1, member = 8)
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1 = 2, 
                       index_fcst2, method_BC = c('none','ME')),
              "Parameter 'index_fcst1' must be an array.")
  
  index_fcst1 <- 1:16
  dim(index_fcst1) <- c(time = 2, member = 8)
  
  expect_error(BEI_PDFBest(index_obs, index_hind1, index_hind2, index_fcst1, 
                       index_fcst2, method_BC = c('none','ME')),
               paste0("Length of temporal dimension ",
                      "of parameter 'index_fcst1' must be equal to 1."))

})  
