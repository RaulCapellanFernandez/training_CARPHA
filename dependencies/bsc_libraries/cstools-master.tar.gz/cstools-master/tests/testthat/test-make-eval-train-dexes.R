##############################################

test_that("1. Input checks", {
  # s2dv_cube
  expect_error(
    .make.eval.train.dexes(eval.method = 1, 2),
    paste0("unknown sampling method: 1")
  )
  expect_error(
   .make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 12),
    paste0("k needs to be a positive integer less than the amt.points")
  )
  expect_error(
   .make.eval.train.dexes(eval.method = 'retrospective', 10, NULL, 10),
    paste0("k needs to be a positive integer less than the amt.points")
  )
})

##############################################

test_that("2. Output checks: k-fold", {
  expect_equal(
    is.list(.make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)),
    TRUE
  )
  expect_equal(
   is.list(.make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)[[1]]),
    TRUE
  )
  expect_equal(
   length(.make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)),
    10
  )
  expect_equal(
   names(.make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)[[1]]),
    c("eval.dexes", "train.dexes")
  )
  expect_equal(
   .make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)[[1]],
    list(eval.dexes = 1,
         train.dexes = 4:8)
  )
   expect_equal(
   .make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)[[2]],
    list(eval.dexes = 2, 
         train.dexes = 5:9)
  )
   expect_equal(
   .make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)[[3]],
    list(eval.dexes = 3,
         train.dexes = 6:10)
  )
   expect_equal(
   .make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)[[9]],
    list(eval.dexes = 9,
         train.dexes = 2:6)
  )
   expect_equal(
   .make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 5)[[10]],
    list(eval.dexes = 10,
         train.dexes = 3:7)
  )
  expect_equal(
   .make.eval.train.dexes(eval.method = 'k-fold', 10, NULL, 1),
   .make.eval.train.dexes(eval.method = 'leave-one-out', 10, NULL)
  )
  expect_equal(
   .make.eval.train.dexes(eval.method = 'k-fold', 20, NULL, 1),
   .make.eval.train.dexes(eval.method = 'leave-one-out', 20, NULL)
  )
})

##############################################

test_that("3. Output checks: retrospective", {
  expect_equal(
    length(.make.eval.train.dexes(eval.method = 'retrospective', 10, NULL, 3)),
    7
  )
  expect_equal(
    .make.eval.train.dexes(eval.method = 'retrospective', 10, NULL, 3)[[1]],
    list(eval.dexes = 4, train.dexes = 1:3)
  )
  expect_equal(
    .make.eval.train.dexes(eval.method = 'retrospective', 10, NULL, 3)[[2]],
    list(eval.dexes = 5, train.dexes = 1:4)
  )
  expect_equal(
    .make.eval.train.dexes(eval.method = 'retrospective', 10, NULL, 3)[[7]],
    list(eval.dexes = 10, train.dexes = 1:9)
  )
})

