##############################################

# Default output
output_default <- "DATA SUMMARY:
lonlat_prec months: March, February 
lonlat_prec range: Mar 01 2011 to Mar 31 2013 
lonlat_prec dimensions: 
dataset  member   sdate   ftime     lat     lon  
      1       6       3      31       4       4  
Statistical summary of the data in  lonlat_prec : 
      Min.    1st Qu.     Median       Mean    3rd Qu.       Max.  
-7.064e-10  0.000e+00  3.532e-09  3.501e-08  4.027e-08  7.516e-07  
--------------------------------------------- "

# Conditional output
output_conditional <- "DATA SUMMARY:
lonlat_prec_st months: March, February 
lonlat_prec_st range: Mar 01 2011 to Mar 31 2013 
lonlat_prec_st dimensions: 
dataset     var  member   sdate   ftime     lat     lon  
      1       1       6       3      31       4       4  
Statistical summary of the data in  lonlat_prec_st : 
Variable: prlr (units: m s-1) 
      Min.    1st Qu.     Median       Mean    3rd Qu.       Max.  
-7.064e-10  0.000e+00  3.532e-09  3.501e-08  4.027e-08  7.516e-07  
NA-Indices per Dimension
dataset:  var:  member:  sdate:  ftime:  lat:  lon:  
Number of NAs in NA-Indices per Dimensions
dataset:  var:  member:  sdate:  ftime:  lat:  lon:  
Loaded files:
/esarchive/exp/ecmwf/system5c3s/daily_mean/prlr_s0-24h/prlr_20101101.nc
/esarchive/exp/ecmwf/system5c3s/daily_mean/prlr_s0-24h/prlr_20111101.nc
/esarchive/exp/ecmwf/system5c3s/daily_mean/prlr_s0-24h/prlr_20121101.nc 
--------------------------------------------- "

##############################################
test_that("Input checks: CST_Summary", {
  # Check that data is s2dv_cube
  expect_error(
    CST_Summary(array(10)), 
    "Parameter 'data' must be of the class 's2dv_cube'."
  )
  # Check show_NA
  expect_error(
    CST_Summary(lonlat_prec, show_NA = 1.5),
    "Parameter 'show_NA' must be logical."
  )
  # Check show_loaded_files
  expect_error(
    CST_Summary(lonlat_prec, show_loaded_files = 1.5),
    "Parameter 'show_loaded_files' must be logical."
  )
  # Check var_dim
  expect_error(
    CST_Summary(lonlat_prec, var_dim = 1),
    "'var_dim' must be a single character string."
  )
  expect_error(
    CST_Summary(lonlat_prec, var_dim = c('tas', 'psl')),
    "'var_dim' must be a single character string."
  )
  expect_warning(
    CST_Summary(lonlat_prec, var_dim = "var"),
    "Dimension var not found. Summary is not be split by variable."
  )
})

test_that("2. Output checks: CST_Summary", {
  # Default output
  actual_out <- capture.output(suppressWarnings(CST_Summary(lonlat_prec)))
  expect_out <- capture.output(cat(output_default))
  expect_equal(
    actual_out, 
    expect_out
  )
  
  # Conditional output               
  actual_out <- capture.output(
    CST_Summary(lonlat_prec_st, show_loaded_files = TRUE,
                show_NA = TRUE, var_dim = "var")
  )
  expect_out <- capture.output(cat(output_conditional))
  expect_equal(
    actual_out, 
    expect_out
  )
})

