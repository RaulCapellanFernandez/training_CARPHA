##############################################

# dat1
dat_exp <- array(abs(rnorm(4*6*3*4*4))*275, dim = c(dataset = 1, member = 4, sdate = 6, 
                                                    ftime = 3, lat = 4, lon = 4))
dat_obs <- array(abs(rnorm(6*3*4*4))*275, dim = c(dataset = 1, member = 1, sdate = 6, 
                                                  ftime = 3, lat = 4, lon = 4))
lon <- seq(0, 3)
lat <- seq(48, 27)

coords <- list(lon = lon, lat = lat)

exp <- list(data = dat_exp, coords = coords)
obs <- list(data = dat_obs, coords = coords)
attr(exp, 'class') <- 's2dv_cube'
attr(obs, 'class') <- 's2dv_cube'

# dat2
exp2 <- exp
exp2$data[1, 2, 1, 1, 1, 1] <- NA
obs2 <- obs
obs2$data[1, 1, 2, 1, 1, 1] <- NA

##############################################

test_that("Sanity checks", {
  expect_error(
    CST_CategoricalEnsCombination(exp = 1),
    paste0("Parameter 'exp' and 'obs' must be of the class 's2dv_cube', ",
         "as output by CSTools::CST_Load.")
  )
  expect_error(
    CST_CategoricalEnsCombination(obs = 1),
    c("argument \"exp\" is missing, with no default")
  )
  cal <- CST_CategoricalEnsCombination(exp = exp, obs = obs)
  expect_equal(
    length(cal),
    2
  )
  expect_equal(
    as.numeric(dim(cal$data)[c(1, 2)]),
    c(1, 1)
  )
  expect_equal(
    as.numeric(dim(cal$data)[c(-1, -2, -3)]),
    as.numeric(dim(exp$data)[c(-1, -2)])
  )
  expect_equal(
    names(dim(cal$data))[c(-1, -2, -3)],
    names(dim(exp$data))[c(-1, -2)]
  )
  expect_equal(
    names(dim(cal$data))[c(1, 2, 3)],
    c("dataset", "member", "category")
  )
  expect_equal(
    cal$lat, 
    exp$lat
  )
  expect_equal(
    cal$lat, 
    obs$lat
  )
  expect_equal(
    cal$lon, 
    exp$lon
  )
  expect_equal(
    cal$lon, 
    obs$lon
  )
  expect_error(
    CST_CategoricalEnsCombination(exp = exp, obs = exp),
    "The length of the dimension 'member' in the component 'data' "
  )
  expect_warning(
    CST_CategoricalEnsCombination(exp = exp2, obs = obs),
    "Parameter 'exp' contains NA values."
  )
  expect_warning(
    CST_CategoricalEnsCombination(exp = exp, obs = obs2),
    "Parameter 'obs' contains NA values."
  )
  expect_warning(
    CST_CategoricalEnsCombination(exp = exp2, obs = obs2),
    "Parameter 'exp' contains NA values."
  )
})  
