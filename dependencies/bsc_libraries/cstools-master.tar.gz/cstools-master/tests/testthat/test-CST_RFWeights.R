##############################################

# dat1
data <- rnorm(2 * 10 * 4 * 5 * 6 * 6)
dim(data) <- c(dataset = 2, member = 10,
                sdate = 4, ftime = 5, lats = 6, lons = 6)
lon <- seq(0, 11, 2)
lat <- seq(10, 15, 1)
coords <- list(longitude = lon, latitude = lat)
exp <- list(data = data, coords = coords)
attr(exp, "class") <- "s2dv_cube"

# dat2
exp2_2 <- exp
exp2_2$coords <- NULL
exp2_3 <- exp
names(exp2_3$coords) <- c("lati", "loni")

##############################################
test_that("1. Input checks", {
  # Check 's2dv_cube'
  expect_error(
    CST_RFWeights(rnorm(2 * 15 * 4 * 5 * 6 * 7), lon = lon, lat = lat),
    paste0("Parameter 'climfile' is expected to be a character string indicating",
           " the path to the files or an object of class 's2dv_cube'.")
  )
  # Check object structure
  expect_error(
    CST_RFWeights(exp2_2, lon = lon, lat = lat, nf = 3),
    paste0("Parameter 'climfile' must have 'data' and 'coords' elements ",
           "within the 's2dv_cube' structure.")
  )  
  # Check coordinates
  expect_error(
    CST_RFWeights(exp2_3, lon = lon, lat = lat, nf = 3),
    paste0("Spatial coordinate names do not match any of the names accepted by ",
           "the package.")
  )
})

##############################################

test_that("2. Output checks", {
  res <- CST_RFWeights(climfile = exp, nf = 3, lon, lat, lonname = 'lons', 
                       latname = 'lats', fsmooth = TRUE)
  expect_equal(
    names(res$coords),
    c("longitude", "latitude")
  )
  expect_equal(
    names(dim(res$data)),
    c("lons", "lats", "dataset", "member", "sdate", "ftime" )
  )
})