##############################################

test_that("Sanity checks", {
  pdf_1 <- c(1.1,0.6)
  attr(pdf_1, "name") <- "NAO1"
  dim(pdf_1) <-  c(statistic = 2)
  pdf_2 <- c(1,0.5)
  attr(pdf_2, "name") <- "NAO2"
  dim(pdf_2) <-  c(statistic = 2)

  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = "plot.png", 
                                       width = 30, height = 15, 
                                       units = "cm", dpi = '300') , 
              "Parameter 'dpi' must be numeric.")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = "plot.png", 
                           width = 30, height = 15, 
                           units = 20, dpi = 300) , 
               "Parameter 'units' must be character")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = "plot.png", 
                           width = 30, height = 15, 
                           units = "dm", dpi = 300) , 
               "Parameter 'units' must be equal to 'in', 'cm' or 'mm'.")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = "plot.png", 
                           width = 30, height = '15', 
                           units = "cm", dpi = 300) , 
               "Parameter 'height' must be numeric.")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = "plot.png", 
                           width = list(30), height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'width' must be numeric.")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = 0, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               paste0("Parameter 'plotfile' must be a character string ",
                    "indicating the path and name of output png file."))
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, legendPos = 1, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'legendPos' must be character")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, legendPos = 'arriba', 
                           plotfile = "plot.png", 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'legendPos' must be equal to 'bottom', 'top', 'right' or 'left'.")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, legendSize = '3', plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'legendSize' must be numeric.")
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = '3', plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'nsigma' must be numeric.")
  
  pdf_1 <- list(1.1,0.6)
  attr(pdf_1, "name") <- "NAO1"
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'pdf_1' must be an array.")
  
  pdf_1 <- c('1.1','0.6')
  attr(pdf_1, "name") <- "NAO1"
  dim(pdf_1) <-  c(statistic = 2)
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'pdf_1' must be a numeric array.")
  
  pdf_1 <- c(1.1,0.6)
  attr(pdf_1, "name") <- "NAO1"
  dim(pdf_1) <-  c(2)
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               paste0("Parameters 'pdf_1' and 'pdf_2' ",
                    "should have dimmension names."))
  
  pdf_1 <- c(1.1,0.6)
  attr(pdf_1, "name") <- "NAO1"
  dim(pdf_1) <-  c(statisti = 2)
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'pdf_1' must have dimension 'statistic'.")
  
  pdf_1 <- c(1.1,0.6)
  attr(pdf_1, "name") <- "NAO1"
  dim(pdf_1) <-  c(statistic = 2, model = 1)
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               "Parameter 'pdf_1' must have only dimension 'statistic'.")
  
  pdf_1 <- c(1.1, 0.6, 0.2)
  attr(pdf_1, "name") <- "NAO1"
  dim(pdf_1) <-  c(statistic = 3)
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               paste0("Length of dimension 'statistic'",
                    "of parameter 'pdf_1' and 'pdf_2' must be equal to 2."))
  
  pdf_1 <- c(1.1, 0.6)
  attr(pdf_1, "name") <- 12
  dim(pdf_1) <-  c(statistic = 2)
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               paste0("The 'name' attribute of parameter 'pdf_1' must be a character ",
                    "indicating the name of the variable of parameter 'pdf_1'."))
  
  pdf_1 <- c(1.1,0.6)
  attr(pdf_1, "name") <- "NAO1"
  dim(pdf_1) <-  c(statistic = 2)
  pdf_2 <- c(1,0.5)
  attr(pdf_2, "name") <- 12
  dim(pdf_2) <-  c(statistic = 2)
  
  expect_error(PlotPDFsOLE(pdf_1, pdf_2, nsigma = 3, plotfile = NULL, 
                           width = 30, height = 15, 
                           units = "cm", dpi = 300) , 
               paste0("The 'name' attribute of parameter 'pdf_2' must be a character ",
                      "indicating the name of the variable of parameter 'pdf_2'."))
  
  
  
  
})  
