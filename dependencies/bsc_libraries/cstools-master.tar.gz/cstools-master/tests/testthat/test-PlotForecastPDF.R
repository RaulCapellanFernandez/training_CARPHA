##############################################

test_that("Sanity checks", {
  expect_error(
    PlotForecastPDF(fcst, tercile.limits),
    "object 'fcst' not found")
  expect_error(
    PlotForecastPDF(fcst, tercile.limits = c(0.25, 0.55)),
    "object 'fcst' not found")
  expect_error(
    PlotForecastPDF(fcst, tercile.limits = 10),
    "object 'fcst' not found")
  expect_error(
    PlotForecastPDF(fcst, tercile.limits = c(10, 20)),
    "object 'fcst' not found")
  fcsts2 <- array(rnorm(100),dim = c(member = 20, fcst = 5))
  expect_error(
    PlotForecastPDF(fcst = fcsts2, tercile.limits),
    "object 'tercile.limits' not found")
  expect_error( 
    PlotForecastPDF(fcst = fcsts2, tercile.limits = c(-0.5, 0.5), extreme.limits = NA),
    "Provide two extreme limits")
})
