##############################################

# dat1
data <- rnorm(2 * 10 * 4 * 5 * 6 * 7)
dim(data) <- c(dataset = 2, member = 10,
                sdate = 4, ftime = 5, lat = 6, lon = 7)
lon <- seq(0, 12, 2)
lat <- seq(10, 15, 1)
coords <- list(lon = lon, lat = lat)
exp1 <- list(data = data, coords = coords)
attr(exp1, "class") <- "s2dv_cube"

##############################################
test_that("1. Input checks", {
  # Check 's2dv_cube'
  expect_error(
    CST_ProxiesAttractor(rnorm(2 * 15 * 4 * 5 * 6 * 7)),
    paste0("Parameter 'data' must be of the class 's2dv_cube', ",
           "as output by CSTools::CST_Load.")
  )
  # Check quanti
  expect_error(
    CST_ProxiesAttractor(data = exp1, quanti = NULL),
    paste0("Parameter 'quanti' cannot be NULL.")
  )
})
##############################################