##############################################
exp <- lonlat_temp$exp
##############################################

test_that("1. Input checks", {
  expect_error(
    CST_InsertDim(1),
    "Parameter 'data' must be of the class 's2dv_cube'."
  )
  expect_error(
    CST_InsertDim(exp, name = 1),
    "Parameter 'name' must be a character string"
  )
  expect_warning(
    CST_InsertDim(exp, posdim = 1, lendim = 1, name = "variable"),
    paste0("Parameter 'values' is not provided. Adding a sequence of ",
	         "integers from 1 to 'lendim' as the values for the new dimension.")
  )
  expect_error(
    CST_InsertDim(exp, posdim = 1, lendim = 1, name = "variable", values = 1:2),
    paste0("The length of the parameter 'values' must be consistent",
           "with the parameter 'lendim'.")
  )
})

##############################################

test_that("2. Output checks", {
  exp <- CST_InsertDim(exp, posdim = 2, lendim = 1, name = "variable", 
                       values = c("tas"))
  expect_equal(
    dim(exp$data), 
    c(dataset = 1, variable = 1, member = 15, sdate = 6, ftime = 3, lat = 22, 
      lon = 53)
  ) 
  expect_equal(
    exp$dims, 
    c(dataset = 1, variable = 1, member = 15, sdate = 6, ftime = 3, lat = 22, 
      lon = 53)
  )
  expect_equal(
    exp$coords$variable, 
    c("tas")
  )
})
