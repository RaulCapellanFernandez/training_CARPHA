##############################################

test_that("1. Input checks", {
  # Check 's2dv_cube'
  expect_error(
    CST_RegimesAssign(data = 1),
    paste0("Parameter 'data' must be of the class 's2dv_cube', as output by ",
           "CSTools::CST_Load.")
  )
  data1 <- 1 : 20
  data1 <- list(data = data1)
  class(data1) <- 's2dv_cube'
  expect_error(
    CST_RegimesAssign(data = data1, ref_maps = 1),
    paste0("Parameter 'ref_maps' must be of the class 's2dv_cube', as output by ",
           "CSTools::CST_Load.")
  )
  # data
  regimes <- 1:20
  dim(regimes) <- c(lat = 5, lon = 2, cluster = 2)
  regimes <- list(data = regimes)
  expect_error(
    RegimesAssign(data = data1$data, ref_maps = regimes$data),
    paste0("Parameter 'data' must be an array with named dimensions.")
  )
  # Temporal dimensions
  data1 <- 1 : 20
  dim(data1) <- c(lat = 5, lon = 4)
  data1 <- list(data = data1 , coords = list(lat = 1:5))
  class(data1) <- 's2dv_cube'
  expect_error(
    RegimesAssign(data = data1$data, ref_maps = regimes$data, 
                  lat = data1$coords$lat),
    paste0("Parameter 'data' must have temporal dimensions.")
  )
  data1 <- 1 : 20
  dim(data1) <- c(time = 20)
  data1 <- list(data = data1)
  class(data1) <- 's2dv_cube'
  
  expect_error(
    RegimesAssign(data = data1$data, ref_maps = regimes$data, 
                  lat = data1$coords$lat),
    paste0("Parameter 'lat' must be specified.")
  )
  data1 <- 1 : 20
  dim(data1) <- c(time = 20)
  data1 <- list(data = data1,  coords = list(lat = 1:5))
  class(data1) <- 's2dv_cube'
  expect_error(
    RegimesAssign(data = data1$data, ref_maps = regimes$data, 
                  lat = data1$coords$lat),
    paste0("Spatial coordinate dimension names do not match any of the names ",
           "accepted by the package.")
  )
})

##############################################

test_that("2. Output checks", {
  data1 <- 1: 20
  dim(data1) <- c(lat = 5, lon = 2, time = 2)
  data1 <- list(data = data1,  coords = list(lat = 1:5, lon = 1:2))
  class(data1) <- 's2dv_cube'
  regimes <- 1:20
  dim(regimes) <- c(lat = 5, lon = 2, cluster = 2)
  regimes <- list(data = regimes, coords = list(lat = 1:5, lon = 1:2))
  class(regimes) <- 's2dv_cube'
  expect_equal(
    names(CST_RegimesAssign(data = data1, ref_maps = regimes)$statistics),
    c('cluster', 'frequency')
  )  
  expect_equal(
    names(suppressWarnings(
          CST_RegimesAssign(
            data = data1,
            ref_maps = regimes,
            composite = TRUE))$statistics), 
    c('pvalue', 'cluster', 'frequency')
  )  
  expect_equal(
    names(dim(
    suppressWarnings(
    CST_RegimesAssign(
      data = data1,
      ref_maps = regimes,
      composite = TRUE))$data)), c('lon', 'lat', 'composite.cluster')
  )
  
  data1 <- 1: 160
  dim(data1) <- c(lat = 5, lon=2, time=2, member=8)
  data1 <- list(data = data1,  coords = list(lat = 1:5))
  class(data1) <- 's2dv_cube'
  
  expect_equal(
    names(dim(
    suppressWarnings(
    CST_RegimesAssign(
      data = data1,
      ref_maps = regimes,
      composite = TRUE))$data)), c('lon', 'lat', 'composite.cluster', 'member')
  )
  
  expect_equal(
    names(dim(
    suppressWarnings(
    CST_RegimesAssign(
      data = data1,
      ref_maps = regimes,
      composite = TRUE))$statistics$cluster)), c('time', 'member')
  )
  
  regimes <- 1:60
  dim(regimes) <- c(lat = 5, lon=2, cluster=6)
  regimes <- list(data=regimes)
  class(regimes) <- 's2dv_cube'
  expect_equal(max(CST_RegimesAssign(data = data1, ref_maps = regimes,
                                     composite = FALSE)$statistics$cluster), 
               unname(dim(regimes$data)['cluster']))


  regimes <- 1:240
  dim(regimes) <- c(lat = 5, lon=2, cluster=3, member=8)
  regimes <- list(data=regimes)
  class(regimes) <- 's2dv_cube'
  expect_equal(
    names(dim(CST_RegimesAssign(data = data1, ref_maps = regimes,
                                composite = FALSE)$statistics$cluster)), 
    c('member', 'time')
  )  

})
