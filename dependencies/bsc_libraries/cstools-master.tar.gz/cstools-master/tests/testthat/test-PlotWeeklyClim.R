##############################################

# dat1
dat1 <- array(rnorm(1*7), dim = c(dat = 1, var = 1, sdate = 1, time = 7))
dat2 <- array(rnorm(21), dim = c(dat = 1, var = 1, sdate = 3, time = 7))

##############################################

test_that("1. Input checks", {
  # data
  expect_error(
    PlotWeeklyClim(data = array(1:92), first_date = '2020-03-01', 
                   ref_period = 1993:2021),
    "Parameter 'data' must have named dimensions."
  )
  expect_error(
    PlotWeeklyClim(data = data.frame(week = 1:92), first_date = '2020-03-01', 
                   ref_period = 1993:2021),
    paste0("If parameter 'data' is a data frame, it must contain the ",
           "following column names: 'week', 'clim', 'p10', 'p90', 'p33', ", 
           "'p66', 'week_mean', 'day' and 'data'.")
  )
  expect_error(
    PlotWeeklyClim(data = 1:92, first_date = '2020-03-01', 
                   ref_period = 1993:2021),
    "Parameter 'data' must be an array or a data frame."
  )
  # time_dim
  expect_error(
    PlotWeeklyClim(data = dat1, first_date = '2020-03-01', 
                   ref_period = 2020, time_dim = 1),
    "Parameter 'time_dim' must be a character string."
  )
  expect_error(
    PlotWeeklyClim(data = array(rnorm(1), dim = c(dat = 1)), 
                   first_date = '2020-03-01', ref_period = 2020),
    "Parameter 'time_dim' is not found in 'data' dimension."
  )
  expect_error(
    PlotWeeklyClim(data = array(rnorm(1*7), dim = c(time = 6)), 
                   first_date = '2020-03-01', ref_period = 2020),
    paste0("Parameter 'data' must have the dimension 'time_dim' of length ",
           "equal or grater than 7 to compute the weekly means.")
  )
  # sdate_dim
  expect_error(
    PlotWeeklyClim(data = dat1, first_date = '2020-03-01', 
                   ref_period = 2020, sdate_dim = 1),
    "Parameter 'sdate_dim' must be a character string."
  )
  expect_warning(
    PlotWeeklyClim(data = array(rnorm(7), dim = c(time = 7)), 
                   first_date = '2020-03-01', ref_period = 2020),
    paste0("Parameter 'sdate_dim' is not found in 'data' dimension. ",
           "A dimension of length 1 has been added.")
  )
  # legend
  expect_error(
    PlotWeeklyClim(data = dat1, first_date = '2020-03-01', 
                   ref_period = 2020, legend = 1),
    "Parameter 'legend' must be a logical value."
  )
  # ref_period (1)
  expect_error(
    PlotWeeklyClim(data = dat1, first_date = '2020-03-01', ref_period = "2020"),
    "Parameter 'ref_period' must be numeric."
  )
  # first_date
  expect_error(
    PlotWeeklyClim(data = dat1, first_date = 2020-03-01, ref_period = 2020),
    paste0("Parameter 'first_date' must be a character string ", 
           "indicating the date in the format 'yyyy-mm-dd', 'POSIXct' ", 
           "or 'Dates' class.")
  )
  # data_years
  expect_error(
    PlotWeeklyClim(data = dat2, first_date = '2020-03-01', ref_period = 2020, 
                   data_years = '2020'),
    "Parameter 'data_years' must be numeric."
  )
  expect_error(
    PlotWeeklyClim(data = dat2, first_date = '2020-03-01', ref_period = 2020, 
                   data_years = 2005:2020),
    paste0("Parameter 'data_years' must have the same length as the ",
           "dimension 'sdate' of 'data'.")
  )
  expect_error(
    PlotWeeklyClim(data = dat2, first_date = '2010-03-01', 
                   ref_period = 2020:2021, data_years = 2018:2020),
    paste0("The 'ref_period' must be included in the 'data_years' ", 
           "period.")
  )
  expect_error(
    PlotWeeklyClim(data = dat2, first_date = '2021-03-01', 
                   ref_period = 2018:2019, data_years = 2018:2020),
    paste0("Parameter 'first_date' must be a date included ", 
           "in the 'data_years' period.")
  )
  # ref_period (2)
  expect_error(
    PlotWeeklyClim(data = dat2, first_date = '2020-03-01', 
                   ref_period = 2020:2021),
    paste0("Parameter 'ref_period' must have the same length as the ",
           "dimension 'sdate' of 'data' if 'data_years' is not provided.")
  )
  expect_error(
    PlotWeeklyClim(data = dat2, first_date = '2020-03-01', 
                   ref_period = 2017:2019),
    paste0("If parameter 'data_years' is NULL, parameter 'first_date' ", 
           "must be a date included in the 'ref_period' period.")
  )
  # last_date
  expect_error(
    PlotWeeklyClim(data = dat2, first_date = '2020-03-01', 
                   ref_period = 2020:2022, last_date = 2020-03-01),
    paste0("Parameter 'last_date' must be a character string ", 
           "indicating the date in the format 'yyyy-mm-dd', 'POSIXct' ", 
           "or 'Dates' class.")
  )
  expect_warning(
    PlotWeeklyClim(data = dat2, first_date = '2020-03-01', 
                   ref_period = 2020:2022, last_date = '2020-03-08'),
    paste0("Parameter 'last_date' is greater than the last date ",
           "of 'data'. The last date of 'data' will be used.")
  )
  # ylim
  expect_warning(
    PlotWeeklyClim(data = dat2, first_date = '2020-03-01', 
                   ref_period = 2020:2022, ylim = 'i'),
    paste0("Parameter 'ylim' can't be a character string, it will ",
           "not be used.")
  )
})

##############################################