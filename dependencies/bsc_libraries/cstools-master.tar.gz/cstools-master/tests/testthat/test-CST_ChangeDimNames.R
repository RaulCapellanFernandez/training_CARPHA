##############################################
test_that("1. Input checks", {
  expect_error(
    CST_ChangeDimNames(1),
    "Parameter 'data' must be an object of class 's2dv_cube'."
  )
  expect_error(
    CST_ChangeDimNames(lonlat_prec_st, 1, 'bbb'),
    paste0("Parameter 'original_names' must be a character string or a ", 
           "vector of character strings.")
  )
  expect_error(
    CST_ChangeDimNames(lonlat_prec_st, 'aaa', 1),
    paste0("Parameter 'new_names' must be a character string or a ",
           "vector of character strings.")
  )
  expect_error(
    CST_ChangeDimNames(lonlat_prec_st, 'aaa', c('aaa', 'bbb')),
    paste0("The number of dimension names in 'new_names' must be the same ",
           "as in 'original_names'.")
  )
  expect_error(
    CST_ChangeDimNames(lonlat_prec_st, 'aaa', 'bbb'),
    paste0("Some of the dimensions in 'original_names' could not be found in ",
           "'data'.")
  )
})
##############################################
test_that("2. Output checks", {
  exp <- CST_ChangeDimNames(lonlat_temp_st$exp,
                            original_names = c("lon", 'ftime', 'sdate'),
                            new_names = c("lons", 'ftimes', 'sdates'))
  # dims
  expect_equal(
    dim(exp$data),
    c(dataset = 1, var = 1, member = 15, sdates = 6, ftimes = 3, lat = 22, lons = 53)
  )
  expect_equal(
    exp$dims,
    dim(exp$data)
  )
  expect_equal(
    as.vector(exp$data),
    as.vector(lonlat_temp_st$exp$data)
  )
  # coords
  expect_equal(
    names(exp$coords),
    c("dataset", "var", "member", "sdates", "ftimes", "lat", "lons")
  )
  # dim Dates
  expect_equal(
    dim(exp$attrs$Dates),
    c(sdates = 6, ftimes = 3)
  )
  # variable metadata
  expect_equal(
    names(exp$attrs$Variable$metadata),
    c("lat", "lons", "ftimes", "tas" )
  )
  # source_files
  expect_equal(
    dim(exp$attrs$source_files),
    c(dataset = 1, var = 1, sdates = 6)
  )
  # Dates 'dim' attribute
  dat <- CST_ChangeDimNames(lonlat_prec,
                            original_names = c("lon", 'ftime', 'sdate', 'member'),
                            new_names = c("lons", 'ftimes', 'sdates', 'members')) 
  expect_equal(
    as.vector(lonlat_prec$data),
    as.vector(dat$data)
  )
  expect_equal(
    attributes(dat$attrs$Dates)$dim,
    c(ftimes = 31, sdates = 3)
  )
  expect_equal(
    attributes(exp$attrs$Dates)$dim,
    c(sdates = 6, ftimes = 3)
  )
  expect_equal(
    as.vector(dat$attrs$Dates),
    as.vector(lonlat_prec$attrs$Dates)
  )
  # attribute dimensions
  expect_equal(
    attributes(dat$data)$dimensions,
    names(dim(dat$data))
  )
  expect_equal(
    attributes(exp$data)$dimensions,
    NULL
  )
})