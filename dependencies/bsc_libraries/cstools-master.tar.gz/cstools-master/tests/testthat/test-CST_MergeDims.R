##############################################

# data1
data1 <- list(data = 1:10)
class(data1) <- 's2dv_cube'

# data2
data <- 1 : 20
dim(data) <- c(time = 20)
data2 <- list(data = data)
data2$dims <- dim(data)
data2$coords <- list(time = 1:20)
attr(data2$coords$time, 'indices') <- TRUE
class(data2) <- 's2dv_cube'

# exp
exp <- 1 : 20
dim(exp) <- c(time = 10, lat = 2)
exp <- list(data = exp)
class(exp) <- 's2dv_cube'

# data3 
data3 <- data2
names(dim(data3$data)) <- 'Dim1'
data3$dims <- dim(data3$data)
names(data3$coords) <- 'Dim1'

##############################################

test_that("1. Sanity checks", {
  expect_error(
    CST_MergeDims(data = 1),
    paste0("Parameter 'data' must be of the class 's2dv_cube'.")
  )
  expect_error(
    CST_MergeDims(data = data1),
    paste0("Parameter 'data' must have dimensions.")
  )

  expect_error(
    CST_MergeDims(data = data2),
    "Parameter 'merge_dims' must match with dimension names in parameter 'data'."
  )
  expect_error(
    CST_MergeDims(data = data2, merge_dims = 1),
    paste0("Parameter 'merge_dims' must be a character vector indicating the ",
           "names of the dimensions to be merged.")
  )
  expect_error(
    CST_MergeDims(data = data2, merge_dims = 'time'),
    "Parameter 'merge_dims' must be of length two."
  )
  expect_error(
    CST_MergeDims(data = data2, merge_dims = c('time', 'sdates')),
    paste0("Parameter 'merge_dims' must match with dimension ",
           "names in parameter 'data'.")
  )
})

##############################################

test_that("2. Output checks", {
  expect_equal(
    CST_MergeDims(data = exp, merge_dims = c('time', 'lat')), 
    data2
  )
  expect_warning(
    CST_MergeDims(data = exp, merge_dims = c('time', 'lat', 'lon')),
    paste0("Only two dimensions can be merge, only the first two dimension",
           " will be used. To merge further dimensions consider to use this ",
           "function multiple times.")
  )
  expect_warning(
    CST_MergeDims(data = exp, merge_dims = c('time', 'lat'), 
                  rename_dim = c('lat', 'lon')),
    paste0("Parameter 'rename_dim' has length greater than 1 and only the ",
           "first element will be used.")
  )
  expect_equal(
    CST_MergeDims(data = exp, merge_dims = c('time', 'lat'), 
                  rename_dim = 'Dim1'), 
    data3
  )
  expect_equal(
    CST_MergeDims(data = exp, merge_dims = c('time', 'lat'),
                  rename_dim = 'Dim1', na.rm = TRUE), 
    data3
  )
  expect_equal(
    CST_MergeDims(data = exp, merge_dims = c('time', 'lat'),
                  rename_dim = 'Dim1', na.rm = TRUE), 
    data3
  )
})

##############################################