##############################################

# dat1
dat1 <- array(1:5, dim = c(var = 1, sdate = 5))
coords1 <- list(sdate = c('20000101', '20010102', '20020103', '20030104', '20040105'), 
                var = 'tas')
dates1 <- as.POSIXct(coords1[[1]], format = "%Y%m%d", tz = "UTC")
dim(dates1) <- c(sdate = 5)

##############################################

test_that("1. Input checks", {
  # data
  expect_error(
    s2dv_cube(data = 1:10),
    "Parameter 'data' must be an array with named dimensions."
  )
  # coords
  expect_warning(
    s2dv_cube(data = dat1, coords = list(sdate = c('20000102', '20010202'), var = 'tas'), 
              varName = 'tas', metadata = list(tas = list(level = '2m')),
              Dates = dates1),
    "Coordinate 'sdate' has different lenght as its dimension and it will not be used."
  )
  expect_warning(
    s2dv_cube(data = dat1, coords = list(sdate = coords1[[1]]), 
              varName = 'tas', metadata = list(tas = list(level = '2m')),
              Dates = dates1),
    "Coordinate 'var' is not provided and it will be set as index in element coords."
  )
  # Dates
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1,
              varName = 'tas', metadata = list(tas = list(level = '2m'))),
    paste0("Parameter 'Dates' is not provided so the metadata ",
           "of 's2dv_cube' object will be incomplete.")
  )
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1,
              varName = 'tas', metadata = list(tas = list(level = '2m')),
              Dates = c('20000101', '20010102', '20020103', '20030104', '20040105')),
    paste0("Parameter 'Dates' must be an array with named time dimensions.")
  )
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1,
              varName = 'tas', metadata = list(tas = list(level = '2m')),
              Dates = array(c('20000101', '20010102', '20020103', '20030104', '20040105'))),
    paste0("Parameter 'Dates' must have dimension names.")
  )
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1,
              varName = 'tas', metadata = list(tas = list(level = '2m')),
              Dates = array(c('20000101', '20010102', '20020103', '20030104', '20040105'),
                            dim = c(time = 5))),
    paste0("Parameter 'Dates' must have the corresponding time dimension names in 'data'.")
  )
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1,
              varName = 'tas', metadata = list(tas = list(level = '2m')),
              Dates = array(c('20000101', '20010102', '20020103', '20030104', '20040105'),
                            dim = c(sdate = 5))),
    paste0("Parameter 'Dates' must be of class 'POSIXct'.")
  )
  # varName
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1, 
              metadata = list(tas = list(level = '2m')),
              Dates = dates1),
    paste0("Parameter 'varName' is not provided so the metadata ",
           "of 's2dv_cube' object will be incomplete.")
  )
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1, varName = 1, 
              metadata = list(tas = list(level = '2m')),
              Dates = dates1),
    "Parameter 'varName' must be a character."
  )
  # metadata
  expect_warning(
    s2dv_cube(data = dat1, coords = coords1, varName = 'tas', 
              Dates = dates1),
    "Parameter 'metadata' is not provided so the metadata of 's2dv_cube' object will be incomplete."
  )
})

##############################################

test_that("2. Output checks", {
  expect_equal(
    names(s2dv_cube(data = dat1, coords = coords1, 
                    varName = 'tas', metadata = list(tas = list(level = '2m')),
                    Dates = dates1)),
    c("data", "dims", "coords", "attrs")
  )
  expect_equal(
    names(s2dv_cube(data = dat1, coords = coords1, 
                    varName = 'tas', metadata = list(tas = list(level = '2m')),
                    Dates = dates1)$coords),
    c("sdate", "var")
  )
  expect_equal(
    names(s2dv_cube(data = dat1, coords = coords1, 
                    varName = 'tas', metadata = list(tas = list(level = '2m')),
                    Dates = dates1)$attrs),
    c("Dates", "Variable")
  )
  expect_equal(
    names(s2dv_cube(data = dat1, coords = coords1, 
                    varName = 'tas', metadata = list(tas = list(level = '2m')),
                    Dates = dates1, Datasets = 'dat1', 
                    when = as.POSIXct("2022-12-21 17:13"), 
                    source_files = "/home/R")$attrs),
    c("Dates", "Variable", "Datasets", "when", "source_files")
  )
  suppressWarnings(
    object <- s2dv_cube(data = dat1, coords = list(sdate = coords1[[1]]), varName = 'tas', 
                        metadata = list(tas = list(level = '2m')), 
                        Dates = dates1)
  )
  expect_equal(
    attributes(object$coords$sdate),
    list(indices = FALSE)
  )
  expect_equal(
    attributes(object$coords$var),
    list(indices = TRUE)
  )
})

##############################################

test_that("3. Output checks", {
  dim(coords1$sdate) <- c(sdate = 5)
  dim(coords1$var) <- c(var = 1)
  suppressWarnings(
    object <- s2dv_cube(data = dat1, coords = list(sdate = coords1[[1]]), varName = 'tas', 
                        metadata = list(tas = list(level = '2m')), 
                        Dates = dates1)
  )
  expect_equal(
    names(object$coords),
    c('sdate', 'var')
  )
  expect_equal(
    dim(object$coords$sdate),
    NULL
  )
  expect_equal(
    dim(object$coords$var),
    NULL
  )
  expect_equal(
    length(object$coords$sdate),
    5
  )
})
