##############################################

test_that("Sanity checks", {
  expect_error(
    PlotTriangles4Categories(data = 1:20),
    paste0("Parameter 'data' must be an array with three dimensions."))
  
  data1 <- array(runif(min = -1, max = 1, n = 30), dim=c(5,3,2))
  expect_error(
    PlotTriangles4Categories(data = data1),
    paste0("Parameter 'data' must be an array with named dimensions."))
  
  data1 <- runif(min = -1, max = 1, n = 30)
  dim(data1) <- c(dim1 = 5, dim2 = 2, dim3 = 3)
  expect_error(
    PlotTriangles4Categories(data = data1),
    paste0("Parameter 'data' should contain 'dimx', 'dimy' and 'dimcat' dimension names."))
  
  data1 <- runif(min = -1, max = 1, n = 30)
  dim(data1) <- c(dimx = 5, dimy =2 , dimcat=3)
  expect_error(
    PlotTriangles4Categories(data = data1),
    paste0("Parameter 'data' should contain a dimcat dimension with length equals
      to two or four as only two or four categories can be plotted"))
  
  data1 <- runif(min = -1, max = 1, n = 30)
  data1[5:10] <- NA
  dim(data1) <- c(dimx = 5, dimy =3 , dimcat=2)
  expect_error(
    PlotTriangles4Categories(data = data1),
    paste0("Parameter 'data' cannot contain NAs."))
  
  data1 <- runif(min = -1, max = 1, n = 30)
  dim(data1) <- c(dimx = 5, dimy =3 , dimcat=2)
  expect_error(
    PlotTriangles4Categories(data = data1,sig_data = 0.5),
    paste0("Parameter 'sig_data' array must be logical."))
  
  expect_error(
    PlotTriangles4Categories(data = data1, sig_data = TRUE),
    paste0("Parameter 'sig_data' must be an array with three dimensions."))
  
  sig1 <- array(TRUE, dim=c(5,2,3))
  expect_error(
    PlotTriangles4Categories(data = data1, sig_data = sig1),
    paste0("Parameter 'sig_data' must be an array with the same dimensions as 'data'"))
  
  sig1 <- array(TRUE, dim= c(5,3,2))
  dim(sig1) <- c(dimy = 5, dimx =3 , dimcat=2)
  expect_error(
    PlotTriangles4Categories(data = data1, sig_data = sig1),
    paste0("Parameter 'sig_data' must be an array with the same named dimensions as 'data'."))
  
  data1 <- runif(min = -1, max = 1, n = 30)
  dim(data1) <- c(dimx = 5, dimy =3 , dimcat=2)
  expect_error(
    PlotTriangles4Categories(data = data1, lab_legend = c('1','2','3')),
    paste0("Parameter 'lab_legend' should contain two or four names."))

expect_error(
    PlotTriangles4Categories(data = data1, brks=c(-1,0,1),cols=c('blue','red','black')),
    paste0("The length of the parameter 'brks' must be one more than 'cols'."))


  
})
