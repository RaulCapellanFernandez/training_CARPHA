##############################################

# dat1
data1 <- 1 : 20
dim(data1) <- c(time = 20)
data1 <- list(data = data1)
class(data1) <- 's2dv_cube'

indices1 <- c(rep(1,5), rep(2,5), rep (3, 5), rep(4, 5))
output1 <- matrix(data1$data, nrow = 5, ncol = 4)
output1 <- matrix(data1$data, nrow = 5, ncol = 4)
names(dim(output1)) <- c('time', 'monthly')
output1 <- list(data = output1) 
output1$dims <- dim(output1$data)
output1$coords <- list(time = 1:5, monthly = 1:4)
attr(output1$coords$time, 'indices') <- TRUE
attr(output1$coords$monthly, 'indices') <- TRUE
class(output1) <- 's2dv_cube'

exp_cor <- 1 : 20
dim(exp_cor) <- 20
exp_cor <- list(data = exp_cor)
class(exp_cor) <- 's2dv_cube'

# dat2
output2 <- matrix(data1$data, nrow = 5, ncol = 4)
names(dim(output2)) <- c('time', 'index')
output2 <- list(data = output2)
output2$dims <- dim(output2$data)
output2$coords <- list(time = 1:5, index = 1:4)
attr(output2$coords$time, 'indices') <- TRUE
attr(output2$coords$index, 'indices') <- TRUE
class(output2) <- 's2dv_cube'

time2 <- c(seq(ISOdate(1903, 1, 1), ISOdate(1903, 1, 4), "days"),
          seq(ISOdate(1903, 2, 1), ISOdate(1903, 2, 4), "days"),
          seq(ISOdate(1904, 1, 1), ISOdate(1904, 1, 2), "days"))
attrs <- list(Dates = time2)
data2 <- list(data = data1$data, attrs = attrs)
class(data2) <- 's2dv_cube' 

# dat3
time3 <- c(seq(ISOdate(1903, 1, 1), ISOdate(1903, 1, 8), "days"),
           seq(ISOdate(1903, 2, 1), ISOdate(1903, 2, 8), "days"),
           seq(ISOdate(1904, 1, 1), ISOdate(1904, 1, 4), "days"))
attrs <- list(Dates = time3)
data3 <- list(data = data1$data, attrs = attrs)
class(data3) <- 's2dv_cube'
output3 <- c(data3$data, rep(NA, 4))
dim(output3) <- c(time = 8, monthly = 3)
result3 <- data3
result3$data <- output3
result3$dims <- dim(result3$data)
result3$coords <- list(time = 1:8, monthly = 1:3)
attr(result3$coords$time, 'indices') <- TRUE
attr(result3$coords$monthly, 'indices') <- TRUE
# dat4
data4 <- list(data = array(rnorm(10), dim = c(sdate = 2, lon = 5)))
class(data4) <- 's2dv_cube'

##############################################

test_that("1. Input checks", {
  expect_error(
    CST_SplitDim(data = 1),
    paste0("Parameter 'data' must be of the class 's2dv_cube'.")
  )
  expect_error(
    CST_SplitDim(data = data1),
    paste0("Parameter 'freq' must be a integer number indicating ", 
           " the length of each chunk.")
  )
  expect_error(
    CST_SplitDim(data = data2),
    paste0("Parameter 'indices' has different length of parameter data ",
           "in the dimension supplied in 'split_dim'.")
  )
  expect_error(
    CST_SplitDim(data = exp_cor, freq = 5),
    "Parameter 'data' must have dimension names."
  )
  expect_error(
    CST_SplitDim(data = data4),
    "Parameter 'split_dims' must be one of the dimension names in parameter 'data'."
  ) 
})

##############################################

test_that("2. Output checks", {
  expect_equal(
    CST_SplitDim(data = data1, indices = indices1), 
    output1
  )
  expect_equal(
    CST_SplitDim(data = data1, freq = 5), 
    output2
  )
  expect_equal(
    CST_SplitDim(data = data3), 
    result3
  )
})

##############################################

test_that("3. Output checks: sample data", {
  output <- lonlat_temp$exp$data
  output <- abind(output[, , , 1, ,], output[, , , 2, ,], output[, , , 3, ,], along = 5)
  dim(output) <- c(dataset = 1, member = 15, sdate = 6, ftime = 1, 
                   lat = 22, lon = 53, monthly = 3)
  result <- lonlat_temp$exp
  result$data <- output
  result$attrs$Dates <- s2dv::Reorder(result$attrs$Dates, c('sdate', 'ftime'))
  dim(result$attrs$Dates) <- c(ftime = 1, sdate = 6, monthly = 3)
  result$dims <- c(dataset = 1, member = 15, sdate = 6, ftime = 1, lat = 22, 
                   lon = 53, monthly = 3)
  attributes(result$attrs$Dates)$end <- NULL
  result$coords$ftime <- 1 
  result$coords$monthly <- 1:3
  attr(result$coords$ftime, 'indices') <- TRUE
  attr(result$coords$monthly, 'indices') <- TRUE
  expect_equal(
    CST_SplitDim(data = lonlat_temp$exp, split_dim = 'ftime', ftime_dim = 'ftime'),
    result
  )
  expect_equal(
    dim(CST_SplitDim(data = lonlat_temp$exp, split_dim = 'member', 
                     freq = 5)$data),
    c(dataset = 1, member = 5, sdate = 6, ftime = 3, lat = 22, 
      lon = 53, index = 3)
  )
  expect_warning(
    CST_SplitDim(data = lonlat_temp$exp, split_dim = 'member', freq = 5, 
                 new_dim_name = c('a', 'b')),
    paste0("Parameter 'new_dim_name' has length greater than 1 ",
           "and only the first elemenst is used.")
  )
  expect_error(
    CST_SplitDim(data = lonlat_temp$exp, split_dim = 'member', freq = 5, 
                 new_dim_name = 3), 
    "Parameter 'new_dim_name' must be character string"
  )
  expect_equal(
    dim(CST_SplitDim(data = lonlat_temp$exp, split_dim = 'member', 
        freq = 5, new_dim_name = 'wt')$data),
    c(dataset = 1, member = 5, sdate = 6, ftime = 3, lat = 22,
      lon = 53, wt = 3)
  )
})

##############################################

test_that("4. Output checks II", {
  res <- CST_SplitDim(lonlat_prec_st, indices = lonlat_prec_st$attrs$Dates[,1],
                      split_dim = 'sdate', freq = 'year', return_indices = T)
  expect_equal(
    names(res),
    c('data', 'indices')
  )
  expect_equal(
    res$dims,
    dim(res$data)
  )
  expect_equal(
    all(names(dim(res$data$attrs$Dates)) %in% names(res$data$dims)),
    TRUE
  )
})
