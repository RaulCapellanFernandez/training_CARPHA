##############################################
test_that("basic use case", {
  index_weight <- 1 : (3 * 3)
  dim(index_weight) <- c(sdate = 3, member = 3)
  pdf_weight <- 1 : (3 * 2)
  dim(pdf_weight) <- c(sdate = 3, statistic = 2)
  
  result <- array(c(0.4808867, 0.4306591, 0.4017633, 
                    0.3629923, 0.3597167, 0.3545549,
                    0.1561210, 0.2096243, 0.2436818), 
                  dim = c(sdate = 3, member = 3))
  
  expect_equal(BEI_Weights(index_weight, pdf_weight), result, tolerance=1e-4)
  
})

test_that("Sanity checks", {
  expect_error(
    BEI_Weights(index_weight, pdf_weight, time_dim_name = 1),
    paste0("Parameter 'time_dim_name' must be a character string ",
           "indicating the name of the temporal dimension."))
  
  expect_error(
    BEI_Weights(index_weight = 1),
    "Parameter 'index_weight' must be an array.")
  
  index_weight <- 1 : (3 * 3)
  dim(index_weight) <- c(sdate = 3, member = 3)
  expect_error(
    BEI_Weights(index_weight, pdf_weight = 1),
    "Parameter 'pdf_weight' must be an array.")
  
  index_weight <- 1 : (3 * 3)
  dim(index_weight) <- c(3, 3)
  pdf_weight <- 1 : (3 * 2)
  dim(pdf_weight) <- c(3, 2)
  
  expect_error(
    BEI_Weights(index_weight, pdf_weight),
    paste0("Parameters 'index_weight' and 'pdf_weight'",
           " should have dimmension names."))
  
  index_weight <- 1 : (3 * 3)
  dim(index_weight) <- c(time= 3, season = 3)
  pdf_weight <- 1 : (3 * 2)
  dim(pdf_weight) <- c(time = 3, statistic = 2)
  expect_error(
    BEI_Weights(index_weight, pdf_weight),
    "Parameter 'index_weight' must have dimension 'member'.")
  
  index_weight <- 1 : (3 * 3)
  dim(index_weight) <- c(time= 3, member = 3)
  pdf_weight <- 1 : (3 * 2)
  dim(pdf_weight) <- c(time = 3, season = 2)
  expect_error(
    BEI_Weights(index_weight, pdf_weight),
    "Parameter 'pdf_weight' must have dimension 'statistic'.")
  
  index_weight <- 1 : (3 * 3)
  dim(index_weight) <- c(time= 3, member = 3)
  pdf_weight <- 1 : 2
  dim(pdf_weight) <- c(statistic = 2)
  expect_error(
    BEI_Weights(index_weight, pdf_weight),
    "Parameter 'pdf_weight' must have temporal dimension.")
  
  index_weight <- 1 : 3
  dim(index_weight) <- c(member = 3)
  pdf_weight <- 1 : 4
  dim(pdf_weight) <- c(time = 2, statistic = 2)
  expect_error(
    BEI_Weights(index_weight, pdf_weight),
    "Parameter 'index_weight' must have temporal dimension.")
  
  index_weight <- 1 : 12
  dim(index_weight) <- c(time= 4, member = 3)
  pdf_weight <- 1 : 4
  dim(pdf_weight) <- c(time = 2, statistic = 2)
  expect_error(
    BEI_Weights(index_weight, pdf_weight),
    "Length of temporal dimension of parameters must be equal")
  
  index_weight <- 1 : (3 * 3)
  dim(index_weight) <- c(sdate = 3, member = 3)
  pdf_weight <- 1 : (3 * 3)
  dim(pdf_weight) <- c(sdate = 3, statistic = 3)
  expect_error(
    BEI_Weights(index_weight, pdf_weight),
    paste0("Length of dimension 'statistic' ",
           "of the parameter 'pdf_weight' must be equal to 2."))

})  
