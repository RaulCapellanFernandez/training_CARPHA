library(testthat)
library(CSTools)
library(startR)

test_check("CSTools")

