#----------------------------------------------------------------------------
# Author: An-Chi Ho
# Date: 8th Oct 2021
#
# This script shows how to load irregular grid data by Start(), then regrid it
# by s2dv::CDORemap in the workflow. It is a solution before Start() can deal
# with irregular regridding directly.
#----------------------------------------------------------------------------

library(startR)
library(s2dv)

path <- paste0('/esarchive/exp/CMIP6/dcppA-hindcast/CMCC-CM2-SR5/',
               'DCPP/CMCC/CMCC-CM2-SR5/dcppA-hindcast/$member$/Omon/$var$/gn/v20200101/',
               '$var$_*_s$sdate$-$member$_gn_$aux$.nc')

data <- Start(dataset = path,
              var = 'tos',
              sdate = c('1960', '1961'),
              aux = 'all',
              aux_depends = 'sdate',
              x = indices(2:361), # remove two indices to avoid white strips 
              y = indices(2:291), # remove two indices to avoid white strips 
              time = indices(1:12),
              member = 'r1i1p1f1',
              return_vars = list(nav_lat = NULL, nav_lon = NULL),
              retrieve = F)

attr(data, 'Dimensions')
#dataset     var   sdate     aux       x       y    time  member 
#      1       1       2       1     360     290      12       1 
dim(attr(data, 'Variables')$common$nav_lon)
#  x   y 
#362 292 
dim(attr(data, 'Variables')$common$nav_lat)
#  x   y 
#362 292 

func_regrid <- function(data) {
  lons <- attr(data, 'Variables')$common$nav_lon
  lats <- attr(data, 'Variables')$common$nav_lat
  data <- s2dv::CDORemap(data, lons[2:361, 2:291], lats[2:361, 2:291],
                         grid = 'r360x180', method = 'bil', crop = FALSE)
  lons_reg <- data[['lons']]
  lats_reg <- data[['lats']]
  return(list(data = data[[1]], lats = lats_reg, lons = lons_reg))
}

step <- Step(fun = func_regrid,
             target_dims = list(data = c('x', 'y')),
             output_dims = list(data = c('lon', 'lat'), 
                                lats = 'lat', lons = 'lon'),
             use_attributes = list(data = "Variables"))
wf <- AddStep(data, step)

res <- Compute(workflow = wf$data,
               chunks = list(sdate = 2, time = 2))

names(res)
#[1] "data" "lats" "lons"
dim(res$data)
#    lon     lat dataset     var   sdate     aux    time  member 
#    360     180       1       1       2       1      12       1 
dim(res$lons)
#    lon dataset     var   sdate     aux    time  member 
#    360       1       1       2       1      12       1 
dim(res$lats)
#    lat dataset     var   sdate     aux    time  member 
#    180       1       1       2       1      12       1 

PlotEquiMap(drop(res$data)[ , , 1, 1],
            lon = drop(res$lons)[, 1, 1],
            lat = drop(res$lats)[, 1, 1])

# Plot Layout for sdate = 1 all the time steps
var <- Reorder(drop(res$data)[, , 1, ], c(3, 1, 2))
PlotLayout(PlotEquiMap, c('lon', 'lat'), var = var, 
           lon = drop(res$lons)[, 1, 1], lat = drop(res$lats)[, 1, 1])

