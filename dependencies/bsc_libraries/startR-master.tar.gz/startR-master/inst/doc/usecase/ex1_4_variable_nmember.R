# This code shows that the number of members could depend on the start date
# and the order of start dates impacts the length of member dimension.
# See FAQ 10 [The members depends on the start date](https://earth.bsc.es/gitlab/es/startR/-/blob/master/inst/doc/faq.md#10-the-number-of-members-depends-on-the-start-date) and 
# FAQ 21[Retrieve the complete data when the dimension length varies among files](https://earth.bsc.es/gitlab/es/startR/-/blob/master/inst/doc/faq.md#21-retrieve-the-complete-data-when-the-dimension-length-varies-among-files)
# For more explanation.

library(startR)

path_list <- list(list(name = 'system5',   
  path = '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'))
sdates_exp <- c('19991101', '19990901')
data_Nov_Sep <- Start(dat = path_list,
                      var = 'psl',
                      member = 'all',
                      sdate = sdates_exp,
                      time = indices(1),
                      latitude = values(list(0, 20)),
                      latitude_reorder = Sort(),
                      longitude = values(list(0, 5)),
                      longitude_reorder = CircularSort(0, 360),
                      synonims = list(latitude = c('lat', 'latitude'),
                                      longitude = c('lon', 'longitude'),
                                      member = c('ensemble', 'realization')),
                      retrieve = TRUE)
# 51 members 
dim(data_Nov_Sep)
#      dat       var    member     sdate      time  latitude longitude 
#        1         1        51         2         1        71        19 

apply(data_Nov_Sep, 4, function(x){sum(is.na(x))})
#[1]     0 35074
# --> 26*71*19 = 35074 missing values for the second start date.


#-------- exchange the order of sdate -------------
sdates_exp <- c('19990901', '19991101')
data_Sep_Nov <- Start(dat = path_list,
                      var = 'psl',
                      member = 'all',
                      sdate = sdates_exp,
                      time = indices(1),
                      latitude = values(list(0, 20)),
                      latitude_reorder = Sort(),
                      longitude = values(list(0, 5)),
                      longitude_reorder = CircularSort(0, 360),
                      synonims = list(latitude = c('lat', 'latitude'),
                                      longitude = c('lon', 'longitude'),
                                      member = c('ensemble', 'realization')),
                      retrieve = TRUE)

# Only 25 members available
dim(data_Sep_Nov)
#      dat       var    member     sdate      time  latitude longitude 
#        1         1        25         2         1        71        19 

apply(data_Sep_Nov, 4, function(x){sum(is.na(x))})
#[1] 0 0
#--> No missing value.

#-----------Use 'largest_dims_length' to get full members -------------
data_largest_len <- Start(dat = path_list,
                      var = 'psl',
                      member = 'all',
                      largest_dims_length = c(member = 51), #TRUE,
                      sdate = sdates_exp,
                      time = indices(1),
                      latitude = values(list(0, 20)),
                      latitude_reorder = Sort(),
                      longitude = values(list(0, 5)),
                      longitude_reorder = CircularSort(0, 360),
                      synonims = list(latitude = c('lat', 'latitude'),
                                      longitude = c('lon', 'longitude'),
                                      member = c('ensemble', 'realization')),
                      retrieve = TRUE)

dim(data_largest_len)
#      dat       var    member     sdate      time  latitude longitude 
#        1         1        51         2         1        71        19 

# Switch the sdate order of data_largest_len and compare to the first data
all.equal(as.vector(data_largest_len[, , , 2:1, , , ]),
          as.vector(data_Nov_Sep),check.attribtes = F)
#[1] TRUE
