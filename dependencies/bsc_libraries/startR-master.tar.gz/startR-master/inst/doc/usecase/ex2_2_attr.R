#-----------------------------------------------------------------
# Function using attributes of the data e.g.: latitudinal correction
# ------------------------------------------------------------------
library(startR)
  repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
  data <- Start(dat = repos,
                var = 'tas',
                sdate = c('20170101', '20180101'),
                ensemble = indices(1:20),
                time = 'all',
                latitude = 'all',
                longitude = indices(1:40),
                return_vars = list(latitude = 'dat', longitude = 'dat', time = 'sdate'),
                retrieve = FALSE)
  funp <- function(x) {
            lat = attributes(x)$Variables$dat1$latitude
            weight = sqrt(cos(lat * pi / 180))
            corrected = Apply(list(x), target_dims = "latitude",
                              fun = function(x) {x * weight})
          }
  
  
  step2 <- Step(fun = funp,
               target_dims = 'latitude',
               output_dims = 'latitude',
               use_attributes = list(data = "Variables"))
  wf2 <- AddStep(data, step2)
  
## locally
library(multiApply)
  res2 <- Compute(workflow = wf2,
              chunks = list(ensemble = 2,
                            sdate = 2))
  
  dim(res2$output1)
  head(res2$output1)
  summary(res2$output1)
# ------------------------------------------------------------------
# Output:
#> dim(res2$output1)
# latitude       dat       var     sdate  ensemble      time longitude
#      640         1         1         2        20         7        40
#> head(res2$output1)
#[1] 15.22683 23.09543 28.94978 33.82982 38.11695 41.99680
#> summary(res2$output1)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
#  13.19  169.60  237.60  217.90  284.10  305.10
# -----------------------------------------------------------------

## on Power9
#-----------modify according to your personal info---------
  queue_host = 'cte-power'   #your own host name for power9
  temp_dir =  '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir = '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res2_P <- Compute(wf2,
                    chunks = list(ensemble = 20,
                                  sdate = 2),
                    threads_load = 2,
                    threads_compute = 4,
                    cluster = list(queue_host = queue_host,  #your own host name for power9
                                   queue_type = 'slurm',
                                   cores_per_job = 2,
                                   temp_dir = temp_dir,
                                   r_module = 'R/3.6.1-foss-2018b',
                                   #extra_queue_params = list('#SBATCH --mem-per-cpu=3000'),
                                   polling_period = 10,
                                   job_wallclock = '01:00:00',
                                   max_jobs = 40,
                                   bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir,  #your own local directory
                 wait = TRUE)

## on Nord3v2
#-----------modify according to your personal info---------
  queue_host = 'nord4'   #your own host name for power9
  temp_dir =  '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir = '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res2_Nord <- Compute(wf2,
                    chunks = list(ensemble = 20,
                                  sdate = 2),
                    threads_load = 2,
                    threads_compute = 4,
                    cluster = list(queue_host = queue_host,  #your own host name for power9
                                   queue_type = 'slurm',
                                   cores_per_job = 2,
                                   temp_dir = temp_dir,
                                   polling_period = 10,
                                   job_wallclock = '01:00',
                                   max_jobs = 40,
                                   bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir,  #your own local directory
                 wait = TRUE)
