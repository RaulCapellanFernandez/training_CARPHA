#---------------------------------------------------------------------
# This script shows you how to use reorder function (Sort, CircularSort)
# to get the desired longitude and latitude region.

# Note that the information of the lon/lat system in the original file is 
# provided in order to illustrate a clearer picture, but it doesn't affect 
# the results as long as the reorder functions are used.

# Also, whether transformation is used or not, the range results remain the same.

# See faq.md How-to-#11 for more explanation.

#---------------------------------------------------------------------

library(startR)

#----------------------------
# CASE 1: 
# Original file: lon [0:360]; lat [90:-90]
# Desired region: lon [-10, 10] in [-180, 180] system; lat [-20, 20] from south to north
# transformation: No
#----------------------------
# tips: 
# 1. Use 'latitude_reorder = Sort()' to sort latitude from south to north. 
#    The default of the hidden parameter 'decreasing' is TRUE.
# 2. Use 'longitude_reorder = CircularSort(-180, 180). It helps put the longitude values 
#    in [-180:180] system, so you can get the continuous region across 0 degree.
# 3. With reorder functions, the original file range does not affect the results.
#----------------------------

path_exp <- paste0('/esarchive/exp/ecmwf/system5_m1/daily_mean/',
                   '$var$_f6h/$var$_$sdate$.nc')
var <- 'psl'
sdate <- '19821201'

lons.min <- -10
lons.max <- 10
lats.min <- -20
lats.max <- 20


res <- Start(dat = path_exp,
             var = var,
             ensemble = 'first',
             sdate = sdate,
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)

# Check the longitude and latitude
as.vector(attr(res, 'Variables')$dat1$latitude)
# [1] -19.8126401 ...... [142] 19.8126401
as.vector(attr(res, 'Variables')$dat1$longitude)
# [1] -10.0000000 ...... [73] 10.0000000



#----------------------------
# CASE 2:
# Original file: lon [0:360]; lat [90:-90]
# Desired region: lon [-10, 10] in [-180, 180] system; lat [20, -20] from north to south
# transformation: Yes, to 'r360x181'
#----------------------------
# tips:
# 1. Use 'latitude_reorder = Sort(decreasing = TRUE)' to sort latitude from north to south.
# 2. Use 'longitude_reorder = CircularSort(-180, 180). It helps put the longitude values
#    in [-180:180] system, so you can get the continuous region across 0 degree.
# 3. With the usage of reorder functions, transformation does not affect the results.
# 4. With reorder functions, the original file range does not affect the results.
#----------------------------

path_exp <- paste0('/esarchive/exp/ecmwf/system5_m1/daily_mean/',
                   '$var$_f6h/$var$_$sdate$.nc')
var <- 'psl'
sdate <- '19821201'

lons.min <- -10
lons.max <- 10
lats.min <- 20
lats.max <- -20

res <- Start(dat = path_exp,
             var = var,
             ensemble = 'first',
             sdate = sdate,
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con'), 
             transform_vars = c('longitude', 'latitude'),
             synonims = list(latitude=c('lat', 'latitude'),
                             longitude=c('lon', 'longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)

# Check the longitude and latitude
as.vector(attr(res, 'Variables')$dat1$latitude)
# [1] 20 ...... [41] -20
as.vector(attr(res, 'Variables')$dat1$longitude)
# [1] -10 ...... [21] 10



#----------------------------
# CASE 3:
# Original file: lon [-180:180]; lat [90:-90]
# Desired region: lon [300, 320] in [0, 360] system; lat [-10, -20] from north to south
# transformation: Yes, to 'r360x181'
#----------------------------
# tips:
# 1. Use 'latitude_reorder = Sort(decreasing = TRUE)' to sort latitude from north to south.
# 2. Use 'longitude_reorder = CircularSort(0, 360). It helps put the longitude values
#    in [-180:180] system, so you can get the continuous region across 0 degree.
# 3. With the usage of reorder functions, transformation does not affect the results.
# 4. With reorder functions, the original file range does not affect the results.
#----------------------------

path_exp <- paste0('/esarchive/recon/ecmwf/era5/original_files/',
                   'reorder/daily_mean/$var$/$var$_$sdate$.nc')
var <- 'tas'
sdate <- '199212'

lons.min <- 300
lons.max <- 320
lats.min <- -10
lats.max <- -20

res <- Start(dat = path_exp,
             var = var,
             sdate = sdate,
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con'),
             transform_vars = c('longitude', 'latitude'),
             synonims = list(latitude=c('lat', 'latitude'),
                             longitude=c('lon', 'longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)

# Check the longitude and latitude
as.vector(attr(res, 'Variables')$dat1$latitude)
# [1] -10 ...... [11] -20
as.vector(attr(res, 'Variables')$dat1$longitude)
# [1] 300 ...... [21] 320

