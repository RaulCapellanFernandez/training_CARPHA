# LOADING GRID POINT DATA
# This code shows how to load grid point data
# given lat and lon values Start will load the nearest grid point
# and how to create a grid point dimension. 
# See also FAQ 13 [How to load grid point data](/inst/doc/faq.md)

library(startR)

lats <- c(51.30760, 51.97100, 52.10000, 54.01486, 55.00690, 55.19500, 51.94355,
          53.51917, 46.95580, 53.12750, 50.92847, 52.16630, 53.40360, 55.35277,
          55.11070, 62.90566, 67.36186)
lons <- c(4.519800, 4.926000, -0.416700, 6.587639, 13.154200, 7.158000, 1.922200,
          10.102861, 16.652200, 0.436100, 6.219629, 14.122600, 6.352800, -7.332018,
          36.597700, 27.653497, 26.637833)
data <- Start(dat = '/esarchive/exp/ecmwf/system5c3s/monthly_mean/$var$_f6h/$var$_$sdate$.nc',
              var = 'sfcWind',
              sdate = '19931101',
              ensemble = indices(1),
              time = 'all',
              latitude = values(lats),
              longitude = values(lons),
              pattern_dims = 'dat',
              synonims = list(latitude = c('lat', 'latitude'),
                              longitude = c('lon', 'longitude')),
              return_vars = list(time = NULL,
                                 latitude = 'dat',
                                 longitude = 'dat'),
              retrieve = TRUE)

# The warning is reporting:
#5: ! Warning: Numeric selectors have been provided for a dimension defined along a
#!   numeric variable, but no exact match found for all the selectors.
#!   Taking the index of the nearest values. 

# The attributes shows the values loaded,
# that has lower length since there are repeated values:
lon <- as.vector(attributes(data)$Variables$dat1$lon)
#[1]  5  0  7 13  2 10 17  6 14 37 28 27
lat <- as.vector(attributes(data)$Variables$dat1$lat)
#[1] 51 52 54 55 47 53 63 67

# while the data loaded has the same length of the requested values:
dim(data)
#      dat       var     sdate  ensemble      time  latitude longitude 
#        1         1         1         1         8        17        17 


# The real retrieved values can be calculated:
lats_retrieved <- unlist(lapply(lats, function(x) {lat[which(abs(lat - x) == min(abs(lat - x)))]}))
#[1] 51 52 52 54 55 55 52 54 47 53 51 52 53 55 55 63 67
lons_retrieved <- unlist(lapply(lons, function(x) {lon[which(abs(lon - x) == min(abs(lon - x)))]}))
# [1]  5  5  0  7 13  7  2 10 17  0  6 14  6  0 37 28 27

# The desired information is the time series of the grid points in the list:
gridpoint <- lapply(1:length(lats), function(x) {c(lats_retrieved[x], lons_retrieved[x])})

# The latitude and longitude dimension in data can be merged to the corresponding gridpoint dimension:
data_gridpoint <- unlist(lapply(1:17, function(x) {data[,,,,,x,x]}))
dim(data_gridpoint) <- c(dim(data)[1:5], gridpoint = 17)

plot(1:8, data_gridpoint[1,1,1,1,,4], main = paste("lat", gridpoint[[4]][1], ", lon" , gridpoint[[4]][2]), 
     bty = "n", type = "l", ylab = 'sfcWind (m/s)',
     xlab = 'forecast time (month)')
lines(1:8, data[1,1,1,1,,4,4], type = 'p', col = 'green')

# Comparison against independet loading tool:
library(ncdf4)
f <- nc_open('/esarchive/exp/ecmwf/system5c3s/monthly_mean/sfcWind_f6h/sfcWind_19931101.nc')
ncvar_get(f, varid = 'latitude') 
ncvar_get(f, varid = 'longitude')
dat <- ncvar_get(f, varid = 'sfcWind', start = c(8, 37, 1, 1), count = c(1, 1, 1, 8)) 	
nc_close(f)
lines(1:8, dat, col = 'blue', lty = 3, lwd = 2)

all(dat == data_gridpoint[1,1,1,1,,4])

dat
#[1]  8.080409  9.172594 11.310596 11.145370  9.234114  6.885310  5.471250
#[8]  5.467621
