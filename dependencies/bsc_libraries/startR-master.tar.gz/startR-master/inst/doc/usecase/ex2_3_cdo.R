# --------------------------------------------------------------
# Function doing regridding CDO (e.g.: s2dv::CDORemap)
#---------------------------------------------------------------
library(startR)
  repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
  data <- Start(dat = repos,
                var = 'tas',
                sdate = c('20170101', '20180101'),
                ensemble = indices(1:2),
                time = 'all',
                latitude = 'all',
                longitude = 'all',
                return_vars = list(latitude = 'dat', longitude = 'dat', time = 'sdate'),
                retrieve = FALSE)
  
  
  fun_deb2 <- function(x) {
               lons_data = as.vector(attr(x, 'Variables')$dat1$longitude)
               lats_data = as.vector(attr(x, 'Variables')$dat1$latitude)
               resgrid = "r360x180"   # prlr
               r <- s2dv::CDORemap(x, lons_data, lats_data, resgrid,
                                   'bil', crop = FALSE, force_remap = TRUE)[[1]]
               return(r)
  }
  
  step3 <- Step(fun = fun_deb2,
               target_dims = c('latitude','longitude'),
               output_dims = c('latitude', 'longitude'),
               use_attributes = list(data = "Variables"))
  wf3 <- AddStep(data, step3)
  
## locally
  res3 <- Compute(workflow = wf3,
              chunks = list(ensemble = 2,
                            sdate = 2))
  dim(res3$output1)
  head(res3$output1)
  summary(res3$output1)

# --------------------------------------------------------------------
# Output:
#> dim(res3$output1)
# latitude longitude       dat       var     sdate  ensemble      time
#      180       360         1         1         2         2         7
#> head(res3$output1)
#[1] 245.2156 244.6700 245.1513 244.7413 244.4198 245.0041
#> summary(res3$output1)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
#  206.3   269.2   283.3   278.8   296.4   314.2
# --------------------------------------------------------------------

## on Power9
#-----------modify according to your personal info---------
  queue_host = 'cte-power'   #your own host name for power9
  temp_dir =  '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir = '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res3_P <- Compute(wf3,
                    chunks = list(ensemble = 2,
                                  sdate = 2),
                    threads_load = 2,
                    threads_compute = 4,
                    cluster = list(queue_host = queue_host, #your own host name for power9
                                   queue_type = 'slurm',
                                   cores_per_job = 1,
                                   temp_dir = temp_dir,
                                   r_module = 'R/3.5.0-foss-2018b',
                                   CDO_module = 'CDO/1.9.5-foss-2018b',
                       extra_queue_params = list('#SBATCH --mem-per-cpu=3000'),
                                   polling_period = 100,
                                   job_wallclock = '01:00:00',
                                   max_jobs = 4,
                                   bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir,  #your own local directory
                 wait = TRUE)


## on Nord3v2
#-----------modify according to your personal info---------
  queue_host = 'nord4.bsc.es'  
  temp_dir =  '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir = '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res3_N <- Compute(wf3,
                    chunks = list(ensemble = 2,
                                  sdate = 2),
                    threads_load = 2,
                    threads_compute = 4,
                    cluster = list(queue_host = queue_host, #your own host name for power9
                                   queue_type = 'slurm',
                                   cores_per_job = 1,
                                   temp_dir = temp_dir,
                                   CDO_module = 'CDO',
                                   polling_period = 100,
                                   job_wallclock = '01:00',
                                   max_jobs = 4,
                                   bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir,  #your own local directory
                 wait = TRUE)
