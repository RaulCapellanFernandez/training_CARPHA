# -----------------------------------------------------------------
# Function working on time dimension e.g.: Season
# ------------------------------------------------------------------
library(startR)  
  repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
  data <- Start(dat = repos,
                var = 'tas',
                sdate = c('20170101', '20180101'),
                ensemble = indices(1:20),
                time = 'all',
                latitude = 'all',
                longitude = indices(1:40),
                return_vars = list(latitude = 'dat', longitude = 'dat', time = 'sdate'),
                retrieve = FALSE)
  
  fun_spring <- function(x) {
      y <- s2dv::Season(x,  time_dim = 'time', monini = 1, moninf = 3, monsup = 5)
      return(y)
  }
  
  step1 <- Step(fun = fun_spring,
               target_dims = c('var', 'time'),
               output_dims = c('var', 'time'))
  
  wf1 <- AddStep(data, step1)
  
## locally
  res1 <- Compute(wf1,
              chunks = list(ensemble = 2,
                            sdate = 2))
  
  dim(res1$output1)
  str(res1$output1)
  summary(res1$output1)
# -----------------------------------------------------------------
#> dim(res1$output1)
#     time       dat       var     sdate  ensemble  latitude longitude 
#        1         1         1         2        20       640        40 
#> str(res1$output1)
# num [1, 1, 1, 1:2, 1:20, 1:640, 1:40] 260 257 257 260 257 ...
#> summary(res1$output1)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
#  220.5   273.3   282.7   279.9   295.6   306.8 
# ----------------------------------------------------------------

## on Power9
#-----------modify according to your personal info---------
  queue_host <- 'cte-power'   #your own host name for power9
  temp_dir <- '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir <- '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res <- Compute(wf1,
                 chunks = list(ensemble = 20,
                               sdate = 2),
                 threads_load = 2,
                 threads_compute = 4,
                 cluster = list(queue_host = queue_host,  
                                queue_type = 'slurm',
                                cores_per_job = 2,
                                temp_dir = temp_dir,
                                r_module = 'R/3.6.1-foss-2018b',
                                polling_period = 10,
                                job_wallclock = '01:00:00',
                                max_jobs = 40,
                                bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir,  
                 wait = TRUE)


## on Nord3 with ecFlow
#-----------modify according to your personal info---------
  queue_host <- 'nord4'
  temp_dir <-  '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir <- '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res <- Compute(wf1,
                 chunks = list(ensemble = 20,
                               sdate = 2),
                 threads_load = 2,
                 threads_compute = 4,
                 cluster = list(queue_host = queue_host,
                                queue_type = 'slurm',
                                cores_per_job = 2,
                                temp_dir = temp_dir,
                                polling_period = 10,
                                job_wallclock = '01:00',
                                max_jobs = 40,
                                bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir,
                 wait = TRUE)



## on Nord3 with Autosubmit
#-----------modify according to your personal info---------
  hpc_user <- "bsc32xxx"
  expid <- "xxxx" # autosubmit exp id; can be NULL
  autosubmit_suite_dir <- "/home/Earth/<user_id>/startR_local_autosubmit/"
#------------------------------------------------------------
  res <- Compute(wf1, 
                 chunks = list(ensemble = 20, sdate = 2),
                 threads_load = 2, 
                 threads_compute = 4,
                 cluster = list(
                   queue_host = 'nord3', 
                   r_module = "R/4.1.2-foss-2019b",
                   autosubmit_module = 'autosubmit/4.0.0b-foss-2015a-Python-3.7.3',
                   cores_per_job = 2,
                   job_wallclock = '01:00:00',
                   max_jobs = 40,
                   polling_period = 10,
                   extra_queue_params = list('#SBATCH --constraint=medmem', '#SBATCH --exclusive'),
                   expid = NULL,
                   hpc_user = hpc_user
                 ),
                 workflow_manager = 'autosubmit',
                 autosubmit_suite_dir = autosubmit_suite_dir,
                 autosubmit_server = NULL, #'bscesautosubmit01',
                 wait = TRUE
                 )
