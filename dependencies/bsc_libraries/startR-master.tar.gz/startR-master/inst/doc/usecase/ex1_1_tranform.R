# ------------------------------------------------------------------
# This script shows you how to do the interpolation in Start(). It also 
# uses s2dv::Load to compare the results, which are identical
# (only tiny difference due to round-up).
#
# The parameters in Start() for interpolation include 'transform', 
# 'transform_extra_cells', 'transform_params', and 'transform_vars'.
# 'transform' is the interpolation function. startR provides 'CDORemapper',
# which is the wrapper function of s2dv::CDORemap.
# 'transform_extra_cells' defines the extra grid points you want to use for 
# interpolation. The default value is 2. 'transform_params' is a list which
# defines the arguments used in 'cdo'. 'transform_vars' is a vector indicating 
# the dimensions to be interpolated.
# ------------------------------------------------------------------

library(startR)

obs_path <- '/esarchive/recon/ecmwf/era5/monthly_mean/$var$_f1h/$var$_$sdate$.nc'
var_name <- 'sfcWind'

lons.min <- 10
lons.max <- 20
lats.min <- 0
lats.max <- 10

#-------------------------
# Start()
#-------------------------
obs <- Start(dat = obs_path,
             var = var_name,
             sdate = '201811',
             time = 'all',
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(longitude = c('lon', 'longitude'),
                             latitude = c('lat', 'latitude')),
             transform = CDORemapper,
             transform_extra_cells = 2,
             transform_params = list(grid = 'r360x181',
                                     method = 'conservative'),
             transform_vars = c('latitude', 'longitude'),
             return_vars = list(time = NULL,
                                latitude = 'dat',
                                longitude = 'dat'),
             retrieve = T)

# -- Result --
dim(obs)
#      dat       var     sdate      time  latitude longitude 
#        1         1         1         1        11        11 
range(obs)
#[1] 1.090472 2.803161
attr(obs, 'Variables')$dat1$longitude
# [1] 10 11 12 13 14 15 16 17 18 19 20
attr(obs, 'Variables')$dat1$latitude
# [1] 10  9  8  7  6  5  4  3  2  1  0
obs[1,1,1,1,1:3,1:2]
#         [,1]     [,2]
#[1,] 2.345519 2.365326
#[2,] 2.219121 1.958319
#[3,] 1.840537 1.386617


#-------------------------
# s2dv::Load()
#-------------------------
library(s2dv)
pobs <- paste0('/esarchive/recon/ecmwf/era5/monthly_mean/',
               '$VAR_NAME$_f1h/$VAR_NAME$_$YEAR$$MONTH$.nc')

obs1 <- Load(var = var_name,
             obs = list(list(path = pobs)),
             sdates = '20181101',
             leadtimemin = 1,
             leadtimemax = 1,
             output = 'lonlat',
             grid = 'r360x181',
             method = 'conservative',
             storefreq = 'monthly',
             latmin = lats.min,
             latmax = lats.max,
             lonmin = lons.min,
             lonmax = lons.max)

# -- Result --
dim(obs1$obs)
#dataset  member   sdate   ftime     lat     lon 
#      1       1       1       1      11      11 
range(obs1$obs)
#[1] 1.0905 2.8032
as.vector(obs1$lon)
# [1] 10 11 12 13 14 15 16 17 18 19 20
as.vector(obs1$lat)
# [1] 10  9  8  7  6  5  4  3  2  1  0
obs1$obs[1,1,1,1,1:3,1:2]
#       [,1]   [,2]
#[1,] 2.3455 2.3653
#[2,] 2.2191 1.9583
#[3,] 1.8405 1.3866

#-----------------------
# Comparison
#-----------------------
diff <- drop(obs) - drop(obs1$obs) 
range(diff)
#[1] -4.965553e-05  4.929314e-05






