#----------------------------------------------------------------------------
# Author: An-Chi Ho
# Date: 11th November 2022
#
# This script shows how to use Start() to load files with different time dimension length
# and reshape the array without undesired NAs. To know more about the usage of parameter
# "merge_across_dims_narm" and "largest_dims_length", check faq.md How-to-26 (https://earth.bsc.es/gitlab/es/startR/-/blob/master/inst/doc/faq.md#26-use-merge-across-dims-narm-to-remove-nas)
#
# The used data is daily data, so the time dimension length is the days in each month. 
# "largest_dims_length = T" needs to be used to tell Start() the different time dimension lengths 
# in each file, and "merge_across_dims_narm = T" can remove the NAs that are added by Start()
# during the reshaping process.
#----------------------------------------------------------------------------

library(startR)

# exp
repos <- paste0('/esarchive/recon/ecmwf/era5/daily_mean/$var$_f1h/$var$_$sdate$.nc')
lons.min <- -10
lons.max <- 30
lats.min <- 30
lats.max <- 60
sdates <- clock::date_format(clock::date_build(2019, 1:12, 1), format = "%Y%m")

data <- Start(dat = repos,
             var = 'tas',
             sdate = sdates,
             time = 'all',
             time_across = 'sdate',
             merge_across_dims = TRUE,  # merge 'time' dim along 'sdate'
             merge_across_dims_narm = TRUE, # remove additional NAs
             largest_dims_length = TRUE,  # to tell Start() that each file has different dim length
             lat = values(list(lats.min, lats.max)),
             lat_reorder = Sort(),
             lon = values(list(lons.min, lons.max)),
             lon_reorder = CircularSort(-180, 180),
             synonims = list(lat = c('lat', 'latitude'), lon = c('lon', 'longitude')),
             return_vars = list(lon = NULL, lat = NULL, time = 'sdate'),
             num_procs = 16,
             retrieve = TRUE)

dim(data)
# dat  var time  lat  lon 
#   1    1  365  107  142 

dim(attr(data, 'Variables')$common$time)
#time 
# 365 

#NOTE: If merge_across_dims_narm = FALSE or largest_dims_length = FALSE, time dimension will 
#      be 372 (= 31 days * 12 months) and NAs will be at the end of each small month, i.e.,
#      60:62 (29-31 Feb), 124 (31 Apr), 186 (31 Jun), 279 (31 Sep), 341 (31 Nov).
