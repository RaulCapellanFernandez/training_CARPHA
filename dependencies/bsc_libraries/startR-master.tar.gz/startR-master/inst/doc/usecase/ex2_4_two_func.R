# --------------------------------------------------------------
# Two functions (e.g.: s2dv::CDORemap and Season)
#---------------------------------------------------------------
library(startR)
  repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
  data <- Start(dat = repos,
                var = 'tas',
                sdate = c('20170101', '20180101'),
                ensemble = indices(1:2),
                time = 'all',
                latitude = 'all',
                longitude = 'all',
                return_vars = list(latitude = 'dat', longitude = 'dat', time = 'sdate'),
                retrieve = FALSE)
  
  fun_deb3 <- function(x) {
               lons_data = as.vector(attr(x, 'Variables')$dat1$longitude)
               lats_data = as.vector(attr(x, 'Variables')$dat1$latitude)
               resgrid = "r360x180"
#               y <- s2dv::Season(x, time_dim = 'time', monini = 1, moninf = 1, monsup = 3)
               y <- apply(x, c(1, 2), s2dv:::.Season, monini = 1, moninf = 1, monsup = 3)
               r <- s2dv::CDORemap(y, lons_data, lats_data, resgrid,
                                  'bil', crop = FALSE, force_remap = TRUE)[[1]]
               return(r)
  }
  
  step4 <- Step(fun = fun_deb3,
               target_dims = c('latitude','longitude', 'time'),
               output_dims = c('latitude', 'longitude'),
               use_attributes = list(data = "Variables"))
  wf4 <- AddStep(list(data = data), step4)
  
## locally
  res4 <- Compute(workflow = wf4,
              chunks = list(ensemble = 2,
                            sdate = 2))

# ------------------------------------------------------------------
# Output:
dim(res4$output1)
# latitude longitude       dat       var     sdate  ensemble
#      180       360         1         1         2         2
head(res4$output1)
#[1] 237.1389 237.2601 238.0882 238.0312 237.7883 238.4835
summary(res4$output1)
#   Min. 1st Qu.  Median    Mean 3rd Qu.    Max.
#  227.3   259.6   280.8   277.1   296.2   306.7
# ------------------------------------------------------------------

## on Power9
#-----------modify according to your personal info-----------
  queue_host = 'cte-power'   #your own host name for power9
  temp_dir =  '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir = '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res4_P <- Compute(wf4,
                    chunks = list(ensemble = 2,
                                  sdate = 2),
                    threads_load = 2,
                    threads_compute = 4,
                    cluster = list(queue_host = queue_host,  #your own host name for power9
                                   queue_type = 'slurm',
                                   cores_per_job = 1,
                                   temp_dir = temp_dir,
                                   r_module = 'R/3.6.1-foss-2018b',
                                   CDO_module = 'CDO/1.9.5-foss-2018b',
                                   extra_queue_params = list('#SBATCH --mem-per-cpu=3000'),
                                   polling_period = 10,
                                   job_wallclock = '01:00:00',
                                   max_jobs = 6,
                                   bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir, #your own local directory
                 wait = TRUE)

## on Nord3v2
#-----------modify according to your personal info-----------
  queue_host = 'nord4.bsc.es'
  temp_dir =  '/gpfs/scratch/bsc32/bsc32339/startR_hpc/'
  ecflow_suite_dir = '/home/Earth/nperez/startR_local/'  #your own local directory
#------------------------------------------------------------
  res4_N <- Compute(wf4,
                    chunks = list(ensemble = 2,
                                  sdate = 2),
                    threads_load = 2,
                    threads_compute = 4,
                    cluster = list(queue_host = queue_host,  #your own host name for power9
                                   queue_type = 'slurm',
                                   cores_per_job = 1,
                                   temp_dir = temp_dir,
                                   CDO_module = 'CDO',
                                   polling_period = 10,
                                   job_wallclock = '01:00',
                                   max_jobs = 6,
                                   bidirectional = FALSE),
                 ecflow_suite_dir = ecflow_suite_dir, #your own local directory
                 wait = TRUE)
