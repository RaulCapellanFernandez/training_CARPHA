(This is a template to report problems or suggest a new development. Please fill in the relevant information and remove the rest.)

Hi @vagudets,

#### Summary
(Bug: Summarize the bug and explain briefly the expected and the current behavior.)  
(New development: Summarize the development needed.)  

#### Example
(Bug: Provide a **minimal reproducible example** and the error message. See [How To Build A Minimal Reproducible Example](https://docs.google.com/document/d/1zRlmsRwFDJctDB94x6HGf6ezu3HFHhEjaBu0hVcrwTI/edit#heading=h.skblym4acpw5))  
(New development: Provide an example script or useful piece of code if appliable.)  

```r
#Example:
exp <- Start(...)
```
> Error in Start: &%$("!* 

#### Module and Package Version
(Which R version are you using? e.g., R/4.1.2)  
(What other modules and their versions required to reproduce this issue? e.g., PROJ/4.8.0-foss-2015a)
(Which R package versions are you using? Check with sessionInfo(). e.g., startR_2.2.3)  
(Which machine are you using? WS, Nord3, hub, others...)  

#### Other Relevant Information
(Additional information.)
