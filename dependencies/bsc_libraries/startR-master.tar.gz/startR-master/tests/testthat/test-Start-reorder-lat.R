suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

#1 selector type	1-values(list)	2-values(vector)  3-indices     4-'all'  5-mix
#2 selector range	1-[10, 20]	2-[20, 10]	  3-[-10, -20]	4-[-20, -10]
#3 resolution		1-1	2-<1	3->1	
#4 returns_var		1-NULL	2-'dat' 		
#5 lat_reorder/Sort()	1-No	2-Yes,decreasing = F	3-Yes,decreasing = T	
#6 lon_reorder/CircularSort()	1-No	2-Yes,(0, 360)	3-Yes,(-180, 180)	
#7 transform		1-NO	2-YES		
#8 transform_crop	1-T	2-F	3-region	

##############################################
path_exp <- '/esarchive/exp/ecmwf/system5_m1/daily_mean/$var$_f6h/$var$_$sdate$.nc'
path_exp <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_exp)

## Origin longitude in file: [0:360]

##############################################
test_that("1-1-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.25761, 19.81264),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  35
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

# lon
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(40, 45),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  19
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )

})

##############################################
test_that("1-2-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 20
lats.max <- 10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.25761, 19.81264),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  35
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

})

##############################################
test_that("1-3-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -10
lats.max <- -20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-19.81264, -10.25761),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  35
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-4-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -20
lats.max <- -10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-19.81264, -10.25761),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  35
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})

##############################################
test_that("2-1-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(9.976578, 20.093670),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

# lon
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(40, 45),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  19
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )

})

##############################################
test_that("2-2-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 20
lats.max <- 10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(9.976578, 20.093670),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("2-3-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -10
lats.max <- -20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-20.093670, -9.976578),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("2-4-2-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -20
lats.max <- -10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-20.093670, -9.976578),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-2-3-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$common$latitude)),
  c(10.25761, 19.81264),
  tolerance = 0.0001
  )
  expect_equal(
  attr(res, 'Variables')$dat1$latitude,
  NULL
  )
  expect_equal(
  (attr(res, 'Variables')$common$latitude)[1] < (attr(res, 'Variables')$common$latitude)[2],
  TRUE
  )
  expect_equal(
  class(attr(res, 'Variables')$common$latitude),
  'array'
  )
})

##############################################
test_that("2-1-2-3-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$common$latitude)),
  c(9.976578, 20.093670),
  tolerance = 0.0001
  )
  expect_equal(
  attr(res, 'Variables')$dat1$latitude,
  NULL
  )
  expect_equal(
  (attr(res, 'Variables')$common$latitude)[1] < (attr(res, 'Variables')$common$latitude)[2],
  TRUE
  )
  expect_equal(
  class(attr(res, 'Variables')$common$latitude),
  'array'
  )
})
##############################################
##############################################
test_that("1-1-2-2-2-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.25761, 19.81264),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  35
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

# lon
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(40, 45),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  19
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )

})
##############################################
test_that("1-2-2-2-2-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 20
lats.max <- 10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.25761, 19.81264),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  35
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-2-2-2-3-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.25761, 19.81264),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  35
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("2-1-2-2-2-3-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(9.976578, 20.093670),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})


##############################################
#1 selector type        1-values(list)  2-values(vector)  3-indices     4-'all'  5-mix
#2 selector range       1-[10, 20]      2-[20, 10]        3-[-10, -20]  4-[-20, -10]
#3 resolution           1-1     2-<1    3->1    
#4 returns_var          1-NULL  2-'dat' 
#5 lat_reorder/Sort()   1-No    2-Yes,decreasing = F    3-Yes,decreasing = T    
#6 lon_reorder/CircularSort()   1-No    2-Yes,(0, 360)  3-Yes,(-180, 180)       
#7 transform            1-NO    2-YES           
#8 transform_crop       1-T     2-F     3-region        


##############################################
test_that("1-1-2-2-1-1-2-3", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})

##############################################
test_that("1-1-2-2-3-1-2-3", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-2-2-3-2-2-3", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-2-2-3-1-2-1", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '19821201',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = T),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})

##############################################
#test_that("1-3. Selector type: indices(list)", {
#
#})
##############################################
#test_that("1-4. Selector type: indices(vector)", {
#
#})
##############################################
test_that("4-x-2-12-123-2-1-x", {

# 1-1. no Sort(), NULL
## lat should be descending
path <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)
suppressWarnings(
exp1_1 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = 'all',
#             latitude_reorder = Sort(),
             longitude = 'all',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('latitude', 'lat'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve = T)
)
# 1-2. Sort(), NULL
## lat should be ascending
suppressWarnings(
exp1_2 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1), 
             time = indices(1),
             latitude = 'all',
             latitude_reorder = Sort(),
             longitude = 'all',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('latitude', 'lat'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve = T)
)
# 1-3. Sort(drcreasing = T), NULL
## lat should be descending
suppressWarnings(
exp1_3 <- Start(dat = path, 
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1), 
             time = indices(1),
             latitude = 'all',
             latitude_reorder = Sort(decreasing = T),
             longitude = 'all',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('latitude', 'lat'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve = T)
)
expect_equal(
drop(exp1_1)[1:5, 2],
c(250.8470, 251.0054, 251.1874, 251.3769, 251.5602),
tolerance = 0.0001
)
expect_equal(
as.vector(drop(exp1_1)),
as.vector(drop(exp1_2)[640:1, ])
)
expect_equal(
as.vector(drop(exp1_1)),
as.vector(drop(exp1_3))
)
expect_equal(
as.vector(attr(exp1_1, 'Variables')$common$latitude)[1:5],
c(89.78488, 89.50620, 89.22588, 88.94519, 88.66436),
tolerance = 0.0001
)
expect_equal(
as.vector(attr(exp1_2, 'Variables')$common$latitude)[1:5],
c(-89.78488, -89.50620, -89.22588, -88.94519, -88.66436),
tolerance = 0.0001
)
expect_equal(
as.vector(attr(exp1_1, 'Variables')$common$latitude),
as.vector(attr(exp1_3, 'Variables')$common$latitude)
)


# 2-1. no Sort(), 'dat'
## lat should be descending
suppressWarnings(
exp2_1 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = 'all',
#             latitude_reorder = Sort(),
             longitude = 'all',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('latitude', 'lat'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'sdate'),
             retrieve = T)
)
# 2-2. Sort(), 'dat'
## lat should be ascending
suppressWarnings(
exp2_2 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1), 
             time = indices(1),
             latitude = 'all',
             latitude_reorder = Sort(),
             longitude = 'all',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('latitude', 'lat'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'sdate'),
             retrieve = T)
)
# 2-3. Sort(drcreasing = T), NULL
## lat should be descending
suppressWarnings(
exp2_3 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1), 
             time = indices(1),
             latitude = 'all',
             latitude_reorder = Sort(decreasing = T),
             longitude = 'all',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('latitude', 'lat'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'sdate'),
             retrieve = T)
)
expect_equal(
as.vector(drop(exp1_1)),
as.vector(drop(exp2_1))
)
expect_equal(
as.vector(drop(exp1_2)),
as.vector(drop(exp2_2))
)
expect_equal(
as.vector(drop(exp1_3)),
as.vector(drop(exp2_3))
)
expect_equal(
as.vector(attr(exp2_1, 'Variables')$dat1$latitude),
as.vector(attr(exp1_1, 'Variables')$common$latitude)
)
expect_equal(
as.vector(attr(exp2_2, 'Variables')$dat1$latitude),
as.vector(attr(exp1_2, 'Variables')$common$latitude)
)
expect_equal(
as.vector(attr(exp2_3, 'Variables')$dat1$latitude),
as.vector(attr(exp1_3, 'Variables')$common$latitude)
)

})
##############################################
}) #suppressMessages
