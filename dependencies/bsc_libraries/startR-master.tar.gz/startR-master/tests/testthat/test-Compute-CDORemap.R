suppressMessages({
test_that("ex2_3", {

  repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
  data <- Start(dat = repos,
                var = 'tas',
                sdate = c('20170101'),
                ensemble = indices(1),
                time = indices(1),
                latitude = 'all',
                longitude = 'all',
                return_vars = list(latitude = 'dat', longitude = 'dat', time = 'sdate'),
                retrieve = FALSE)
)  
  
  fun <- function(x) {
    lons_data <- as.vector(attr(x, 'Variables')$dat1$longitude)
    lats_data <- as.vector(attr(x, 'Variables')$dat1$latitude)
    r <- s2dv::CDORemap(x, lons_data, lats_data, "r360x181",
                        'bil', crop = FALSE, force_remap = TRUE)[[1]]
    return(r)
  }
  
  step3 <- Step(fun = fun,
               target_dims = c('latitude','longitude'),
               output_dims = c('latitude', 'longitude'),
               use_attributes = list(data = "Variables"))
  wf3 <- AddStep(list(data = data), step3)

suppressWarnings(
  res3 <- Compute(workflow = wf3,
                  chunks = list(ensemble = 1))
 )

expect_equal(
attr(data, 'Dimensions'),
c(dat = 1, var = 1, sdate = 1, ensemble = 1, time = 1, latitude = 640, longitude = 1296)
)
expect_equal(
dim(res3$output),
c(latitude = 181, longitude = 360, dat = 1, var = 1, sdate = 1, ensemble = 1, time = 1)
)
expect_equal(
mean(res3$output),
277.0346,
tolerance = 0.0001
)
expect_equal(
res3$output[20,11,1,,1,1,1],
c(265.5362),
tolerance = 0.0001
) 

})
}) #suppressMessages
