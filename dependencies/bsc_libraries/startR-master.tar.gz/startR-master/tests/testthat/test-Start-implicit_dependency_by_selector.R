suppressMessages({
# Similar as usecase ex1_13.
# Use a value array as the inner dimension selector to express dependency on a 
# file dimension. By this means, we don't need to specify the *_across parameter
# and Start() can recognize this dependecy relationship.
#---------------------------------------------------
# If assign a selector with an array that has file dim as dimension, Start() read 
# the values depending on the the file dim. 
#---------------------------------------------------

#NOTE: The files don't exist anymore.
#test_that("1. region with different index between files", {
#
#path <- paste0('/esarchive/exp/ecearth/a35b/diags/DCPP/EC-Earth-Consortium/',
#               'EC-Earth3-HR/dcppA-hindcast/r1i1p1f1/Omon/$var$_mixed/gn/v20201107/',
#               '$var$_Omon_EC-Earth3-HR_dcppA-hindcast_s$sdate$-r1i1p1f1_gn_$chunk$.nc')
#
## two sdates have different index for Nino3. 
#region <- array('Nino3', dim = c(sdate = 2, region = 1))
#
#suppressWarnings(
#data <- Start(dat = path,
#              var = 'tosmean',
#              sdate = c('1993', '2013'),
#              chunk = indices(1:2),
#              chunk_depends = 'sdate',
#              region = region,
#              time = 'all', 
#              time_across = 'chunk',
#              merge_across_dims = TRUE,
#              return_vars = list(time = c('sdate', 'chunk'),
#                                 region = 'sdate'),
#               retrieve = T)
#)
#suppressWarnings(
#data1 <- Start(dat = path,
#              var = 'tosmean',
#              sdate = c('1993'),
#              chunk = indices(1:2),
#              chunk_depends = 'sdate',
#              region = 'Nino3',
#              time = 'all', #c(1:length(forecast_month)),
#              time_across = 'chunk',
#              merge_across_dims = TRUE,
#              return_vars = list(time = c('sdate', 'chunk'),
#                                 region = NULL),
#               retrieve = T)
#)
#suppressWarnings(
#data2 <- Start(dat = path,
#              var = 'tosmean',
#              sdate = c('2013'),
#              chunk = indices(1:2),
#              chunk_depends = 'sdate',
#              region = 'Nino3',
#              time = 'all', #c(1:length(forecast_month)),
#              time_across = 'chunk',
#              merge_across_dims = TRUE,
#              return_vars = list(time = c('sdate', 'chunk'),
#                                 region = NULL),
#               retrieve = T)
#)
#
#expect_equal(
#dim(data),
#c(dat = 1, var = 1, sdate = 2, region = 1, time = 2)
#)
#expect_equal(
#data[1, 1, 1, 1, ],
#data1[1, 1, 1, 1, ]
#)
#expect_equal(
#data[1, 1, 2, 1, ],
#data2[1, 1, 1, 1, ]
#)
#
#
#})

test_that("2. time depends on sdate", {

repos <- '/esarchive/exp/ecmwf/system4_m1/daily_mean/$var$_f24h/$var$_$sdate$.nc'
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
sdates <- paste0(2001:2003, '0501')
tmp <- as.POSIXct(sapply(2001:2003, function(x) paste0(x, '-05-', sprintf('%02d', 1:31))), tz = 'UTC')
tmp <- array(tmp, dim = c(time = 31, sdate = 3))
times <- as.POSIXct(tmp, tz = 'UTC', origin = '1970-01-01')

suppressWarnings(
exp <- Start(dat = repos,
             var = 'tos',
             sdate = sdates,
             time = times,  #dim: [time = 31, sdate = 3]. time is corresponding to each sdate
             ensemble = indices(1:2),
             lat = indices(1:3),
             lon = indices(1:6),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(lon = NULL, lat = NULL, time = 'sdate'),
             retrieve = T)
)

expect_equal(
dim(exp),
c(dat = 1, var = 1, sdate = 3, time = 31, ensemble = 2, lat = 3, lon = 6)
)
expect_equal(
mean(exp, na.rm = T),
271.4913,
tolerance = 0.0001
)
expect_equal(
exp[1, 1, 3, 28:30, 1, 3, 2],
c(272.4185, 272.6533, 272.6494),
tolerance = 0.0001
)


})

test_that("3. region depends on member and sdate", {
#NOTE: This case, region indices are not dependent on sdate. But it should work if it is
reg <- array('Nino3.4', dim = c(sdate = 3, memb = 2, region = 1))

path_SR <- paste0('/esarchive/exp/ecearth/a42y/diags/DCPP/EC-Earth-Consortium/EC-Earth3/dcppA-hindcast/$memb$/Omon/$var$/gn/v*/$var$_Omon_EC-Earth3_dcppA-hindcast_s$sdate$-$memb$_gn_$chunk$.nc')
path_SR <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_SR)
suppressWarnings(
data <- Start(dat = path_SR,
              var = 'tosmean',
              memb = paste0('r', c(24, 28), 'i1p1f1'),
              region = reg,
              region_var = 'region',
              sdate = paste0(2000:2002),
              time = c(1:4),
              chunk = 'all',
              chunk_depends = 'sdate',
              time_across = 'chunk',
              merge_across_dims = TRUE,
              return_vars = list(time=c('sdate','chunk'), region=c('sdate', 'memb')),
              retrieve = T)
)

expect_equal(
dim(data),
c(dat = 1, var = 1, memb = 2, region = 1, sdate = 3, time = 4)
)
expect_equal(
as.vector(drop(data)[,,1]),
c(26.87246, 26.88851, 27.28198, 27.28953, 27.65627, 27.68499),
tolerance = 0.0001
)

expect_equal(
dim(attr(data, 'Variables')$common$region),
c(memb = 2, sdate = 3, region = 1)
)


})
}) #suppressMessages
