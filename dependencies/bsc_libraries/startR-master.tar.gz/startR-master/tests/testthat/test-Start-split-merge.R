suppressMessages({

var_name <- 'tas'
path.exp <- '/esarchive/exp/ecmwf/s2s-monthly_ensforhc/daily_mean/$var$_f6h/$sdate$/$var$_$syear$.nc'
path.exp <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path.exp)

suppressWarnings(
hcst <- Start(dat = path.exp,
              var =  var_name,
              sdate = c('20160704', '20161222'),
              syear = indices(1:3),  #2016:2018
              syear_depends = 'sdate',
              time = indices(1:12),  #4th-15th Jul; 22nd Dec-2nd Jan         
              latitude = indices(1:10),
              longitude = indices(1:10),
              ensemble = 'all',
              return_vars = list(latitude = 'dat',
                                 longitude = 'dat',
                                 time = c('sdate', 'syear')),
              retrieve = F,
              silent = TRUE)
)
dates <- attr(hcst, 'Variables')$common$time
file_date <- sort(unique(gsub('-', '',
                              sapply(as.character(dates), substr, 1, 7))))

path.obs <- '/esarchive/recon/ecmwf/era5/1hourly/$var$/$var$_$file_date$.nc'
path.obs <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path.obs)
var_name <- "sfcWind"

test_that("1. split + merge + narm", {
suppressWarnings(
obs <- Start(dat = path.obs,
             var = var_name,
             file_date = file_date,   # a vector
             latitude = indices(1:10),
             longitude = indices(1:10),
             time = values(dates),    # a 3-dim array (sdate, syear, time)
             time_across = 'file_date',
             merge_across_dims = TRUE,
             merge_across_dims_narm = TRUE,
             split_multiselected_dims = TRUE,
             synonims = list(latitude = c('lat','latitude'),
                             longitude = c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'file_date'),
             retrieve = T)
)
  expect_equal(
  dim(obs),
  c(dat = 1, var = 1, latitude = 10, longitude = 10, sdate = 2, syear = 3, time = 12)
  )
  expect_equal(
  obs[1, 1, 1, 1, 2, 2, 1:3],
  c(6.968349, 6.604249, 7.563990),
  tolerance = 0.0001
  )
  expect_equal(
  mean(obs),
  5.726787,
  tolerance = 0.0001
  )
  expect_equal(
  length(obs[which(is.na(obs))]),
  0
  )
})


test_that("2. no split + merge + narm", {
suppressWarnings(
obs <- Start(dat = path.obs,
             var = var_name,
             file_date = file_date,   # a vector
             latitude = indices(1:10),
             longitude = indices(1:10),
             time = values(dates),    # a 3-dim array (sdate, syear, time)
             time_across = 'file_date',
             merge_across_dims = TRUE,
             merge_across_dims_narm = TRUE,
             split_multiselected_dims = FALSE,
             synonims = list(latitude = c('lat','latitude'),
                             longitude = c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'file_date'),
             retrieve = T)
)
  expect_equal(
  dim(obs),
  c(dat = 1, var = 1, latitude = 10, longitude = 10, time = 72)
  )
  expect_equal(
  obs[1, 1, 1, 1, 10:13],
  c(3.777488, 7.563611, 3.737108, 4.478187),
  tolerance = 0.0001
  )
  expect_equal(
  mean(obs),
  5.726787,
  tolerance = 0.0001
  )
  expect_equal(
  length(obs[which(is.na(obs))]),
  0
  )
})


test_that("3. no split + merge + no narm", {
suppressWarnings(
obs <- Start(dat = path.obs,
             var = var_name,
             file_date = file_date,   # a vector
             latitude = indices(1:10),
             longitude = indices(1:10),
             time = values(dates),    # a 3-dim array (sdate, syear, time)
             time_across = 'file_date',
             merge_across_dims = TRUE,
             merge_across_dims_narm = FALSE,
             split_multiselected_dims = FALSE,
             synonims = list(latitude = c('lat','latitude'),
                             longitude = c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'file_date'),
             retrieve = T)
)  
  expect_equal(
  dim(obs),  
  c(dat = 1, var = 1, latitude = 10, longitude = 10, time = 108)
  )
  expect_equal(
  obs[1, 1, 1, 1, 10:13],
  c(3.777488, 7.563611, 3.737108, 4.478187),
  tolerance = 0.0001
  )
  expect_equal(
  mean(obs, na.rm = T),
  5.726787,
  tolerance = 0.0001
  )
  expect_equal(
  length(obs[which(is.na(obs))]),
  3600
  )
})

test_that("4. split only", {

obs.path <- "/esarchive/recon/ecmwf/era5/monthly_mean/$var$_f1h-r1440x721cds/$var$_$file_date$.nc"
obs.path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', obs.path)
variable <- "prlr"
dates_file <- c("201311","201312","201411","201412")
dim(dates_file) <- c(smonth = 2, syear = 2)

suppressWarnings(
obs <- Start(dat = obs.path,
             var = variable,
             file_date = dates_file,
             time = 'all',
             latitude = values(list(35.6, 40)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(-10, 10)),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('lon', 'longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'file_date'),
             split_multiselected_dims = TRUE,
             retrieve = FALSE)
)

expect_equal(
attr(obs, 'Dimensions'),
c(dat = 1, var = 1, smonth = 2, syear = 2, time = 1, latitude = 18, longitude = 81)
)
expect_equal(
dim(attr(obs, 'Variables')$common$time),
c(smonth = 2, syear = 2, time = 1)
)
expect_equal(
attr(obs, 'Variables')$common$time[1, 1, 1],
as.POSIXct('2013-11-15', tz = 'UTC')
)



})
}) #suppressMessages
