suppressMessages({
test_that("Chunks of DCPP files- Local execution", {
  path <- '/esarchive/exp/CMIP6/dcppA-hindcast/HadGEM3-GC31-MM/DCPP/MOHC/HadGEM3-GC31-MM/dcppA-hindcast/r1i1p1f2/Omon/tos/gn/v20200417/$var$_Omon_HadGEM3-GC31-MM_dcppA-hindcast_s$sdate$-r1i1p1f2_gn_$chunk$.nc'
  path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

  sdates <- c('2017', '2018')
suppressWarnings(
  dat <- Start(dat = path,
             var = 'tos',
             sdate = sdates,
             chunk = indices(3:5),
             chunk_depends = 'sdate',
             time = 'all',
             i = indices(1:10),
             j = indices(1:10),
             time_across = 'chunk',
             merge_across_dims = TRUE,
             retrieve = TRUE,
             return_vars = list(time = 'sdate'))
)

# [sdate = 2, chunk = 3]  
path <- "/esarchive/exp/CMIP6/dcppA-hindcast/HadGEM3-GC31-MM/DCPP/MOHC/HadGEM3-GC31-MM/dcppA-hindcast/r1i1p1f2/Omon/tos/gn/v20200417/$var$_Omon_HadGEM3-GC31-MM_dcppA-hindcast_s2018-r1i1p1f2_gn_202201-202212.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
dat_2018_chunk3 <- Start(dat = path,
              var = 'tos', time = 'all', i = indices(1:10), j = indices(1:10), 
              retrieve = TRUE)
)
expect_equal(dat[1,1,2,25:36,,], dat_2018_chunk3[1,1,,,])

# [sdate = 1, chunk = 2]
path <- "/esarchive/exp/CMIP6/dcppA-hindcast/HadGEM3-GC31-MM/DCPP/MOHC/HadGEM3-GC31-MM/dcppA-hindcast/r1i1p1f2/Omon/tos/gn/v20200417/$var$_Omon_HadGEM3-GC31-MM_dcppA-hindcast_s2017-r1i1p1f2_gn_202001-202012.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)
suppressWarnings(
dat_2017_chunk2 <- Start(dat = path,
              var = 'tos', time = 'all', i = indices(1:10), j = indices(1:10),
              retrieve = TRUE)
)
expect_equal(dat[1,1,1,13:24,,], dat_2017_chunk2[1,1,,,])

# [sdate = 2, chunk = 1]  
path <- "/esarchive/exp/CMIP6/dcppA-hindcast/HadGEM3-GC31-MM/DCPP/MOHC/HadGEM3-GC31-MM/dcppA-hindcast/r1i1p1f2/Omon/tos/gn/v20200417/$var$_Omon_HadGEM3-GC31-MM_dcppA-hindcast_s2018-r1i1p1f2_gn_202001-202012.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)
suppressWarnings(
dat_2018_chunk1 <- Start(dat = path,
              var = 'tos', time = 'all', i = indices(1:10), j = indices(1:10),
              retrieve = TRUE)
)

expect_equal(dat[1,1,2,1:12,,], dat_2018_chunk1[1,1,,,])

})

}) #suppressMessages
