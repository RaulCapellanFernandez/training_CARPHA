suppressMessages({
# The name of return_vars should be one of the inner dimension names. The synonims can 
# be used but will be changed back to the inner dim names. 

repos_obs <- '/esarchive/obs/ukmo/hadisst_v1.1/monthly_mean/$var$/$var$_$date$.nc'
repos_obs <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos_obs)

#---------------------------------------------------------------

test_that("1. Selector is values()", {

# (1)
suppressWarnings(
res <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = values(list(5, 10)),
             lat_reorder = Sort(),
             lon = values(list(15, 20)),
             lon_reorder = CircularSort(0, 360),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(latitude = NULL,  # the name should be lat
                                longitude = NULL,
                                time = 'date'),
             retrieve = TRUE)
)

expect_equal(
names(attr(res, 'Variables')$common),
c("lat", "lon", "time", "tos")
)
expect_equal(
range(attr(res, 'Variables')$common$lat),
c(5.5, 9.5)
)


# (2)
suppressWarnings(
res <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = values(list(5, 10)),
             lat_reorder = Sort(),
             lon = values(list(15, 20)),
             lon_reorder = CircularSort(0, 360),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(lat = NULL, 
                                lon = NULL,
                                time = 'date'),
             retrieve = TRUE)
)

expect_equal(
names(attr(res, 'Variables')$common),
c("lat", "lon", "time", "tos")
)
expect_equal(
range(attr(res, 'Variables')$common$lat),
c(5.5, 9.5)
)

# (3)
suppressWarnings(
res <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = values(list(5, 10)),
             lat_reorder = Sort(),
             lon = values(list(15, 20)),
             lon_reorder = CircularSort(0, 360),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(lat = 'dat',  # the name should be lat
                                lon = 'dat',
                                time = 'date'),
             retrieve = TRUE)
)
expect_equal(
names(attr(res, 'Variables')$dat1),
c("lat", "lon")
)
expect_equal(
names(attr(res, 'Variables')$common),
c("time", "tos")
)
expect_equal(
range(attr(res, 'Variables')$dat1$lat),
c(5.5, 9.5)
)

# (4)
suppressWarnings(
res <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = values(list(5, 10)),
             lat_reorder = Sort(),
             lon = values(list(15, 20)),
             lon_reorder = CircularSort(0, 360),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(latitude = 'dat',  # the name should be lat
                                longitude = 'dat',
                                time = 'date'),
             retrieve = TRUE)
)
expect_equal(
names(attr(res, 'Variables')$dat1),
c("lat", "lon")
)
expect_equal(
names(attr(res, 'Variables')$common),
c("time", "tos")
)
expect_equal(
range(attr(res, 'Variables')$dat1$lat),
c(5.5, 9.5)
)

})




test_that("2. Selector is indices()", {

# (1)
suppressWarnings(
obs <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = indices(105:110),
             lon =  indices(105:110),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(lat = NULL,  
                                lon = NULL,
                                time = 'date'),
             retrieve = TRUE)
)
expect_equal(
names(attr(obs, 'Variables')$common),
c("lat", "lon","time", "tos")
)
expect_equal(
range(attr(obs, 'Variables')$common$lat),
c(-19.5, -14.5)
)


# (2)
suppressWarnings(
obs <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = indices(105:110),
             lon =  indices(105:110),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(latitude = NULL,  
                                longitude = NULL,
                                time = 'date'),
             retrieve = TRUE)
)
expect_equal(
names(attr(obs, 'Variables')$common),
c("lat", "lon","time", "tos")
)
expect_equal(
range(attr(obs, 'Variables')$common$lat),
c(-19.5, -14.5)
)


# (3)
suppressWarnings(
obs <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = indices(105:110),
             lon =  indices(105:110),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(latitude = 'dat', 
                                longitude = 'dat',
                                time = 'date'),
             retrieve = TRUE)
)
expect_equal(
names(attr(obs, 'Variables')$common),
c("time", "tos")
)
expect_equal(
names(attr(obs, 'Variables')$dat1),
c("lat", "lon")
)
expect_equal(
range(attr(obs, 'Variables')$dat1$lat),
c(-19.5, -14.5)
)

# (4)
suppressWarnings(
obs <- Start(dat = repos_obs,
             var = 'tos',
             date = '200505',
             time = indices(1),
             lat = indices(105:110),
             lon =  indices(105:110),
             synonims = list(lat = c('lat', 'latitude'),
                             lon = c('lon', 'longitude')),
             return_vars = list(lat = 'dat',  
                                lon = 'dat',
                                time = 'date'),
             retrieve = TRUE)
)
expect_equal(
names(attr(obs, 'Variables')$common),
c("time", "tos")
)
expect_equal(
names(attr(obs, 'Variables')$dat1),
c("lat", "lon")
)
expect_equal(
range(attr(obs, 'Variables')$dat1$lat),
c(-19.5, -14.5)
)

})
}) #suppressMessages
