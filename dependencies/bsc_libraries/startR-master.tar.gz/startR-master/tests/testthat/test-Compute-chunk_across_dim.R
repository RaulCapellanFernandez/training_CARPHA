suppressMessages({
# This unit test tests the chunking over dimension that goes across files.
# 1. across dim is a vector
#   a. merge_across_dims is TRUE
#   b. merge_across_dims is FALSE
# Note that 1.b. doesn't work.

path <- '/esarchive/exp/CMIP6/dcppA-hindcast/HadGEM3-GC31-MM/DCPP/MOHC/HadGEM3-GC31-MM/dcppA-hindcast/r1i1p1f2/Omon/tos/gn/v20200417/$var$_Omon_HadGEM3-GC31-MM_dcppA-hindcast_s$sdate$-r1i1p1f2_gn_$chunk$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

sdates <- c('2016', '2017', '2018')

# retrieve = T for verification
suppressWarnings(
  data_T <- Start(dat = path,
                  var = 'tos',
                  sdate = sdates,
                  chunk = 'all',
                  chunk_depends = 'sdate',
                  time = indices(1:24),
                  i = indices(450:452),
                  j = indices(650:651),
                  time_across = 'chunk',
                  merge_across_dims = TRUE,
                  largest_dims_length = TRUE,
                  retrieve = TRUE,
                  return_vars = list(time = 'sdate'))
)

test_that("1.a. across dim is a vector, merge_across_dims = TRUE", {

suppressWarnings(
data <- Start(dat = path,
              var = 'tos',
              sdate = sdates,
              chunk = 'all',
              chunk_depends = 'sdate',
              time = indices(1:24),
              i = indices(450:452),
              j = indices(650:651),
              merge_across_dims = TRUE,
              largest_dims_length = TRUE,
              time_across = 'chunk',
              return_vars = list(time = 'sdate'),
              retrieve = FALSE)
)

fun <- function(x) {
return(x)
}

step <- Step(fun = fun,
             target_dims = 'dat', output_dims = 'dat')
wf <- AddStep(inputs = data, step_fun = step)
suppressWarnings(
res1 <- Compute(workflow = wf, chunks = list(time = 1))$output1
)
suppressWarnings(
res2 <- Compute(workflow = wf, chunks = list(time = 2))$output1
)
suppressWarnings(
res3 <- Compute(workflow = wf, chunks = list(time = 3))$output1
)

expect_equal(
as.vector(data_T),
as.vector(res1)
)
expect_equal(
res1,
res2
)
expect_equal(
res1,
res3
)

expect_equal(
as.vector(drop(res1)[ , 1, 1, 1]),
c(29.91125, 29.94805, 30.35584),
tolerance = 0.0001
)
expect_equal(
as.vector(drop(res1)[ , 2, 1, 1]),
c(29.53878, 29.72491, 30.34167),
tolerance = 0.0001
)

})

#################################################################
#################################################################
#################################################################

test_that("1.b. across dim is a vector, merge_across_dims = FALSE", {

suppressWarnings(
data <- Start(dat = path,
              var = 'tos',
              sdate = sdates,
              chunk = 'all',
              chunk_depends = 'sdate',
              time = indices(1:24),
              i = indices(450:452),
              j = indices(650:651),
              merge_across_dims = FALSE,
              largest_dims_length = TRUE,
              time_across = 'chunk',
              return_vars = list(time = 'sdate'),
              retrieve = FALSE)
)

fun <- function(x) {
return(x)
}

step <- Step(fun = fun,
             target_dims = 'dat', output_dims = 'dat')
wf <- AddStep(inputs = data, step_fun = step)

expect_error(
suppressWarnings(
res <- Compute(workflow = wf, chunks = list(time = 2))$output1),
"Chunk over dimension 'time' is not allowed because 'time' is across 'chunk' and 'merge_across_dims' is set to FALSE'."
)

})

}) #suppressMessages
