suppressMessages({
# Ensure returns_vars = NULL or 'dat' have the same metadata

test_that("1. Sort() and CircularSort(0, 360)", {

# Original lon is [-180, 180]
path_exp <- '/esarchive/recon/ecmwf/era5/original_files/reorder/daily_mean/$var$/$var$_$sdate$.nc'
lons.min <- -10
lons.max <- 10
lats.min <- 10
lats.max <- 20

# return_vars is NULL
suppressWarnings(
res_null <- Start(dat = list(list(path = path_exp)),
                  var = 'tas',
                  sdate = '199212',
                  time = indices(4),
                  latitude = values(list(lats.min, lats.max)),
                  latitude_reorder = Sort(),
                  longitude_reorder = CircularSort(0, 360),
                  longitude = values(list(lons.min, lons.max)),
                  synonims = list(latitude = c('lat', 'latitude'),
                                  longitude = c('lon', 'longitude')),
                  return_vars = list(latitude = NULL,
                                     longitude = NULL,
                                     time = 'sdate'),
                  retrieve = F)
)
  expect_equal(
  length(attributes(attr(res_null, 'Variables')$common$longitude)),
  2
  )
  expect_equal(
  is.list(attr(attr(res_null, 'Variables')$common$latitude, 'variables')),
  TRUE
  )
  expect_equal(
  length(attr(attr(res_null, 'Variables')$common$latitude, 'variables')$latitude),
  7
  )
  expect_equal(  
  length(attr(attr(res_null, 'Variables')$common$longitude, 'variables')$longitude),
  7
  )
  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$latitude)[1],
  10.25761,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$latitude)[35],
  19.81264,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_null, 'Variables')$common$latitude)),
  35
  )

  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$longitude)[1],
  0.00000,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$longitude)[71],
  359.71875,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_null, 'Variables')$common$longitude)),
  71
  )

# return_vars is dat
suppressWarnings(
res_dat <- Start(dat = list(list(path = path_exp)),
                 var = 'tas',
                 sdate = '199212',
                 time = indices(4),
                 latitude = values(list(lats.min, lats.max)),
                 latitude_reorder = Sort(),
                 longitude_reorder = CircularSort(0, 360),
                 longitude = values(list(lons.min, lons.max)),
                 synonims = list(latitude = c('lat', 'latitude'),
                                 longitude = c('lon', 'longitude')),
                 return_vars = list(latitude = 'dat',
                                    longitude = 'dat',
                                    time = 'sdate'),
                 retrieve = F)
)
  expect_equal(
  length(attributes(attr(res_dat, 'Variables')$dat1$longitude)),
  2
  )
  expect_equal(
  is.list(attr(attr(res_dat, 'Variables')$dat1$latitude, 'variables')),
  TRUE
  )
  expect_equal(
  length(attr(attr(res_dat, 'Variables')$dat1$latitude, 'variables')$latitude),
  7
  )
  expect_equal(
  length(attr(attr(res_dat, 'Variables')$dat1$longitude, 'variables')$longitude),
  7
  )
  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$latitude)[1],
  10.25761,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$latitude)[35],
  19.81264,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_dat, 'Variables')$dat1$latitude)),
  35
  )

  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$longitude)[1],
  0.00000,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$longitude)[71],
  359.71875,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_dat, 'Variables')$dat1$longitude)),
  71
  )

})

test_that("2. Sort(decreasing = TRUE) and CircularSort(-180, 180)", {

# Original lon is [0, 360]
path_exp <- '/esarchive/exp/ecmwf/system5_m1/daily_mean/$var$_f6h/$var$_$sdate$.nc'
lons.min <- 190
lons.max <- 200
lats.min <- 10
lats.max <- 20

# return_vars is NULL
suppressWarnings(
res_null <- Start(dat = list(list(path = path_exp)),
                  var = 'psl',
                  member = 'all',
                  sdate = '19821201',
                  time = indices(4),
                  latitude = values(list(lats.min, lats.max)),
                  latitude_reorder = Sort(decreasing = T),
                  longitude_reorder = CircularSort(-180, 180),
                  longitude = values(list(lons.min, lons.max)),
                  synonims = list(latitude = c('lat', 'latitude'),
                                  longitude = c('lon', 'longitude'),
                                  member = c('ensemble', 'realization')),
                  return_vars = list(latitude = NULL,
                                     longitude = NULL,
                                     time = 'sdate'),
                  retrieve = F)
)
  expect_equal(
  length(attributes(attr(res_null, 'Variables')$common$longitude)),
  2
  )
  expect_equal(
  is.list(attr(attr(res_null, 'Variables')$common$latitude, 'variables')),
  TRUE
  )
  expect_equal(
  length(attr(attr(res_null, 'Variables')$common$latitude, 'variables')$latitude),
  7
  )
  expect_equal(
  length(attr(attr(res_null, 'Variables')$common$longitude, 'variables')$longitude),
  7
  )
  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$latitude)[1],
  19.81264,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$latitude)[35],
  10.25761,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_null, 'Variables')$common$latitude)),
  35
  )

  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$longitude)[1],
  -170.0000,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_null, 'Variables')$common$longitude)[37],
  -160.0000,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_null, 'Variables')$common$longitude)),
  37
  )

# return_vars is 'dat'
suppressWarnings(
res_dat <- Start(dat = list(list(path = path_exp)),
                 var = 'psl',
                 member = 'all',
                 sdate = '19821201',
                 time = indices(4),
                 latitude = values(list(lats.min, lats.max)),
                 latitude_reorder = Sort(decreasing = T),
                 longitude_reorder = CircularSort(-180, 180),
                 longitude = values(list(lons.min, lons.max)),
                 synonims = list(latitude = c('lat', 'latitude'),
                                 longitude = c('lon', 'longitude'),
                                 member = c('ensemble', 'realization')),
                 return_vars = list(latitude = 'dat',
                                    longitude = 'dat',
                                    time = 'sdate'),
                 retrieve = F)
)
  expect_equal(
  length(attributes(attr(res_dat, 'Variables')$dat1$longitude)),
  2
  )
  expect_equal(
  is.list(attr(attr(res_dat, 'Variables')$dat1$latitude, 'variables')),
  TRUE
  )
  expect_equal(
  length(attr(attr(res_dat, 'Variables')$dat1$latitude, 'variables')$latitude),
  7
  )
  expect_equal(
  length(attr(attr(res_dat, 'Variables')$dat1$longitude, 'variables')$longitude),
  7
  )
  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$latitude)[1],
  19.81264,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$latitude)[35],
  10.25761,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_dat, 'Variables')$dat1$latitude)),
  35
  )

  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$longitude)[1],
  -170.0000,
  tolerance = 0.0001
  )
  expect_equal(
  as.vector(attr(res_dat, 'Variables')$dat1$longitude)[37],
  -160.0000,
  tolerance = 0.0001
  )
  expect_equal(
  length(as.vector(attr(res_dat, 'Variables')$dat1$longitude)),
  37
  )

})
}) #suppressMessages
