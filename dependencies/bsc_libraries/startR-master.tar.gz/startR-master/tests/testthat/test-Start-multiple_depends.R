suppressMessages({
# This unit test tests the case where a depended dimension has multiple
# depending dimensions and the 'all' selector is used for a depending dim.

path <- "/esarchive/exp/CMIP6/$dcpp$/HadGEM3-GC31-MM/DCPP/MOHC/HadGEM3-GC31-MM/$dcpp$/r1i1p1f2/Omon/tos/gn/v20200417/$var$_Omon_HadGEM3-GC31-MM_$dcpp$_s$sdate$-r1i1p1f2_gn_$chunk$.nc"

path <- paste0('/esarchive/scratch/aho/startR_unittest_files', path)

sdates <- c('2018', '2019')

test_that("1. ", {
suppressWarnings(
dat1 <- Start(dat = path,
              var = 'tos',
              chunk = 'all', 
              time = indices(1:14),
              time_across = 'chunk',
              sdate = sdates,
              dcpp = list('2018' = "dcppA-hindcast", '2019' = "dcppB-forecast"),
              dcpp_depends = 'sdate',
              chunk_depends = 'sdate',
              merge_across_dims = TRUE,
              largest_dims_length = TRUE,
              i = indices(450:460),
              j = indices(685:700),
              return_vars = list(time = c('chunk', 'sdate')),
              retrieve = TRUE)
)

suppressWarnings(
dat2 <- Start(dat = path,
              var = 'tos',
              chunk = list('2018' = c('201811-201812', '201901-201912'),
                           '2019' = c('201911-201912', '202001-202012')),
              time = 'all',
              time_across = 'chunk',
              sdate = sdates,
              dcpp = list('2018' = "dcppA-hindcast", '2019' = "dcppB-forecast"),
              dcpp_depends = 'sdate',
              chunk_depends = 'sdate',
              merge_across_dims = TRUE,
              largest_dims_length = TRUE,
              i = indices(450:460),
              j = indices(685:700),
              return_vars = list(time = c('chunk', 'sdate')),
              retrieve = TRUE)
)

expect_equal(
  as.vector(dat1),
  as.vector(dat2)
)
expect_equal(
  mean(dat2, na.rm = T),
  29.21144,
  tolerance = 0.0001
)
expect_equal(
  dat1[1, 1, 2, 2, 1, 1:3, 10],
  c(28.84955, 28.84827, 28.84126),
  tolerance = 0.0001
  )
})

}) #suppressMessages
