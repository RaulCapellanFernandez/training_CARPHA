suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

test_that("first test", {

  repos <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/tas_f6h/$var$_$sdate$.nc"
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

  var <- 'tas'
  lon.min <- 170
  lon.max <- 185  #359.723 #360
  lat.min <- -10  #-90
  lat.max <- 20  #90

suppressWarnings(
  data_across <- Start(dat = repos,
                       var = var,
                       sdate = c('20170101'),
                       ensemble = indices(1),
                       time = indices(1),
                       latitude = values(list(lat.min, lat.max)),
                       latitude_reorder = Sort(decreasing = T),
                       longitude = values(list(lon.min, lon.max)),
                       longitude_reorder = CircularSort(-180, 180),
                       transform = CDORemapper,
                       transform_extra_cells = 2,
                       transform_params = list(
                         grid = 'r360x181',
                         method = 'con',
                         crop = c(lon.min,lon.max,lat.min,lat.max)
                       ),
                       transform_vars = c('latitude', 'longitude'),
                       return_vars = list(time = 'sdate',
                                          longitude = 'dat',
                                          latitude = 'dat'),
                       retrieve = T)
)
suppressWarnings(
  data_no_across <- Start(dat = repos,
                          var = var,
                          sdate = c('20170101'),
                          ensemble = indices(1),
                          time = indices(1),
                          latitude = values(list(lat.min, lat.max)),
                          latitude_reorder = Sort(decreasing = T),
                          longitude = values(list(lon.min, lon.max)),
                          longitude_reorder = CircularSort(0, 360),
                          transform = CDORemapper,
                          transform_extra_cells = 2,
                          transform_params = list(
                            grid = 'r360x181',
                            method = 'con',
                            crop = c(lon.min,lon.max,lat.min,lat.max)
                          ),
                          transform_vars = c('latitude', 'longitude'),

                          return_vars = list(time = 'sdate',
                                             longitude = 'dat',
                                             latitude = 'dat'),
                          retrieve = T)
)

  expect_equal(
  as.vector(attr(data_across, 'Variables')$dat1$longitude),
  c(-180:-175, 170:179)
  )
  expect_equal(
  as.vector(attr(data_no_across, 'Variables')$dat1$longitude),
  c(170:185)
  )

  expect_equal(
  data_across[1,1,1,1,1,1,7:16],
  data_no_across[1,1,1,1,1,1,1:10],
  tolerance = 0.0001
  )
  expect_equal(
  data_across[1,1,1,1,1,1,1:6],
  data_no_across[1,1,1,1,1,1,11:16],
  tolerance = 0.0001
  )

})
}) #suppressMessages
