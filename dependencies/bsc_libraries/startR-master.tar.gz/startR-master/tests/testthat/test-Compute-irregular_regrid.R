suppressMessages({
library(s2dv)

test_that("1. ex2_13", {

path <- paste0('/esarchive/exp/CMIP6/dcppA-hindcast/CMCC-CM2-SR5/',
               'DCPP/CMCC/CMCC-CM2-SR5/dcppA-hindcast/$member$/Omon/$var$/gn/v20200101/',
               '$var$_*_s$sdate$-$member$_gn_$aux$.nc')
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
data <- Start(dataset = path,
              var = 'tos',
              sdate = '1960',
              aux = 'all',
              aux_depends = 'sdate',
              x = indices(2:361), # remove two indices to avoid white strips 
              y = indices(2:291), # remove two indices to avoid white strips 
              time = indices(1),
              member = 'r1i1p1f1',
#              synonims = list(j = c(j, x), i = c(i, y)),
              return_vars = list(#x = NULL, y = NULL,
                                 nav_lat = NULL, nav_lon = NULL),
              retrieve = F)
)
func_regrid <- function(data) {
  lons <- attr(data, 'Variables')$common$nav_lon
  lats <- attr(data, 'Variables')$common$nav_lat
  data <- s2dv::CDORemap(data, lons[2:361, 2:291], lats[2:361, 2:291], grid = 'r360x180',
                         method = 'bil', crop = FALSE)
  lons_reg <- data[['lons']]
  lats_reg <- data[['lats']]
  return(list(data = data[[1]], lats = lats_reg, lons = lons_reg))
}

step <- Step(fun = func_regrid,
             target_dims = list(data = c('x', 'y')),
             output_dims = list(data = c('lon', 'lat'),
                                lats = 'lat', lons = 'lon'),
             use_attributes = list(data = "Variables"))
suppressWarnings(
wf <- AddStep(data, step)
)
suppressWarnings(
res <- Compute(workflow = wf$data, chunks = list(sdate = 1))
)

expect_equal(
dim(res$data),
c(lon = 360, lat = 180, dataset = 1, var = 1, sdate = 1, aux = 1, time = 1, member = 1)
)
expect_equal(
dim(res$lons),
c(lon = 360, dataset = 1, var = 1, sdate = 1, aux = 1, time = 1, member = 1)
)
expect_equal(
attr(data, 'Dimensions'),
c(dataset = 1, var = 1, sdate = 1, aux = 1, x = 360, y = 290, time = 1, member = 1)
)
expect_equal(
mean(res$data, na.rm = T),
8.782398,
tolerance = 0.0001
)
expect_equal(
drop(res$data)[120,105:110],
c(28.32521, 28.07044, 27.59033, 27.02514, 26.55184, 26.67090),
tolerance = 0.0001
)
expect_equal(
range(res$data),
c(-1.799982, 31.130471),
tolerance = 0.0001
)

})
}) #suppressMessages
