suppressMessages({
# ex1_8

test_that("1. ex1_8, case 1", {

path_tas <- paste0('/esarchive/exp/ecearth/a1ua/cmorfiles/DCPP/EC-Earth-Consortium/EC-Earth3/',
                   'dcppA-hindcast/$member$/Amon/$var$/gr/v20190713/',
                   '$var$_Amon_EC-Earth3_dcppA-hindcast_s$sdate$-$member$_gr_$fyear$.nc')
path_tas <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_tas)
path_tos <- paste0('/esarchive/exp/ecearth/a1ua/cmorfiles/DCPP/EC-Earth-Consortium/EC-Earth3/',
                   'dcppA-hindcast/$member$/Omon/$var$/gr/v20190713/',
                   '$var$_Omon_EC-Earth3_dcppA-hindcast_s$sdate$-$member$_gr_$fyear$.nc')
path_tos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_tos)
suppressWarnings(
data <- Start(dataset = list(list(path = path_tas), list(path = path_tos)),
              var = c('tas', 'tos'),
              sdate = paste0(1960),
              time = 1,
              lat = values(list(10, 20)),
              lat_reorder = Sort(),
              lon = values(list(150, 170)),
              lon_reorder = CircularSort(0, 360),
              fyear = 'all',
              member = 'r10i1p1f1', #indices(1),
              fyear_depends = 'sdate',
              time_across = 'fyear',
              merge_across_dims = TRUE,
              synonims = list(lon = c('lon', 'longitude'),
                              lat = c('lat', 'latitude')),
              metadata_dims = c('dataset', 'var'),
              return_vars = list(lat = 'dataset', lon = 'dataset'),
              retrieve = TRUE)
)

expect_equal(
dim(data),
c(dataset = 2, var = 2, sdate = 1, time = 1, lat = 15, lon = 28, member = 1)
)
expect_equal(
sum(data, na.rm = T),
264710,
tolerance = 0.0001
)
expect_equal(
sum(is.na(data[1,1,,,,,])),
0
)
# Amon also has tos (though the file is incorrect)
expect_equal(
sum(is.na(data[1,2,,,,,])),
0
)
expect_equal(
sum(is.na(data[2,1,,,,,])),
420
)
expect_equal(
sum(is.na(data[2,2,,,,,])),
0
)

expect_equal(
names(attr(data, 'Variables')),
c("common", "dat1", "dat2")
)
expect_equal(
names(attr(data, 'Variables')$common),
c("time")
)
expect_equal(
names(attr(data, 'Variables')$dat1),
c("lat", "lon", "tas", "tos")
)
expect_equal(
names(attr(data, 'Variables')$dat2),
c("lat", "lon", "tos")
)
expect_equal(
length(attr(data, 'Variables')$dat1$tas),
17
)
expect_equal(
length(attr(data, 'Variables')$dat1$tos),
16
)
expect_equal(
length(attr(data, 'Variables')$dat2$tos),
16
)

expect_equal(
data[1, , 1, 1, 1, 1, 1],
c(299.9199, 302.5184),
tolerance = 0.0001
)
expect_equal(
data[2, , 1, 1, 1, 1, 1],
c(NA, 29.3684),
tolerance = 0.0001
)

})
}) #suppressMessages
