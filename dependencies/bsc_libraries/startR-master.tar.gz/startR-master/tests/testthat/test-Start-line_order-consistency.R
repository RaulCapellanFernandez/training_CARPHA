suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

  variable   <- "tas"
  obs.path   <- "/esarchive/recon/ecmwf/era5/monthly_mean/tas_f1h/tas_$file_date$.nc"
  obs.path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', obs.path)
  dates_file <- "201702"

  lats.min <- -90
  lats.max <- 90
  lons.min <- 0
  lons.max <- 360

test_that("1. lon and lat order", {
suppressWarnings(
  dat1 <- Start(dat = obs.path,
                var = variable,
                file_date = dates_file,
                latitude = values(list(lats.min, lats.max)),
                longitude = values(list(lons.min, lons.max)),
                synonims = list(latitude=c('lat','latitude'),
                                longitude=c('lon','longitude')),
                transform = CDORemapper,
                transform_params = list(
                  grid = 'r360x181',
                  method = 'con',
                  crop = c(lons.min,lons.max,lats.min,lats.max)
                ),
                transform_vars = c('latitude', 'longitude'), 
                return_vars = list(latitude = 'dat',
                                   longitude = 'dat',
                                   time = 'file_date'),
                retrieve = T)
)
suppressWarnings(
  dat2 <- Start(dat = obs.path,
                var = variable,
                file_date = dates_file,
                longitude = values(list(lons.min, lons.max)),
                latitude = values(list(lats.min, lats.max)),
                synonims = list(latitude=c('lat','latitude'),
                                longitude=c('lon','longitude')),
                transform = CDORemapper,
                transform_params = list(
                  grid = 'r360x181',
                  method = 'con',
                  crop = c(lons.min,lons.max,lats.min,lats.max)
                ),
                transform_vars = c('latitude', 'longitude'),
                return_vars = list(latitude = 'dat',
                                   longitude = 'dat',
                                   time = 'file_date'),
                retrieve = T)
)
  expect_equal(
  length(attr(dat1, 'Variables')$dat1$latitude),
  length(attr(dat2, 'Variables')$dat1$latitude)
  )
  expect_equal(
  length(attr(dat1, 'Variables')$dat1$longitude),
  length(attr(dat2, 'Variables')$dat1$longitude)
  )
})


test_that("2. dim length check: with/out reorder", {
suppressWarnings(
  dat1 <- Start(dat = obs.path,
                var = variable,
                file_date = dates_file,
                latitude = values(list(lats.min, lats.max)),
                longitude = values(list(lons.min, lons.max)),
                synonims = list(latitude=c('lat','latitude'),
                                longitude=c('lon','longitude')),
                transform = CDORemapper,
                transform_params = list(
                  grid = 'r360x181',
                  method = 'con',
                  crop = c(lons.min,lons.max,lats.min,lats.max)
                ),
                transform_vars = c('latitude', 'longitude'),
                return_vars = list(latitude = 'dat',
                                   longitude = 'dat',
                                   time = 'file_date'),
                retrieve = T)
)
suppressWarnings(
  dat2 <- Start(dat = obs.path,
                var = variable,
                file_date = dates_file,
                latitude = values(list(lats.min, lats.max)),
                latitude_reorder = Sort(),
                longitude = values(list(lons.min, lons.max)),
             #   longitude_reorder = CircularSort(0, 360),
                synonims = list(latitude=c('lat','latitude'),
                                longitude=c('lon','longitude')),
                transform = CDORemapper,
                transform_params = list(
                  grid = 'r360x181',
                  method = 'con',
                  crop = c(lons.min,lons.max,lats.min,lats.max)
                ),
                transform_vars = c('latitude', 'longitude'),
                return_vars = list(latitude = 'dat',
                                   longitude = 'dat',
                                   time = 'file_date'),
                retrieve = T)
)
suppressWarnings(
  dat3 <- Start(dat = obs.path,
                var = variable,
                file_date = dates_file,
                latitude = values(list(lats.min, lats.max)),
                longitude = values(list(lons.min, lons.max)),
                longitude_reorder = CircularSort(0, 361),
                synonims = list(latitude=c('lat','latitude'),
                                longitude=c('lon','longitude')),
                transform = CDORemapper,
                transform_params = list(
                  grid = 'r360x181',
                  method = 'con',
                  crop = c(lons.min,lons.max,lats.min,lats.max)
                ),
                transform_vars = c('latitude', 'longitude'),
                return_vars = list(latitude = 'dat',
                                   longitude = 'dat',
                                   time = 'file_date'),
                retrieve = T)
)
  expect_equal(
  length(attr(dat1, 'Variables')$dat1$latitude),
  length(attr(dat2, 'Variables')$dat1$latitude)
  )
  expect_equal(
  length(attr(dat1, 'Variables')$dat1$longitude),
  length(attr(dat2, 'Variables')$dat1$longitude)
  )
  expect_equal(
  length(attr(dat1, 'Variables')$dat1$latitude),
  length(attr(dat3, 'Variables')$dat1$latitude)
  )
  expect_equal(
  length(attr(dat1, 'Variables')$dat1$longitude),
  length(attr(dat3, 'Variables')$dat1$longitude)
  )

})
}) #suppressMessages
