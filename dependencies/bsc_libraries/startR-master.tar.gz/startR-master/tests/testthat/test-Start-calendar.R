suppressMessages({

test_that("1. 360_day, daily, unit = 'days since 1850-01-01'", {
  path_hadgem3 <- paste0('/esarchive/exp/CMIP6/dcppA-hindcast//HadGEM3-GC31-MM/',
                         'DCPP/MOHC/HadGEM3-GC31-MM/',
                         'dcppA-hindcast/r1i1p1f2/day/$var$/gn/v20200417/',
                         '$var$_day_HadGEM3-GC31-MM_dcppA-hindcast_s$sdate$-r1i1p1f2_gn_$fyear$.nc')
path_hadgem3 <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_hadgem3)
 
 sdate <-  c('2000', '2001')
 fyear_hadgem3 <- indices(1)

  suppressWarnings(
    data <- Start(dat = path_hadgem3,
                  var = 'tasmax',
                  sdate = sdate,
                  fyear = fyear_hadgem3,
                  fyear_depends = 'sdate',
                  time = indices(1:3),
                  lat = indices(1), lon = indices(1),
                  return_vars = list(lat = 'dat', lon = 'dat', time = 'sdate'),
                  retrieve = FALSE)
  )

expect_equal(
  dim(attr(data, 'Variables')$common$time),
  c(sdate = 2, time = 3)
)
 time <- c(as.POSIXct('2000-11-01 12:00:00', tz = 'UTC'), 
           as.POSIXct('2000-11-02 12:00:00', tz = 'UTC'), 
           as.POSIXct('2000-11-03 12:00:00', tz = 'UTC'))
 attr(time, "tzone") <- "UTC"
expect_equal(
  attr(data, 'Variables')$common$time[1, ],
  time
)
 time <- c(
           as.POSIXct('2001-11-01 12:00:00', tz = 'UTC'),
           as.POSIXct('2001-11-02 12:00:00', tz = 'UTC'),
           as.POSIXct('2001-11-03 12:00:00', tz = 'UTC'))
 attr(time, "tzone") <- "UTC"
expect_equal(
  attr(data, 'Variables')$common$time[2, ],
  time
)


})

test_that("2. 365_day, daily, unit = 'days since 1984-01-01'", {
path_bcc_csm2 <- '/esarchive/exp/CMIP6/dcppA-hindcast/BCC-CSM2-MR/DCPP/BCC/BCC-CSM2-MR/dcppA-hindcast/r1i1p1f1/day/$var$/gn/v20200114/$var$_day_BCC-CSM2-MR_dcppA-hindcast_s$sdate$-r1i1p1f1_gn_19800101-19891231.nc'
path_bcc_csm2 <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_bcc_csm2)

suppressWarnings(
  data <- Start(dat = path_bcc_csm2,
                var = 'tasmax',
                sdate = '1980',
                time = indices(1:3),
                lat = indices(1),
                lon = indices(1),
                return_vars = list(lat = 'dat', lon = 'dat', time = 'sdate'),
                retrieve = FALSE) 
)

expect_equal(
  dim(attr(data, 'Variables')$common$time),
  c(sdate = 1, time = 3)
)
 time <- c(as.POSIXct('1980-01-01 12:00:00', tz = 'UTC'),
           as.POSIXct('1980-01-02 12:00:00', tz = 'UTC'),
           as.POSIXct('1980-01-03 12:00:00', tz = 'UTC'))
 attr(time, "tzone") <- "UTC"
expect_equal(
  attr(data, 'Variables')$common$time[1, ],
  time
)


})


test_that("3. standard, daily, unit = 'days since 1850-1-1 00:00:00'", {
  path_mpi_esm <- paste0('/esarchive/exp/CMIP6/dcppA-hindcast/MPI-ESM1-2-HR/',
                         'DCPP/MPI-M/MPI-ESM1-2-HR/',
                         'dcppA-hindcast/r1i1p1f1/day/$var$/gn/v20200101/',
                         '$var$_day_MPI-ESM1-2-HR_dcppA-hindcast_s$sdate$-r1i1p1f1_gn_$fyear$.nc')
  path_mpi_esm <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_mpi_esm)

  var <- 'tasmax'
  sdate <- '2000'
  fyear_mpi_esm <- paste0(sdate, '1101-', as.numeric(sdate) + 10, '1231')

suppressWarnings(
  data <- Start(dat = path_mpi_esm,
                var = var,
                sdate = sdate,
                fyear = fyear_mpi_esm,
                fyear_depends = 'sdate',
                time = indices(1:3),
                lat = indices(1),
                lon = indices(1),
                return_vars = list(lat = 'dat', lon = 'dat', time = 'sdate'),
                retrieve = FALSE) 
)

expect_equal(
  dim(attr(data, 'Variables')$common$time),
  c(sdate = 1, time = 3)
)
 time <- c(as.POSIXct('2000-11-01 12:00:00', tz = 'UTC'),
           as.POSIXct('2000-11-02 12:00:00', tz = 'UTC'),
           as.POSIXct('2000-11-03 12:00:00', tz = 'UTC'))
 attr(time, "tzone") <- "UTC"
expect_equal(
  attr(data, 'Variables')$common$time[1, ],
  time
)


})

test_that("4. standard, monthly, unit = 'days since 1850-1-1 00:00:00'", {

  path_mpi_esm <- paste0('/esarchive/exp/CMIP6/dcppA-hindcast/MPI-ESM1-2-HR/',
                         'DCPP/MPI-M/MPI-ESM1-2-HR/',
                         'dcppA-hindcast/r1i1p1f1/Amon/$var$/gn/v20200320/',
                         '$var$_Amon_MPI-ESM1-2-HR_dcppA-hindcast_s$sdate$-r1i1p1f1_gn_200011-201012.nc')
  path_mpi_esm <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_mpi_esm)

  sdate <- '2000'
  fyear_mpi_esm <- paste0(sdate, '1101-', as.numeric(sdate) + 10, '1231')

suppressWarnings(
  data <- Start(dat = path_mpi_esm,
                var = 'tasmax',
                sdate = '2000',
                time = indices(1:3),
                lat = indices(1),
                lon = indices(1),
                return_vars = list(lat = 'dat', lon = 'dat', time = 'sdate'),
                retrieve = FALSE)
)

expect_equal(
  dim(attr(data, 'Variables')$common$time),
  c(sdate = 1, time = 3)
)
 time <- c(as.POSIXct('2000-11-16 00:00:00', tz = 'UTC'),
           as.POSIXct('2000-12-16 12:00:00', tz = 'UTC'),
           as.POSIXct('2001-01-16 12:00:00', tz = 'UTC'))
 attr(time, "tzone") <- "UTC"
expect_equal(
  attr(data, 'Variables')$common$time[1, ],
  time
)

})

test_that("5. proleptic_gregorian, 6hrly, unit = 'hours since 2000-11-01 00:00:00'", {
  repos_obs <- paste0('/esarchive/recon/ecmwf/erainterim/6hourly/',
                      '$var$/$var$_199405.nc')
  repos_obs <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos_obs)
  date <- paste0('1994-05-', sprintf('%02d', 1:31), ' 00:00:00')
  date <- as.POSIXct(date, tz = 'UTC')
#  attr(date, 'tzone') <- 'UTC'

suppressWarnings(
  data <- Start(dat = repos_obs,
                var = 'tas',
                time = date, 
                latitude = indices(1),
                longitude = indices(1),
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = NULL),
                retrieve = TRUE)
)

expect_equal(
  as.vector(attr(data, 'Variables')$common$time[1:31]),
  as.vector(date)
)
expect_equal(
  as.vector(data)[1:5],
  c(255.0120, 256.8095, 254.3654, 254.6059, 257.0551),
  tolerance = 0.0001
)
expect_equal(
  as.vector(data)[length(data)],
  c(268.2216),
  tolerance = 0.0001
)
})

test_that("6. standard, monthly, unit = 'months since 1850-01-01 00:00:00'", {

  repos_obs <- '/esarchive/obs/ukmo/hadisst_v1.1/monthly_mean/$var$/$var$_$date$.nc'
  repos_obs <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos_obs)

suppressWarnings(
  obs <- Start(dat = repos_obs,
               var = 'tos',
               date = '200505', #dates_file,
               time = 'all',
               lat = indices(1),
               lon = indices(1),
               time_across = 'date',
               #combine time and file_date dims 
               merge_across_dims = TRUE,
               #exclude the additional NAs generated by merge_across_dims
               merge_across_dims_narm = TRUE,
               synonims = list(lat = c('lat', 'latitude'),
                               lon = c('lon', 'longitude')),
               return_vars = list(lat = 'dat',
                                  lon = 'dat',
                                  time = 'date'),
               retrieve = FALSE)
)

expect_equal(
  attr(obs, 'Variables')$common$time[1], 
  as.POSIXct('2005-05-16 12:00:00', tz = 'UTC')
)
expect_equal(
  dim(attr(obs, 'Variables')$common$time),
  c(time = 1)
)

suppressWarnings(
data_obs <- Start(dat = repos_obs,
                  var = 'tos',
                  date = c("196011", "196012", "196101", "196102"),
                  latitude = indices(100),
                  longitude = indices(100),
                  synonims = list(longitude = c('lon', 'longitude'),
                                  latitude = c('lat', 'latitude')),
                  return_vars = list(time = c('date'),
                                     latitude = NULL, longitude = NULL),
                  retrieve = TRUE)
)

expect_equal(
dim(attr(data_obs, 'Variables')$common$time),
c(date = 4, time = 1)
)
expect_equal(
as.character(attr(data_obs, 'Variables')$common$time),
c("1960-11-16 00:00:00", "1960-12-16 12:00:00", "1961-01-16 12:00:00", "1961-02-15 00:00:00")
)

})


test_that("7. proleptic_gregorian, monthly, unit = 'days since 1850-1-1 00:00:00'", {

  repos <- '/esarchive/exp/mpi-esm-lr/cmip5-historical_i0p1/monthly_mean/$var$/$var$_$sdate$.nc'
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
  data <- Start(dat = repos,
                var = 'tas',
                sdate = '20000101',
                time = indices(1:3),
                ensemble = indices(1),
                latitude = indices(1:4),
                longitude = indices(1:3),
                return_vars = list(time = NULL))
)
  time <- c(as.POSIXct('2000-01-16 12:00:00', tz = 'UTC'),
            as.POSIXct('2000-02-15 12:00:00', tz = 'UTC'),
            as.POSIXct('2000-03-16 12:00:00', tz = 'UTC'))
 attr(time, "tzone") <- "UTC"

  expect_equal(
    attr(data, 'Variables')$common$time[1],
    time[1]
  )
  expect_equal(
    attr(data, 'Variables')$common$time[2],
    time[2]
  )
  expect_equal(
    attr(data, 'Variables')$common$time[3],
    time[3]
  )

})

test_that("8. gregorian, 3hrly, unit = 'days since 1850-1-1'", {
  repos <- '/esarchive/exp/CMIP5/historical/ecearth/cmip5-historical_i0p1/$var$_3hr_EC-EARTH_historical_r6i1p1_$period$.nc'
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
 suppressWarnings(
 data <- Start(dat = repos,
                var = 'vas',
                period = '200501010300-200601010000',
                time = indices(1:3),
                lat = indices(1:4),
                lon = indices(1:3),
                return_vars = list(time = NULL)) 
)
  time <- c(as.POSIXct('2005-01-01 03:00:00', tz = 'UTC'),
            as.POSIXct('2005-01-01 06:00:00', tz = 'UTC'),
            as.POSIXct('2005-01-01 09:00:00', tz = 'UTC'))
  attr(time, "tzone") <- "UTC"
 
  expect_equal(
    attr(data, 'Variables')$common$time[1],
    time[1]
  )
  expect_equal(
    attr(data, 'Variables')$common$time[2],
    time[2]
  )
  expect_equal(
    attr(data, 'Variables')$common$time[3],
    time[3]
  )

})

}) #suppressMessages
