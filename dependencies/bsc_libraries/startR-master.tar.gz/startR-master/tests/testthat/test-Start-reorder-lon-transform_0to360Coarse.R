suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

#1 selector type        1-values(list)  2-values(vector)  3-indices     4-'all'  5-mix
#2 selector range       1-[10, 20]      2-[20, 10]        3-[-10, -20]  4-[-20, -10]  5-[-10, 10]  6-[10, -10]  7-[300, 350]  8-[350, 370]
#3 resolution           1-1     2-<1    3->1 4 -> mixed   
#4 returns_var          1-NULL  2-'dat'                 
#5 lat_reorder/Sort()   1-No    2-Yes,decreasing = F    3-Yes,decreasing = T
#6 lon_reorder/CircularSort()   1-No    2-Yes,(0, 360)  3-Yes,(-180, 180)       
#7 transform            1-NO    2-'r360x181'    
#8 transform_crop       1-T     2-F     3-region    4-x

##############################################
# 3-2
## Origin longitude in file: [0:360]
path_exp <- '/esarchive/exp/ncar/cesm-dple/monthly_mean/$var$/$var$_$sdate$.nc'

## Origin longitude in file: [0:358.75] step 1.25 degrees #288 values
## latitude:  -90 o 90 {-90, -89.05759 ...} #192 values

variable <- 'psl'
sdate <- '20001101'

##############################################
test_that("1-1-2-2-1-1-2-4", {
lons.min <- 10
lons.max <- 20
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con', crop = T),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )
})

##############################################
test_that("1-2-2-2-1-1-2-4", {
lons.min <- 20
lons.max <- 10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con', crop = T),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  11
  )
})
##############################################
test_that("1-5-2-2-1-1-2-4", {
lons.min <- -10
lons.max <- 10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con', crop = T),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-10, 10),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
})

##############################################
test_that("1-6-2-2-1-1-2-4", {
lons.min <- 10
lons.max <- -10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con', crop = T),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-10, 10),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
})
##############################################
test_that("1-7-2-2-1-1-2-4", {
lons.min <- 330
lons.max <- 350
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con', crop = T),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(330, 350),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
})
##############################################
#NOTE_18/01/2022: This Start() call returns ERROR now since "crop"
#is decrepated and automatically assigned as c(lons.min, lons.max, lats.min, lats.max). lons.max cannot excess 360. 
#test_that("1-8-2-2-1-1-2-4", {
#lons.min <- 350
#lons.max <- 370
#lats.min <- 10
#lats.max <- 20
#suppressWarnings(
#res <- Start(dat = list(list(path=path_exp)),
#             var = variable,
#             member = indices(1),
#             sdate = sdate,
#             time = indices(4),
#             latitude = values(list(lats.min, lats.max)),
#             longitude = values(list(lons.min, lons.max)),
#             transform = CDORemapper,
#             transform_params = list(grid ='r360x181',
#                                     method = 'con', crop = T),
#             transform_vars = c('longitude', 'latitude'),
#             transform_extra_cells = 2,
#             synonims = list(latitude=c('lat','latitude'),
#                             longitude=c('lon','longitude'),
#                             member=c('ensemble','realization')),
#             return_vars = list(latitude = 'dat',
#                                longitude = 'dat',
#                                time = NULL),
#             retrieve = F)
#)
#  expect_equal(
#  range((attr(res, 'Variables')$dat1$longitude)),
#  c(350, 359),
#  tolerance = 0.0001
#  )
#  expect_equal(
#  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
#  TRUE
#  )
#  expect_equal(
#  length(attr(res, 'Variables')$dat1$longitude),
#  10
#  )
#})
##############################################
##############################################
##############################################
test_that("1-1-2-2-2-2-2-3", {
lons.min <- 10
lons.max <- 20
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)

  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  11 
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )
})
##############################################
test_that("1-2-2-2-2-2-2-3", {
lons.min <- 20
lons.max <- 10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(0, 359),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  351
  )
  expect_equal(
  as.vector((attr(res, 'Variables')$dat1$longitude))[11:12],
  c(10, 20),
  tolerance = 0.0001
  )
})
##############################################
test_that("1-3-2-2-2-2-2-3", {
lons.min <- -10
lons.max <- -20
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(0, 359),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  351
  )
  expect_equal(
  as.vector((attr(res, 'Variables')$dat1$longitude))[341:342],
  c(340, 350),
  tolerance = 0.0001
  )
})
##############################################
test_that("1-4-2-2-2-2-2-3", {
lons.min <- -20
lons.max <- -10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(340, 350),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  11
  )
})
##############################################
test_that("1-5-2-2-2-2-2-3", {
lons.min <- -10
lons.max <- 10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)

  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(0, 359),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
  expect_equal(
  as.vector((attr(res, 'Variables')$dat1$longitude))[11:12],
  c(10, 350),
  tolerance = 0.0001
  )
})
##############################################
test_that("1-6-2-2-2-2-2-3", {
lons.min <- 20
lons.max <- -10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)

  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(20, 350),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  331
  )
})
##############################################
test_that("1-7-2-2-2-2-2-3", {
lons.min <- 330
lons.max <- 350
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(330, 350),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
})
##############################################
test_that("1-8-2-2-2-2-2-3", {
lons.min <- 350
lons.max <- 370
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(0, 359),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
  expect_equal(
  as.vector((attr(res, 'Variables')$dat1$longitude))[11:12],
  c(10, 350),
  tolerance = 0.0001
  )
})
##############################################
##############################################
##############################################
test_that("1-1-2-2-2-3-2-3", {
lons.min <- 10
lons.max <- 20
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )
})
##############################################
test_that("1-2-2-2-2-3-2-3", {
lons.min <- 20
lons.max <- 10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-180, 179),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  351
  )
  expect_equal(
  as.vector((attr(res, 'Variables')$dat1$longitude))[191:192],
  c(10, 20),
  tolerance = 0.0001
  )
})
##############################################
test_that("1-3-2-2-2-3-2-3", {
lons.min <- -10
lons.max <- -20
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-180, 179),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  351
  )
  expect_equal(
  as.vector((attr(res, 'Variables')$dat1$longitude))[161:162],
  c(-20, -10),
  tolerance = 0.0001
  )
})
##############################################
test_that("1-4-2-2-2-3-2-3", {
lons.min <- -20
lons.max <- -10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-20, -10),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  11
  )
})

##############################################
test_that("1-5-2-2-2-3-2-3", {
lons.min <- -10
lons.max <- 10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-10, 10),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
})
##############################################
test_that("1-6-2-2-2-3-2-3", {
lons.min <- 20
lons.max <- -10
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-180, 179),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  331
  )
  expect_equal(
  as.vector((attr(res, 'Variables')$dat1$longitude))[171:172],
  c(-10, 20),
  tolerance = 0.0001
  )
})
##############################################
test_that("1-7-2-2-2-3-2-3", {
lons.min <- 330
lons.max <- 350
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-30, -10),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
})
##############################################
test_that("1-8-2-2-2-3-2-3", {
lons.min <- 350
lons.max <- 370
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = variable,
             member = indices(1),
             sdate = sdate,
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(-10, 10),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  21
  )
})
}) #suppressMessages
