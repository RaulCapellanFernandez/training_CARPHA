suppressMessages({
test_that("ex2_1", {

  repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
  data <- Start(dat = repos,
                var = 'tas',
                sdate = c('20170101', '20180101'),
                ensemble = indices(1:2),
                time = 'all',
                latitude = indices(1:10),
                longitude = indices(1:15),
                return_vars = list(latitude = 'dat', longitude = 'dat', time = 'sdate'),
                retrieve = FALSE)
)
  
  fun_spring <- function(x) {
      y <- s2dv::Season(x,  time_dim = 'time', monini = 1, moninf = 3, monsup = 5)
      return(y)
  }
  
  step1 <- Step(fun = fun_spring,
               target_dims = c('var', 'time'),
               output_dims = c('var', 'time'))
  
  wf1 <- AddStep(data, step1)

suppressWarnings(
  res1 <- Compute(wf1,
              chunks = list(ensemble = 2))
)

expect_equal(
attr(data, 'Dimensions'),
c(dat = 1, var = 1, sdate = 2, ensemble = 2, time = 7, latitude = 10, longitude = 15)
)
expect_equal(
dim(res1$output),
c(var = 1, time = 1, dat = 1, sdate = 2, ensemble = 2, latitude = 10, longitude = 15)
)
expect_equal(
mean(res1$output),
258.3792,
tolerance = 0.0001
)
expect_equal(
res1$output[1,1,1,,2,10,2],
c(256.4469, 260.3636),
tolerance = 0.0001
)




})
}) #suppressMessages
