suppressMessages({
# When data is reshaping (e.g., time_across = 'sdate'), the corresponding attribute should be reshaped too.

test_that("1. time across fyear, fyear depends on sdate", {

repos <- "/esarchive/exp/ecearth/a3w5/original_files/cmorfiles/DCPP/EC-Earth-Consortium/EC-Earth3/dcppA-hindcast/$member$/day/$var$/gr/v20210910/$var$_day_EC-Earth3_dcppA-hindcast_s$sdate$-$member$_gr_$fyear$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
data <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960:1961), 
                      time = 62:426, ## Jan to Dec (initialised in Nov)
                      time_across = 'fyear',
                      merge_across_dims = TRUE,
                      fyear = 'all',
                      fyear_depends = 'sdate', 
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         time = c('sdate', 'fyear')),
                      retrieve = TRUE)
)
dates <- attr(data,'Variables')$common[['time']]

expect_equal(
dim(dates),
c(sdate = 2, time = 365)
)
expect_equal(
dim(drop(data)),
dim(dates)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
as.vector(dates[1, ]),
as.vector(seq(as.POSIXct('1961-01-01 12:00:00', tz = 'UTC'), as.POSIXct('1961-12-31 12:00:00', tz = 'UTC'), by = 'day'))
)
expect_equal(
as.vector(dates[2, ]),
as.vector(seq(as.POSIXct('1962-01-01 12:00:00', tz = 'UTC'), as.POSIXct('1962-12-31 12:00:00', tz = 'UTC'), by = 'day'))
)

# retrieve = FALSE
suppressWarnings(
dataF <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960:1961),
                      time = 62:426, ## Jan to Dec (initialised in Nov)
                      time_across = 'fyear',
                      merge_across_dims = TRUE,
                      fyear = 'all',
                      fyear_depends = 'sdate',
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         time = c('sdate', 'fyear')),
                      retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

})


test_that("2. time across fyear, only one sdate", {

repos <- "/esarchive/exp/ecearth/a3w5/original_files/cmorfiles/DCPP/EC-Earth-Consortium/EC-Earth3/dcppA-hindcast/$member$/day/$var$/gr/v20210910/$var$_day_EC-Earth3_dcppA-hindcast_s$sdate$-$member$_gr_$fyear$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
data <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960),
                      time = 62:426, ## Jan to Dec (initialised in Nov)
                      time_across = 'fyear',
                      merge_across_dims = TRUE,
                      fyear = 'all',
#                      fyear_depends = 'sdate',
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         time = c('fyear')),
                      retrieve = TRUE)
)
dates <- attr(data,'Variables')$common[['time']]


expect_equal(
dim(dates),
c(time = 365)
)
expect_equal(
length(data),
length(dates)
)
expect_equal(
as.vector(dates),
as.vector(seq(as.POSIXct('1961-01-01 12:00:00', tz = 'UTC'), as.POSIXct('1961-12-31 12:00:00', tz = 'UTC'), by = 'day'))
)

#retrieve = FALSE
suppressWarnings(
dataF <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960),
                      time = 62:426, ## Jan to Dec (initialised in Nov)
                      time_across = 'fyear',
                      merge_across_dims = TRUE,
                      fyear = 'all',
#                      fyear_depends = 'sdate',
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         time = c('fyear')),
                      retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

})

test_that("3. time across fyear, fyear depends on sdate, 1st fyear is empty, 3rd fyear has more indices than 2nd one, 1964 is leap year", {

repos <- "/esarchive/exp/ecearth/a3w5/original_files/cmorfiles/DCPP/EC-Earth-Consortium/EC-Earth3/dcppA-hindcast/$member$/day/$var$/gr/v20210910/$var$_day_EC-Earth3_dcppA-hindcast_s$sdate$-$member$_gr_$fyear$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
data <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960:1961),
                      day = 700:860, ## initialised in Nov
                      day_across = 'fyear',
                      merge_across_dims = TRUE,
                      fyear = 'all',
                      fyear_depends = 'sdate',
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude'),
                                      day = c('day', 'time')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         day = c('sdate', 'fyear')),
                      retrieve = TRUE)
)
dates <- attr(data,'Variables')$common[['day']]

expect_equal(
dim(dates),
c(sdate = 2, day = 161)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
as.vector(dates[1, ]),
as.vector(seq(as.POSIXct('1962-10-01 12:00:00', tz = 'UTC'), as.POSIXct('1963-03-10 12:00:00', tz = 'UTC'), by = 'day'))
)
expect_equal(
as.vector(dates[2, ]),
as.vector(seq(as.POSIXct('1963-10-01 12:00:00', tz = 'UTC'), as.POSIXct('1964-03-09 12:00:00', tz = 'UTC'), by = 'day'))
)


suppressWarnings(
dataF <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960:1961),
                      day = 700:860, ## initialised in Nov
                      day_across = 'fyear',
                      merge_across_dims = TRUE,
                      fyear = 'all',
                      fyear_depends = 'sdate',
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude'),
                                      day = c('day', 'time')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         day = c('sdate', 'fyear')),
                      retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['day']]
expect_equal(
datesF,
dates
)

})


test_that("4. merge and split time dim", {
datess <- seq(as.POSIXct('1994-05-01', tz = 'UTC'), as.POSIXct('1994-12-31', tz = 'UTC'), by = 'days') 
datess <- c(datess[c(1:31, 32:62, 62:92, 93:123, 124:154, 154:184, 185:215, 215:245)])
datess <- as.POSIXct(array(datess, dim = c(time = 31, sdate = 8)), 
                    origin = '1970-01-01', tz = 'UTC')
dates_file <- sort(unique(gsub('-', '', sapply(as.character(datess),
                   substr, 1, 7))))

repos <- "/esarchive/recon/ecmwf/erainterim/6hourly/$var$/$var$_$file_date$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
suppressWarnings(
  data <- Start(dat = repos,
                var = 'tas',
                file_date = dates_file,
                time = values(datess), #[time = 31, sdate = 8]
                latitude = indices(1),
                longitude = indices(1),
                time_var = 'time',
                #because time is assigned by 'values', set the tolerance to avoid too distinct match
                time_tolerance = as.difftime(1, units = 'hours'), 
                #time values are across all the files
                time_across = 'file_date',  
                #combine time and file_date dims 
                merge_across_dims = TRUE,
                #exclude the additional NAs generated by merge_across_dims
                merge_across_dims_narm = TRUE,
                #split time dim, because it is two-dimensional
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = 'file_date'),
                retrieve = TRUE)
)

dates <- attr(data,'Variables')$common[['time']]

expect_equal(
dim(dates),
c(time = 31, sdate = 8)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
as.vector(dates),
as.vector(datess)
)

suppressWarnings(
  dataF <- Start(dat = repos, 
                var = 'tas',
                file_date = dates_file,
                time = values(datess), #[time = 31, sdate = 8]
                latitude = indices(1),
                longitude = indices(1),
                time_var = 'time',
                #because time is assigned by 'values', set the tolerance to avoid too distinct match
                time_tolerance = as.difftime(1, units = 'hours'),
                #time values are across all the files
                time_across = 'file_date',
                #combine time and file_date dims 
                merge_across_dims = TRUE,
                #exclude the additional NAs generated by merge_across_dims
                merge_across_dims_narm = TRUE,
                #split time dim, because it is two-dimensional
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = 'file_date'),
                retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

})

test_that("5. test 1 but merge_across_dims_narm = F", {


repos <- "/esarchive/exp/ecearth/a3w5/original_files/cmorfiles/DCPP/EC-Earth-Consortium/EC-Earth3/dcppA-hindcast/$member$/day/$var$/gr/v20210910/$var$_day_EC-Earth3_dcppA-hindcast_s$sdate$-$member$_gr_$fyear$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
data <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960:1961),
                      time = 62:426, ## Jan to Dec (initialised in Nov)
                      time_across = 'fyear',
                      merge_across_dims = TRUE,
                      merge_across_dims_narm = F,
                      fyear = 'all',
                      fyear_depends = 'sdate',
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         time = c('sdate', 'fyear')),
                      retrieve = TRUE)
)
dates <- attr(data,'Variables')$common[['time']]

expect_equal(
dim(dates),
c(sdate = 2, time = 608)
)
expect_equal(
dim(drop(data)),
dim(dates)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
as.vector(dates[1, ]),
c(as.vector(seq(as.POSIXct('1961-01-01 12:00:00', tz = 'UTC'), as.POSIXct('1961-12-31 12:00:00', tz = 'UTC'), by = 'day')), rep(NA, 243))
)
expect_equal(
as.vector(dates[2, ]),
c(as.vector(seq(as.POSIXct('1962-01-01 12:00:00', tz = 'UTC'), as.POSIXct('1962-12-31 12:00:00', tz = 'UTC'), by = 'day')), rep(NA, 243))
)

suppressWarnings(
dataF <- Start(dat = repos,
                      var = 'tasmin',
                      lat = indices(1),
                      lon = indices(1),
                      sdate = paste0(1960:1961),
                      time = 62:426, ## Jan to Dec (initialised in Nov)
                      time_across = 'fyear',
                      merge_across_dims = TRUE,
                      merge_across_dims_narm = F,
                      fyear = 'all',
                      fyear_depends = 'sdate',
                      member = 'r1i4p1f1',
                      synonims = list(lat = c('lat','latitude'),
                                      lon = c('lon','longitude')),
                      return_vars = list(lat = NULL, lon = NULL,
                                         time = c('sdate', 'fyear')),
                      retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

})

test_that("6. split time dim only", {

datess <- seq(as.POSIXct('1994-07-01', tz = 'UTC'), as.POSIXct('1994-07-14', tz = 'UTC'), by = 'days')
datess <- as.POSIXct(array(datess, dim = c(time = 7, week = 2)),
                     origin = '1970-01-01', tz = 'UTC')
repos <- '/esarchive/recon/ecmwf/erainterim/6hourly/$var$/$var$_199407.nc'
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
data <- Start(dat = repos,
                var = 'tas',
#                file_date = '199407',
                time = values(datess), #[time = 7, week = 2]
                latitude = indices(1),
                longitude = indices(1),
                time_var = 'time',
                time_tolerance = as.difftime(1, units = 'hours'),
#                time_across = 'file_date',
#                merge_across_dims = TRUE,
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = NULL), #'file_date'),
                retrieve = TRUE)
)
dates <- attr(data,'Variables')$common[['time']]


expect_equal(
dim(dates),
c(time = 7, week = 2)
)
expect_equal(
dim(drop(data)),
dim(dates)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
as.vector(dates[, ]),
as.vector(seq(as.POSIXct('1994-07-01', tz = 'UTC'), as.POSIXct('1994-07-14', tz = 'UTC'), by = 'day'))
)

suppressWarnings(
dataF <- Start(dat = repos,
                var = 'tas',
#                file_date = '199407',
                time = values(datess), #[time = 7, week = 2]
                latitude = indices(1),
                longitude = indices(1),
                time_var = 'time',
                time_tolerance = as.difftime(1, units = 'hours'),
#                time_across = 'file_date',
#                merge_across_dims = TRUE,
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = NULL), #'file_date'),
                retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

})

test_that("7. split dim + merge + merge_narm = F", {

datess <- seq(as.POSIXct('1994-07-01', tz = 'UTC'), as.POSIXct('1994-08-31', tz = 'UTC'), by = 'days')
datess <- as.POSIXct(array(datess, dim = c(time = 31, month = 2)),
                     origin = '1970-01-01', tz = 'UTC')

repos <- '/esarchive/recon/ecmwf/erainterim/6hourly/$var$/$var$_$file_date$.nc'
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
suppressWarnings(
data <- Start(dat = repos,
                var = 'tas',
                file_date = c('199407', '199408'),
                time = values(datess), #[time = 31, month = 2]
                latitude = indices(1),
                longitude = indices(1),
                time_var = 'time',
                time_tolerance = as.difftime(1, units = 'hours'),
                time_across = 'file_date',
                merge_across_dims = TRUE,
                merge_across_dims_narm = F,
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = 'file_date'),
                retrieve = TRUE)
)
dates <- attr(data,'Variables')$common[['time']]


expect_equal(
dim(dates),
c(time = 31, month = 2)
)
expect_equal(
dim(drop(data)),
dim(dates)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
as.vector(dates[, ]),
as.vector(seq(as.POSIXct('1994-07-01', tz = 'UTC'), as.POSIXct('1994-08-31', tz = 'UTC'), by = 'day'))
)

suppressWarnings(
dataF <- Start(dat = repos,
                var = 'tas',
                file_date = c('199407', '199408'),
                time = values(datess), #[time = 31, month = 2]
                latitude = indices(1),
                longitude = indices(1),
                time_var = 'time',
                time_tolerance = as.difftime(1, units = 'hours'),
                time_across = 'file_date',
                merge_across_dims = TRUE,
                merge_across_dims_narm = F,
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = 'file_date'),
                retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

})


test_that("8. split sdate dim", {

file_date <- array(c(paste0(1993:1995, '07'), paste0(1993:1995, '08')),
                   dim = c(syear = 3, smonth = 2))
repos <- '/esarchive/recon/ecmwf/erainterim/6hourly/$var$/$var$_$file_date$.nc'
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
suppressWarnings(
data <- Start(dat = repos,
                var = 'tas',
                file_date = file_date, #[syear = 3, smonth = 2]
                time = indices(1:2), 
                latitude = indices(1),
                longitude = indices(1),
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = 'file_date'),
                retrieve = TRUE)
)
dates <- attr(data,'Variables')$common[['time']]


expect_equal(
dim(dates),
c(syear = 3, smonth = 2, time = 2)
)
expect_equal(
dim(drop(data)),
dim(dates)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
dates[, 1, 1],
seq(as.POSIXct('1993-07-01', tz = 'UTC'), as.POSIXct('1995-07-01', tz = 'UTC'), by = 'year')
)
expect_equal(
dates[, 2, 2],
seq(as.POSIXct('1993-08-01 06:00:00', tz = 'UTC'), as.POSIXct('1995-08-01 06:00:00', tz = 'UTC'), by = 'year')
)

suppressWarnings(
dataF <- Start(dat = repos,
                var = 'tas',
                file_date = file_date, #[syear = 3, smonth = 2]
                time = indices(1:2),
                latitude = indices(1),
                longitude = indices(1),
                split_multiselected_dims = TRUE,
                return_vars = list(latitude = NULL,
                                   longitude = NULL,
                                   time = 'file_date'),
                retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

# no return_vars
suppressWarnings(
data <- Start(dat = repos,
                var = 'tas',
                file_date = file_date, #[syear = 3, smonth = 2]
                time = indices(1:2),
                latitude = indices(1),
                longitude = indices(1),
                split_multiselected_dims = TRUE,
#                return_vars = list(latitude = NULL,
#                                   longitude = NULL,
#                                   time = 'file_date'),
                retrieve = TRUE)
)
expect_equal(
names(attributes(data)$Variables$common),
'tas'
)

suppressWarnings(
data <- Start(dat = repos,
                var = 'tas',
                file_date = file_date, #[syear = 3, smonth = 2]
                time = indices(1:2),
                latitude = indices(1),
                longitude = indices(1),
                split_multiselected_dims = TRUE,
#                return_vars = list(latitude = NULL,
#                                   longitude = NULL,
#                                   time = 'file_date'),
                retrieve = FALSE)
)
expect_equal(
names(attributes(data)$Variables$common),
"tas"
)

})

test_that("9. split file dim that contains 'time', and 'time' inner dim is implicit", {

dates_arr <- array(c(paste0(1961, '0', 1:5), paste0(1962, '0', 1:5)), dim = c(time = 5, syear = 2))

repos <- "/esarchive/recon/jma/jra55/monthly_mean/$var$_f6h/$var$_$file_date$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
data <- Start(dat = repos,
              var = 'tas',
              file_date = dates_arr, # [syear, time]
              split_multiselected_dims = TRUE,
              latitude = indices(1),
              longitude = indices(1),
              synonims = list(latitude = c('lat','latitude'),
                              longitude = c('lon','longitude')),
              return_vars = list(latitude = NULL, longitude = NULL,
                                 time = 'file_date'),
              retrieve = TRUE)
)

dates <- attr(data, 'Variables')$common$time


expect_equal(
dim(dates),
c(time = 5, syear = 2)
)
expect_equal(
dim(drop(data)),
dim(dates)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
format(dates, '%Y%m'),
as.vector(dates_arr)
)


suppressWarnings(
dataF <- Start(dat = repos,
              var = 'tas',
              file_date = dates_arr, # [syear, time]
              split_multiselected_dims = TRUE,
              latitude = indices(1),
              longitude = indices(1),
              synonims = list(latitude = c('lat','latitude'),
                              longitude = c('lon','longitude')),
              return_vars = list(latitude = NULL, longitude = NULL,
                                 time = 'file_date'),
              retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)

})

test_that("10. implicit dependency, leap year", {

a <- as.POSIXct('1995-02-27 18:00:00', tz = 'UTC')
b <- as.POSIXct('1995-03-01 18:00:00', tz = 'UTC')
y1 <- seq(a, b, by = 'days')
a <- as.POSIXct('1996-02-27 18:00:00', tz = 'UTC')
b <- as.POSIXct('1996-03-01 18:00:00', tz = 'UTC')
y2 <- seq(a, b, by = 'days')
y2 <- y2[-3]  # remove 28 Feb
time_array <- array(c(y1, y2), dim = c(time = 3, file_date = 2))
time_array <- as.POSIXct(time_array, origin = '1970-01-01', tz = 'UTC')
repos <- "/esarchive/exp/ecmwf/system5c3s/daily_mean/$var$_f6h/$var$_$file_date$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
suppressWarnings(
data <- Start(dat = repos,
              var = "tas",
              file_date = paste0(1994:1995, '1101'),  #1996 is leap year
              time = time_array, #[time = 3, file_date = 2]
              latitude = indices(1), longitude = indices(1), ensemble = indices(1),
                return_vars = list(latitude = NULL, longitude = NULL, time = 'file_date'),
                retrieve = TRUE)
)
dates <- attr(data, 'Variables')$common$time

expect_equal(
dim(dates),
c(file_date = 2, time = 3)
)
expect_equal(
dim(drop(data)),
dim(dates)
)
expect_equal(
length(attributes(dates)),
4
)
expect_equal(
all(names(attributes(dates)) %in% c('variables', 'dim', 'class', 'tzone')),
TRUE
)
expect_equal(
class(dates),
c("POSIXct", "POSIXt")
)
expect_equal(
as.vector(aperm(dates, 2:1)),
as.vector(time_array)
)

suppressWarnings(
dataF <- Start(dat = repos,
              var = "tas",
              file_date = paste0(1994:1995, '1101'),  #1996 is leap year
              time = time_array, #[time = 3, file_date = 2]
              latitude = indices(1), longitude = indices(1), ensemble = indices(1),
                return_vars = list(latitude = NULL, longitude = NULL, time = 'file_date'),
                retrieve = FALSE)
)
datesF <- attr(dataF,'Variables')$common[['time']]
expect_equal(
datesF,
dates
)


})

}) #suppressMessages
