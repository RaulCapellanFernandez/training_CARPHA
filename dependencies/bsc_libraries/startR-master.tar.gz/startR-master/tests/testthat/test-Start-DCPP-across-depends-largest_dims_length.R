suppressMessages({
test_that("Chunks of DCPP files with largest_dims_length = TRUE - Local execution", {
  path <- '/esarchive/exp/CMIP6/dcppA-hindcast/HadGEM3-GC31-MM/DCPP/MOHC/HadGEM3-GC31-MM/dcppA-hindcast/r1i1p1f2/Omon/tos/gn/v20200417/$var$_Omon_HadGEM3-GC31-MM_dcppA-hindcast_s$sdate$-r1i1p1f2_gn_$chunk$.nc'
  path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

  sdates <- c('2017', '2018')
suppressWarnings(
  dat1 <- Start(dat = path,
                var = 'tos',
                sdate = sdates,
                chunk = 'all',
                chunk_depends = 'sdate',
                time = indices(1:15),
                i = indices(450:452),
                j = indices(650:651),
                time_across = 'chunk',
                merge_across_dims = TRUE,
                largest_dims_length = TRUE,
                retrieve = TRUE,
                return_vars = list(time = 'sdate'))
)

# Start at chunk 2 (skip time steps in the first file)
suppressWarnings(
  dat2 <- Start(dat = path,
                var = 'tos',
                sdate = sdates,
                chunk = 'all',
                chunk_depends = 'sdate',
                time = indices(3:15),
                i = indices(450:452),
                j = indices(650:651),
                time_across = 'chunk',
                merge_across_dims = TRUE,
                largest_dims_length = TRUE,
                retrieve = TRUE,
                return_vars = list(time = 'sdate'))
)

expect_equal(dat1[1, 1, 1:2, 3:15, , ], dat2[1, 1, 1:2, , , ])

# Start at chunk 3 (skip time steps in the first and second files)
suppressWarnings(
  dat3 <- Start(dat = path,
                var = 'tos',
                sdate = sdates,
                chunk = 'all',
                chunk_depends = 'sdate',
                time = indices(15),
                i = indices(450:452),
                j = indices(650:651),
                time_across = 'chunk',
                merge_across_dims = TRUE,
                largest_dims_length = TRUE,
                retrieve = TRUE,
                return_vars = list(time = 'sdate'))
)

expect_equal(dat1[1, 1, 1:2, 15, , ], dat3[1, 1, 1:2, , , ])

})

}) #suppressMessages
