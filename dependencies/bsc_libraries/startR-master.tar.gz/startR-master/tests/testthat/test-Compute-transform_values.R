suppressMessages({
# Using values() to assign lat and lon, and transform the data. 
# Also test transform + chunk along lat/lon.

#####################################################################
#####################################################################
#####################################################################

test_that("1. Global", {
#skip_on_cran()

lons.min <- 0
lons.max <- 359.9
lats.min <- -90
lats.max <- 90

# crop = region
#NOTE: res1 and res3 differ if extra_cells = 2. But if retrieve = T, extra_cells = 2 or 8 is equal.

path <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50', 
                                     method = 'con'),
#                                     crop = c(lons.min, lons.max, lats.min, lats.max)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= F)
)
func <- function(exp) {
  return(exp)
}
step <- Step(func,
             target_dims = 'sdate', output_dims = 'sdate')
wf <- AddStep(exp, step)

#---
suppressWarnings(
resT <- eval(exp)
)

suppressWarnings(
res1 <- Compute(wf, chunks = list(latitude = 2, longitude = 2))$output1
)
#suppressWarnings(
#res2 <- Compute(wf, chunks = list(ensemble = 1))$output1
#)
suppressWarnings(
res3 <- Compute(wf, chunks = list(longitude = 3))$output1
)

expect_equal(
dim(res1),
c(sdate = 1, dat = 1, var = 1, ensemble = 1, time = 1, latitude = 50, longitude = 100)
)
expect_equal(
as.vector(res1),
as.vector(resT)
)
expect_equal(
res1,
res3
)

expect_equal(
drop(res1)[1:5, 1],
c(241.8592, 243.7243, 248.7337, 247.9308, 252.0744),
tolerance = 0.001
)
expect_equal(
drop(res1)[23:28, 2],
c(298.0772, 299.4716, 299.7746, 300.2744, 300.3914, 299.5223),
tolerance = 0.001
)
expect_equal(
mean(res1),
276.3901,
tolerance = 0.001
)
#--------------------------------------------------

# crop = region, selector is values(c())
library(easyNCDF)
pathh <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/tas_f6h/tas_20000101.nc"
pathh <- paste0('/esarchive/scratch/aho/startR_unittest_files/', pathh)

file <- NcOpen(pathh)
arr <- NcToArray(file,
                 dim_indices = list(time = 1, ensemble = 1,
                                    latitude = 1:640, longitude = 1:1296),
                 vars_to_read = 'tas')
lats <- NcToArray(file,
                  dim_indices = list(latitude = 1:640), vars_to_read = 'latitude')
lons <- NcToArray(file,
                  dim_indices = list(longitude = 1:1296), vars_to_read = 'longitude')
NcClose(file)

path <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(as.vector(lats)),
             latitude_reorder = Sort(),
             longitude = values(as.vector(lons)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50', 
                                     method = 'con'),
#                                     crop = c(lons.min, lons.max, lats.min, lats.max)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= F)
)
func <- function(exp) {
  return(exp)
}
step <- Step(func,
             target_dims = 'sdate', output_dims = 'sdate')
wf <- AddStep(exp, step)

#---
suppressWarnings(
res1_vector <- Compute(wf, chunks = list(latitude = 2, longitude = 2))$output1
)
expect_equal(
res1,
res1_vector
)

#-----------------------------------------------------------------

# crop = region, CircularSort(-180, 180)
lons.min <- -180
lons.max <- 179.9
lats.min <- -90
lats.max <- 90

path <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50', 
                                     method = 'con'),
#                                     crop = c(lons.min, lons.max, lats.min, lats.max)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve = F)
)
func <- function(exp) {
  return(exp)
}
step <- Step(func,
             target_dims = 'sdate', output_dims = 'sdate')
wf <- AddStep(exp, step)

#---
suppressWarnings(
resT_180 <- eval(exp)
)
suppressWarnings(
res1_180 <- Compute(wf, chunks = list(latitude = 2, longitude = 2))$output1
)
#suppressWarnings(
#res2_180 <- Compute(wf, chunks = list(ensemble = 1))$output1
#)
suppressWarnings(
res3_180 <- Compute(wf, chunks = list(longitude = 3))$output1
)

expect_equal(
as.vector(drop(res1)[, c(51:100, 1:50)]),
as.vector(res1_180),
tolerance = 0.0001
)
expect_equal(
as.vector(res1_180),
as.vector(resT_180)
)
expect_equal(
res1_180,
res3_180
)

})

############################################################################
############################################################################
############################################################################

# The numbers below are consistent with the result of this script.
#pathh <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/tas_f6h/tas_20000101.nc"
#file <- NcOpen(pathh)
#arr <- NcToArray(file,
#                 dim_indices = list(time = 1, ensemble = 1,
#                                    latitude = 171:257, longitude = 30:81),
#                 vars_to_read = 'tas')
#lats <- NcToArray(file,
#                  dim_indices = list(latitude = 171:257), vars_to_read = 'latitude')
#lons <- NcToArray(file,
#                  dim_indices = list(longitude = 30:81), vars_to_read = 'longitude')
#NcClose(file)
#
#arr2 <- s2dv::CDORemap(arr, lons = as.vector(lons), lats = as.vector(lats),
#                       grid = 'r100x50', method = 'con', crop = c(10, 20, 20, 40))

test_that("2. Regional, no border", {

#skip_on_cran()

lons.min <- 10
lons.max <- 20
lats.min <- 20
lats.max <- 40

# crop = region
path <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101', #paste0(2000:2001, '0101'),
             ensemble = indices(1), #'all',
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50', 
                                     method = 'con'),
#                                     crop = c(lons.min, lons.max, lats.min, lats.max)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 16, #8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL, #'dat',
                                longitude = NULL, #'dat',
                                time = 'sdate'),
             retrieve= F)
)
func <- function(exp) {
  return(exp)
}
step <- Step(func,
             target_dims = 'sdate', output_dims = 'sdate')
wf <- AddStep(exp, step)

#---
suppressWarnings(
resT <- eval(exp)
)
suppressWarnings(
res1 <- Compute(wf, chunks = list(latitude = 2, longitude = 2))$output1
)
#suppressWarnings(
#res2 <- Compute(wf, chunks = list(ensemble = 1))$output1
#)
suppressWarnings(
res3 <- Compute(wf, chunks = list(longitude = 3))$output1
)

expect_equal(
dim(res1),
c(sdate = 1, dat = 1, var = 1, ensemble = 1, time = 1, latitude = 5, longitude = 3)
)
expect_equal(
as.vector(res1),
as.vector(resT)
)
expect_equal(
res1,
res3
)

expect_equal(
drop(res1)[, 1],
c(284.9907, 282.9883, 281.2574, 284.1387, 285.6547),
tolerance = 0.0001
)
expect_equal(
drop(res1)[, 2],
c(285.4820, 282.9362, 282.6088, 287.3716, 285.0194),
tolerance = 0.0001
)
expect_equal(
drop(res1)[, 3],
c(286.1208, 284.3523, 285.9198, 287.7389, 286.1099),
tolerance = 0.0001
)

#-------------------------------------------------------

# The region borders do not exist in the original grid value. For example,
# the original grid is [longitude = 1296], so 11 and 21 do not exist there
# (but 10 and 20 do, in the cases above)
lons.min <- 11
lons.max <- 21
lats.min <- 21
lats.max <- 41

# crop = region
path <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101', #paste0(2000:2001, '0101'),
             ensemble = indices(1), #'all',
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50', 
                                     method = 'con'),
#                                     crop = c(lons.min, lons.max, lats.min, lats.max)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL, #'dat',
                                longitude = NULL, #'dat',
                                time = 'sdate'),
             retrieve= F)
)
func <- function(exp) {
  return(exp)
}
step <- Step(func,
             target_dims = 'sdate', output_dims = 'sdate')
wf <- AddStep(exp, step)

#---
suppressWarnings(
resT <- eval(exp)
)
suppressWarnings(
res1 <- Compute(wf, chunks = list(latitude = 2, longitude = 2))$output1
)
#suppressWarnings(
#res2 <- Compute(wf, chunks = list(ensemble = 1))$output1
##)
suppressWarnings(
res3 <- Compute(wf, chunks = list(latitude = 3))$output1
)

expect_equal(
dim(res1),
c(sdate = 1, dat = 1, var = 1, ensemble = 1, time = 1, latitude = 5, longitude = 2)
)
expect_equal(
as.vector(res1),
as.vector(resT)
)
expect_equal(
res1,
res3
)

expect_equal(
drop(res1)[, 1],
c(285.4820, 282.9362, 282.6088, 287.3716, 285.0194),
tolerance = 0.0001
)
expect_equal(
drop(res1)[, 2],
c(286.1208, 284.3523, 285.9198, 287.7389, 286.1099),
tolerance = 0.0001
)

})

############################################################################
############################################################################
############################################################################

# The numbers below are consistent with the result of this script.
#pathh <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/tas_f6h/tas_20000101.nc"
#file <- NcOpen(pathh)
#arr <- NcToArray(file,
#                 dim_indices = list(time = 1, ensemble = 1,
#                                    latitude = 171:257, longitude = c(1:81, 1289:1296)),
#                 vars_to_read = 'tas')
#lats <- NcToArray(file,
#                  dim_indices = list(latitude = 171:257), vars_to_read = 'latitude')
#lons <- NcToArray(file,
#                  dim_indices = list(longitude = c(1:81, 1289:1296)), vars_to_read = 'longitude')
#NcClose(file)
#
#arr2 <- s2dv::CDORemap(arr, lons = as.vector(lons), lats = as.vector(lats),
#                       grid = 'r100x50', method = 'con', crop = c(0, 20, 20, 40))


test_that("3. Regional, at lon border", {
#skip_on_cran()

lons.min <- 0
lons.max <- 20
lats.min <- 20
lats.max <- 40

#NOTE: transform_extra_cells = 8 the results are not equal
# crop = region
path <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50', 
                                     method = 'con'),
#                                     crop = c(lons.min, lons.max, lats.min, lats.max)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 16, #8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL, 
                                time = 'sdate'),
             retrieve= F)
)
func <- function(exp) {
  return(exp)
}
step <- Step(func,
             target_dims = 'sdate', output_dims = 'sdate')
wf <- AddStep(exp, step)

#---
suppressWarnings(
resT <- eval(exp)
)
suppressWarnings(
res1 <- Compute(wf, chunks = list(latitude = 2, longitude = 2))$output1
)
#suppressWarnings(
#res2 <- Compute(wf, chunks = list(ensemble = 1))$output1
#)
suppressWarnings(
res3 <- Compute(wf, chunks = list(longitude = 3))$output1
)

expect_equal(
dim(res1),
c(sdate = 1, dat = 1, var = 1, ensemble = 1, time = 1, latitude = 5, longitude = 6)
)
expect_equal(
as.vector(res1),
as.vector(resT)
)
expect_equal(
res1,
res3
)

expect_equal(
drop(res1)[, 1],
c(286.4231, 283.8847, 280.4234, 277.7688, 284.3575),
tolerance = 0.001
)
expect_equal(
drop(res1)[, 2],
c(288.0916, 283.9386, 280.9974, 278.4432, 284.8728),
tolerance = 0.001
)
expect_equal(
drop(res1)[, 3],
c(285.7436, 283.1867, 281.7465, 280.2615, 284.6408),
tolerance = 0.001
)
expect_equal(
drop(res1)[, 4],
c(284.9907, 282.9883, 281.2574, 284.1387, 285.6547),
tolerance = 0.001
)
expect_equal(
drop(res1)[, 5],
c(285.4820, 282.9362, 282.6088, 287.3716, 285.0194),
tolerance = 0.001
)
expect_equal(
drop(res1)[, 6],
c(286.1208, 284.3523, 285.9198, 287.7389, 286.1099),
tolerance = 0.001
)


#--------------------------------------------------------------

# crop = region, CircularSort(-180, 180)
#NOTE: transform_extra_cells = 8 the results are not equal
path <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50', 
                                     method = 'con'),
#                                     crop = c(lons.min, lons.max, lats.min, lats.max)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 16, #8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL, 
                                time = 'sdate'),
             retrieve = F)
)
func <- function(exp) {
  return(exp)
}
step <- Step(func,
             target_dims = 'sdate', output_dims = 'sdate')
wf <- AddStep(exp, step)

#---
suppressWarnings(
resT_180 <- eval(exp)
)
suppressWarnings(
res1_180 <- Compute(wf, chunks = list(latitude = 2, longitude = 2))$output1
)
#suppressWarnings(
#res2_180 <- Compute(wf, chunks = list(ensemble = 1))$output1
#)
suppressWarnings(
res3_180 <- Compute(wf, chunks = list(longitude = 3))$output1
)

expect_equal(
res1,
res1_180
)
expect_equal(
as.vector(res1_180),
as.vector(resT_180)
)
expect_equal(
res1_180,
res3_180
)

#================================================================

})
}) #suppressMessages
