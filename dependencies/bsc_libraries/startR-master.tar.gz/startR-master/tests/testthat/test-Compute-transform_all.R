suppressMessages({

test_that("1. Chunk along non-lat/lon dim", {
#skip_on_cran()

path <- '/esarchive/exp/ecearth/a1ua/cmorfiles/DCPP/EC-Earth-Consortium/EC-Earth3/dcppA-hindcast/$member$/Amon/$var$/gr/v20190713/$var$_Amon_*_s$sdate$-$member$_gr_$fyear$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
data <- Start(dat = path,
              var = 'tos',
              sdate = paste0(1960),
              time = indices(1:2), #'all',
              lat = 'all',
              lon = 'all',
              fyear = indices(1),
              member = indices(1:2),
              transform = CDORemapper,
              transform_extra_cells = 2,
              transform_params = list(grid = 'r100x50', method = 'conservative'),
              transform_vars = c('lat', 'lon'),
              synonims = list(lon = c('lon', 'longitude'), lat = c('lat', 'latitude')),
              return_vars = list(lat = 'dat', lon = 'dat', time = 'sdate'),
              retrieve = FALSE)
)

func <- function(x) {
  return(x)
}

step <- Step(func, target_dims = c('time'),
             output_dims = 'time')
wf <- AddStep(data, step)

#---
suppressWarnings(
resT <- eval(data)
)
suppressWarnings(
res1 <- Compute(wf, chunks = list(member = 2))
)

expect_equal(
dim(res1$output1),
c(time = 2, dat = 1, var = 1, sdate = 1, lat = 50, lon = 100, fyear = 1, member = 2)
)
expect_equal(
as.vector(resT),
as.vector(res1$output1)
)

})

test_that("2. chunk along lon", {
#skip_on_cran()

#NOTE: the results are not identical when exp has extra cells = 2

path <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
exp <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = 'all', 
             latitude_reorder = Sort(),
             longitude = 'all',
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50',
                                     method = 'con'),
#                                     crop = FALSE),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = 'dat',#NULL,
                                longitude = 'dat',#NULL,
                                time = 'sdate'),
             retrieve = F)
)

  func <- function(x) {
    return(x)
  }
  step <- Step(func, target_dims = 'time', output_dims = 'time')
  wf <- AddStep(exp, step)

#---
suppressWarnings(
resT <- eval(exp)
)
suppressWarnings(
res1 <- Compute(wf, chunks = list(longitude = 2))$output1
)
#suppressWarnings(
#  res2 <- Compute(wf, chunks = list(ensemble = 1))
#)
suppressWarnings(
res3 <- Compute(wf, chunks = list(longitude = 2, latitude = 2))$output1
)
suppressWarnings(
res4 <- Compute(wf, chunks = list(longitude = 3))$output1
)

expect_equal(
as.vector(resT),
as.vector(res1)
)
expect_equal(
res1,
res3
)
expect_equal(
res1,
res4
)

})
}) #suppressMessages
