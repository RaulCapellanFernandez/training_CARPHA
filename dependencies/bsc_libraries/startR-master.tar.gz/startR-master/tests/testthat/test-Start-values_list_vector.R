suppressMessages({
# This unit test tests the consistence between list of values and vector of values.
# 1. transform
# 2. no transform
# 3. transform, indices reversed
# 4. no transform, indices reversed


#-----------------------------------------------------------------
# To get lat and lon vectors
library(easyNCDF)
pathh <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/tas_f6h/tas_20000101.nc"
pathh <- paste0('/esarchive/scratch/aho/startR_unittest_files/', pathh)
file <- NcOpen(pathh)
lats <- NcToArray(file,
                  dim_indices = list(latitude = 1:35), vars_to_read = 'latitude')
lons <- NcToArray(file,
                  dim_indices = list(longitude = 1:33), vars_to_read = 'longitude')
NcClose(file)
#------------------------------------------------------------------

path <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

test_that("1. transform", {

# lat and lon are lists of values
suppressWarnings(
exp1 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(81, 88.2)), 
             latitude_reorder = Sort(),
             longitude = values(list(0, 7.2)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50',
                                     method = 'con',
                                     crop = c(0, 9, 80, 90)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

# lat and lon are vectors of values. This one is a weird usage though...
suppressWarnings(
exp2 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(c(81, 84.6, 88.2)),
             latitude_reorder = Sort(),
             longitude = values(c(0, 3.6, 7.2)), 
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50',
                                     method = 'con',
                                     crop = c(0, 9, 80, 90)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

expect_equal(
as.vector(exp1),
as.vector(exp2)
)

})

#############################################################
#############################################################
#############################################################

test_that("2. no transform", {

# lat and lon are lists of indices
suppressWarnings(
exp1 <- Start(dat = path, 
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(80, 90)),
             latitude_reorder = Sort(),
             longitude = values(list(0, 9)),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

# lat and lon are vectors of indices
suppressWarnings(
exp2 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(as.vector(lats)),
             latitude_reorder = Sort(),
             longitude = values(as.vector(lons)),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

expect_equal(
as.vector(exp1),
as.vector(exp2)
)

})


#############################################################
#############################################################
#############################################################

test_that("3. transform, vector reverse", {

# lat and lon are lists of values
suppressWarnings(
exp1 <- Start(dat = path, 
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(88.2, 81)),
             latitude_reorder = Sort(),
             longitude = values(list(0, 7.2)), # It can't be reversed; different meanings
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50',
                                     method = 'con',
                                     crop = c(0, 9, 80, 90)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

#WRONG!!!!!!!!!!
# lat and lon are vectors of values
suppressWarnings(
exp2 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(rev(c(81, 84.6, 88.2))),
             latitude_reorder = Sort(),
             longitude = values(c(0, 3.6, 7.2)), # It can't be reversed; different meanings
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50',
                                     method = 'con',
                                     crop = c(0, 9, 80, 90)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

expect_equal(
as.vector(exp1),
as.vector(exp2)
)

})

################################################################
################################################################
################################################################

test_that("4. no transform, vector reverse", {

# lat and lon are lists of values
suppressWarnings(
exp1 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(list(90, 80)),
             latitude_reorder = Sort(),
             longitude = values(list(0, 9)),  # it can't be reversed; different meanings
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

# lat and lon are vectors of values
suppressWarnings(
exp2 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = values(rev(as.vector(lats))),
             latitude_reorder = Sort(),
             longitude = values(rev(as.vector(lons))),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

expect_equal(
as.vector(exp1),
as.vector(exp2)
)

})
}) #suppressMessages
