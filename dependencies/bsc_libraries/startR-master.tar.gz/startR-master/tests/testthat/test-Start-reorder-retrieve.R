suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

##############################################
test_that("original range 0to360", {
## Origin longitude in file: [0:359.722222222222]
path_exp <- '/esarchive/exp/ecmwf/system5_m1/daily_mean/$var$_f6h/$var$_$sdate$.nc'
path_exp <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_exp)

lons.min <- -2
lons.max <- 2
lats.min <- 10
lats.max <- 12

suppressWarnings(
res <- Start(dat = path_exp,
             var = 'psl',
             member = indices(1),
             sdate = '19821201',
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = T)
)
suppressWarnings(
res1 <- Start(dat = path_exp,
             var = 'psl',
             member = indices(1),
             sdate = '19821201',
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = T)
)
suppressWarnings(
res2 <- Start(dat = path_exp,
             var = 'psl',
             member = indices(1),
             sdate = '19821201',
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = T)
)
  expect_equal(
  res1[1,1,1,1,1,1:7,], 
  res[1,1,1,1,1,7:1,]
  )
  expect_equal(
  res1[1,1,1,1,1,1,8:15],
  res2[1,1,1,1,1,1,1:8]
  )
  expect_equal(
  res1[1,1,1,1,1,1,1:7],
  res2[1,1,1,1,1,1,9:15]
  )

})


##############################################
test_that("original range -180to180", {
## Origin longitude in file: [0:359.722222222222]
path_exp <- '/esarchive/recon/ecmwf/era5/original_files/reorder/daily_mean/$var$/$var$_$sdate$.nc'
path_exp <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_exp)
variable <- 'tas'
sdate <- '199212'

lons.min <- -2
lons.max <- 2
lats.min <- 10
lats.max <- 12

suppressWarnings(
res <- Start(dat = path_exp,
             var = variable,
             sdate = '199212',
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = T)
)
suppressWarnings(
res1 <- Start(dat = path_exp,
             var = variable,
             sdate = '199212',
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = T)
)
suppressWarnings(
res2 <- Start(dat = path_exp,
             var = variable,
             sdate = '199212',
             time = indices(4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = T)
)
  expect_equal(
  res1[1,1,1,1,1:7,],
  res[1,1,1,1,7:1,]
  )
  expect_equal(
  res1[1,1,1,1,1,8:15],
  res2[1,1,1,1,1,1:8]
  )
  expect_equal(
  res1[1,1,1,1,1,1:7],
  res2[1,1,1,1,1,9:15]
  )

})

}) #suppressMessages
