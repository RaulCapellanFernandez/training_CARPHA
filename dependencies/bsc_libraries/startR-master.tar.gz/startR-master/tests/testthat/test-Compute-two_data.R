suppressMessages({
test_that("ex2_7", {

# exp data
  repos <- paste0('/esarchive/exp/ecmwf/system4_m1/monthly_mean/',
                  '$var$_f6h/$var$_$sdate$.nc')
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

  sdates <- sapply(2013:2014, function(x) paste0(x, sprintf('%02d', 1:12), '01'))

suppressWarnings(
  exp <- Start(dat = repos,
                     var = 'tas',
                     sdate = sdates,
                     time = indices(1),
                     ensemble = indices(1:2),
                     latitude = values(list(10, 12)),
                     latitude_reorder = Sort(),
                     longitude = values(list(0, 2)),
                     longitude_reorder = CircularSort(0, 360),
                     synonims = list(longitude = c('lon', 'longitude'),
                                     latitude = c('lat', 'latitude')),
                     retrieve = F)
)
# obs data
  repos_obs <- paste0('/esarchive/recon/ecmwf/erainterim/monthly_mean/',
                      '$var$_f6h/$var$_$sdate$.nc')
  repos_obs <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos_obs)

  sdates_obs <- (sapply(2012:2013, function(x) paste0(x, sprintf('%02d', 1:12))))
suppressWarnings(
  obs <- Start(dat = repos_obs,
                     var = 'tas',
                     sdate = sdates_obs,
                     time = indices(1),
                     latitude = values(list(10, 12)),
                     latitude_reorder = Sort(),
                     longitude = values(list(0, 2)),
                     longitude_reorder = CircularSort(0, 360),
                     synonims = list(longitude = c('lon', 'longitude'),
                                     latitude = c('lat', 'latitude')),
                     retrieve = F)
)

  func <- function(x, y) {
    crps <- mean(SpecsVerification::EnsCrps(x, y, R.new = Inf))
    return(crps)
  }
  step <- Step(func, target_dims = list(c('sdate', 'ensemble'), c('sdate')),
                     output_dims = NULL)
  wf <- AddStep(list(exp, obs), step)
 

# Compute() on fatnodes
suppressWarnings(
  res <- Compute(wf,
                 chunks = list(latitude = 2))
)

expect_equal(
attr(exp, 'Dimensions'),
c(dat = 1, var = 1, sdate = 24, time = 1, ensemble = 2, latitude = 3, longitude = 3)
)
expect_equal(
attr(obs, 'Dimensions'),
c(dat = 1, var = 1, sdate = 24, time = 1, latitude = 3, longitude = 3)
)
expect_equal(
dim(res$output),
c(dat = 1, var = 1, time = 1, latitude = 3, longitude = 3)
)
expect_equal(
mean(res$output),
0.8646249,
tolerance = 0.0001
)
expect_equal(
res$output[1,1,1,2,1],
0.7980703,
tolerance = 0.0001
)


})
}) #suppressMessages
