suppressMessages({
test_that("1. expid/member/version", {

years  <- paste0(c(1960:1961), '01-', c(1960:1961), '12')

# from the end, each *: 1. member 2. version 3. member
repos <- paste0('/esarchive/exp/ecearth/$expid$/diags/CMIP/EC-Earth-Consortium/',
                'EC-Earth3/historical/*/Omon/$var$/gn/v*/',
                '$var$_Omon_EC-Earth3_historical_*_gn_$year$.nc')
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
suppressWarnings(
data <- Start(dat = repos,
              var = 'tosmean',
              expid =  c('a1st', 'a1sx'),
              year = years,
              time = indices(1),
              region = indices(1),
              path_glob_permissive = 6, #TRUE,
              return_vars = list(time = NULL, region = NULL),
              retrieve = T)
)

  expect_equal(
  dim(data),
  c(dat = 1, var = 1, expid = 2, year = 2, time = 1, region = 1)
  )
  expect_equal(
  dim(attr(data, 'Files')),
  c(dat = 1, var = 1, expid = 2, year = 2)
  )
  expect_equal(
  attr(data, 'Files'),
  array(c("/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1st/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r7i1p1f1/Omon/tosmean/gn/v20190302/tosmean_Omon_EC-Earth3_historical_r7i1p1f1_gn_196001-196012.nc",
           "/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1sx/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r10i1p1f1/Omon/tosmean/gn/v20190308/tosmean_Omon_EC-Earth3_historical_r10i1p1f1_gn_196001-196012.nc",
           "/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1st/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r7i1p1f1/Omon/tosmean/gn/v20190302/tosmean_Omon_EC-Earth3_historical_r7i1p1f1_gn_196101-196112.nc",
           "/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1sx/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r10i1p1f1/Omon/tosmean/gn/v20190308/tosmean_Omon_EC-Earth3_historical_r10i1p1f1_gn_196101-196112.nc"),
        dim = c(dat = 1, var = 1, expid = 2, year = 2))
  )
# NOTE: in R_3.2.0, the following test doesn't have dimension. In R_3.6.2 it does.
  expect_equal(
  data[1, 1, , , 1, 1],
  array(c(18.60422, 17.13862, 18.52348, 17.21780), dim = c(expid = 2, year = 2)), 
  tolerance = 0.0001
  )


# from the end, each *: 1. member 2. version
repos <- paste0('/esarchive/exp/ecearth/$expid$/diags/CMIP/EC-Earth-Consortium/',
                'EC-Earth3/historical/$member$/Omon/$var$/gn/v*/',
                '$var$_Omon_EC-Earth3_historical_*_gn_$year$.nc')
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
suppressWarnings(
data <- Start(dat = repos,
              var = 'tosmean',
              expid =  c('a1st', 'a1sx'),
              year = years,
              member = indices(1),
              member_depends = 'expid',
              time = indices(1),
              region = indices(1),
              path_glob_permissive = 2, #TRUE,
              return_vars = list(time = NULL, region = NULL),
              retrieve = T)
)

  expect_equal(
  dim(data),
  c(dat = 1, var = 1, expid = 2, year = 2, member = 1, time = 1, region = 1)
  )
  expect_equal(
  dim(attr(data, 'Files')),
  c(dat = 1, var = 1, expid = 2, year = 2, member = 1)
  )
  expect_equal(
  attr(data, 'Files'),
  array(c("/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1st/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r7i1p1f1/Omon/tosmean/gn/v20190302/tosmean_Omon_EC-Earth3_historical_r7i1p1f1_gn_196001-196012.nc",
           "/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1sx/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r10i1p1f1/Omon/tosmean/gn/v20190308/tosmean_Omon_EC-Earth3_historical_r10i1p1f1_gn_196001-196012.nc",
           "/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1st/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r7i1p1f1/Omon/tosmean/gn/v20190302/tosmean_Omon_EC-Earth3_historical_r7i1p1f1_gn_196101-196112.nc",
           "/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecearth/a1sx/diags/CMIP/EC-Earth-Consortium/EC-Earth3/historical/r10i1p1f1/Omon/tosmean/gn/v20190308/tosmean_Omon_EC-Earth3_historical_r10i1p1f1_gn_196101-196112.nc"),
        dim = c(dat = 1, var = 1, expid = 2, year = 2, member = 1))
  )
# NOTE: in R_3.2.0, the following test doesn't have dimension. In R_3.6.2 it does.
  expect_equal(
  data[1, 1, , , 1, 1, 1],
  array(c(18.60422, 17.13862, 18.52348, 17.21780), dim = c(expid = 2, year = 2)),
  tolerance = 0.0001
  )
  expect_equal(
  attr(data, 'FileSelectors')$dat1$member,
  list(a1st = 'r7i1p1f1', a1sx = 'r10i1p1f1')
  )

})


test_that("2. tag at the end", {
# Without the layer that path_glob_permissive allows to contain *, the last item in the path is tag. In the example below, the path without path_glob_permissive layer is 
# "/esarchive/oper/S2S4E-data/weekly_statistics/S2S/$var$/$sdate$/". The last item is "$sdate$"

#!!!!!!!!!!This data has been removed!!!!!!!!!!!!!
#sdates.seq.thu <- format(seq(as.Date(paste(2020, 06, 11, sep = '-')),                                                as.Date(paste(2020, 09, 17, sep = '-')),
#                             by = 'weeks'), format='%Y%m%d')
#path <- "/esarchive/oper/S2S4E-data/weekly_statistics/S2S/$var$/$sdate$/$var$_$sdate$_*.nc"
#suppressWarnings(
#exp <- Start(dat = path,
#             var = "tas",
#             sdate = sdates.seq.thu,   
#             time = 'all',
#             ensemble = "all",
#             latitude = indices(1:2),
#             longitude = indices(1:2),
#             path_glob_permissive = 1, 
#             retrieve = F) 
#)
#  asd <- as.list(attr(exp, 'ExpectedFiles'))
#  qwe <- sapply(sapply(asd, strsplit, '/'), '[[', 9)
#  files <- paste0('tas_', sdates.seq.thu, '_', 24:38, '.nc')
#  expect_equal(
#  qwe, files
#  )
#
#suppressWarnings(
#exp <- Start(dat = path,
#             var = "tas",
#             sdate = sdates.seq.thu,
#             time = 'all',
#             ensemble = "all",
#             latitude = indices(1:2),
#             longitude = indices(1:2),
#             path_glob_permissive = FALSE, 
#             retrieve = F)
#)
#  asd <- as.list(attr(exp, 'ExpectedFiles'))
#  qwe <- sapply(sapply(asd, strsplit, '/'), '[[', 9)
#  files <- paste0('tas_', sdates.seq.thu, '_', 24, '.nc')
#  expect_equal(
#    qwe, files
#  ) 


path <- "/esarchive/exp/ecmwf/system4_m1/6hourly/$var$/$var$_$year$0*.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)
suppressWarnings(
data <- Start(dat = path,
              var = "tas",
              year = c('1994', '1995'),
              time = indices(1:2),
              ensemble = indices(1),
              latitude = indices(1:2),
              longitude = indices(1:2),
              path_glob_permissive = 1,
              retrieve = F)
)

expect_equal(
as.list(attr(data, 'ExpectedFiles')),
list("/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecmwf/system4_m1/6hourly/tas/tas_19940501.nc",
     "/esarchive/scratch/aho/startR_unittest_files//esarchive/exp/ecmwf/system4_m1/6hourly/tas/tas_19950101.nc")
)

})

}) #suppressMessages
