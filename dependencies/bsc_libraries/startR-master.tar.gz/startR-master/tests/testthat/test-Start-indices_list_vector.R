suppressMessages({
# This unit test tests the consistence between list of indices and vector of indices.
# 1. transform
# 2. no transform
# 3. transform, indices reversed
# 4. no transform, indices reversed

repos <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc"
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)


test_that("1. transform", {

# lat and lon are lists of indices
suppressWarnings(
exp1 <- Start(dat = repos,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = indices(list(1, 30)), 
             latitude_reorder = Sort(),
             longitude = indices(list(1, 40)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50',
                                     method = 'con',
                                     crop = c(0, 11, -90, -81)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

# lat and lon are vectors of indices
suppressWarnings(
exp2 <- Start(dat = repos,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = 1:30,
             latitude_reorder = Sort(),
             longitude = 1:40,
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid = 'r100x50',
                                     method = 'con',
                                     crop = c(0, 11, -90, -81)),
             transform_vars = c('latitude', 'longitude'),
             transform_extra_cells = 8,
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

expect_equal(
as.vector(exp1),
as.vector(exp2)
)

})

#############################################################
#############################################################
#############################################################

test_that("2. no transform", {

# lat and lon are lists of indices
suppressWarnings(
exp1 <- Start(dat = repos,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = indices(list(1, 30)), 
             latitude_reorder = Sort(),
             longitude = indices(list(1, 40)),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

# lat and lon are vectors of indices
suppressWarnings(
exp2 <- Start(dat = repos,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = 1:30,
             latitude_reorder = Sort(),
             longitude = 1:40,
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

expect_equal(
as.vector(exp1),
as.vector(exp2)
)

})


#############################################################
#############################################################
#############################################################
# PROBLEM:
# latitude is -81 to -88.2 now, but it should be 81 to 88.2 because the indices is retrieved first then do the transform (aiat = F); and it should be ascending.

#  .. ..$ latitude : num [1:3(1d)] -81 -84.6 -88.2

#test_that("3. transform, indices reverse", {
#
## lat and lon are lists of indices
#suppressWarnings(
#exp1 <- Start(dat = '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc',
#             var = 'tas',
#             sdate = '20000101',
#             ensemble = indices(1),
#             time = indices(1),
#             latitude = indices(list(30, 1)), 
#             latitude_reorder = Sort(),
#             longitude = indices(list(1, 40)),  # can't reverse. Different meaning
#             longitude_reorder = CircularSort(0, 360),
#             transform = CDORemapper,
#             transform_params = list(grid = 'r100x50',
#                                     method = 'con',
#                                     crop = c(0, 11, -90, -81)),
#             transform_vars = c('latitude', 'longitude'),
#             transform_extra_cells = 8,
#             synonims = list(latitude = c('lat', 'latitude'),
#                             longitude = c('longitude', 'lon')),
#             return_vars = list(latitude = NULL,
#                                longitude = NULL,
#                                time = 'sdate'),
#             retrieve= T)
#)
#
## This test is not valid because it doesn't make sense to use longitude = 40:1. With the automatic "crop" values, the result is not correct.
### lat and lon are vectors of indices
##suppressWarnings(
##exp2 <- Start(dat = '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc',
##             var = 'tas',
##             sdate = '20000101',
##             ensemble = indices(1),
##             time = indices(1),
##             latitude = 30:1,
##             latitude_reorder = Sort(),
##             longitude = 40:1,
##             longitude_reorder = CircularSort(0, 360),
##             transform = CDORemapper,
##             transform_params = list(grid = 'r100x50',
##                                     method = 'con',
##                                     crop = c(0, 11, -90, -81)),
##             transform_vars = c('latitude', 'longitude'),
##             transform_extra_cells = 8,
##             synonims = list(latitude = c('lat', 'latitude'),
##                             longitude = c('longitude', 'lon')),
##             return_vars = list(latitude = NULL,
##                                longitude = NULL,
##                                time = 'sdate'),
##             retrieve= T)
##)
##
##expect_equal(
##as.vector(drop(exp1)[, 4:1]),
##as.vector(exp2)
##)
#
#})

################################################################
################################################################
################################################################

test_that("4. no transform, indices reverse", {

# lat and lon are lists of indices
suppressWarnings(
exp1 <- Start(dat = repos,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = indices(list(30, 1)), 
             latitude_var = 'latitude',
             latitude_reorder = Sort(),
             longitude = indices(list(1, 40)), # can't reverse. different meaning
             longitude_var = 'longitude',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

# lat and lon are vectors of indices
suppressWarnings(
exp2 <- Start(dat = repos,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = 30:1,
             latitude_var = 'latitude',
             latitude_reorder = Sort(),
             longitude = 40:1,
             longitude_var = 'longitude',
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'sdate'),
             retrieve= T)
)

expect_equal(
as.vector(drop(exp1)[, 40:1]),
as.vector(exp2)
)

})
}) #suppressMessages
