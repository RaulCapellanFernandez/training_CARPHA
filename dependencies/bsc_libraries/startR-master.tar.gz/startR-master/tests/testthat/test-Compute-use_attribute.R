suppressMessages({
test_that("ex2_2", {

  repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
  data <- Start(dat = repos,
                var = 'tas',
                sdate = c('20170101', '20180101'),
                ensemble = indices(1:2),
                time = 'all',
                latitude = indices(1:10),
                longitude = indices(1:15),
                return_vars = list(latitude = 'dat', longitude = 'dat', time = 'sdate'),
                retrieve = FALSE)
)
  funp <- function(x) {
            lat <- attributes(x)$Variables$dat1$latitude
            weight <- sqrt(cos(lat * pi / 180))
            corrected <- Apply(list(x), target_dims = "latitude",
                              fun = function(x) {x * weight})
          }
  
  
  step2 <- Step(fun = funp,
               target_dims = 'latitude',
               output_dims = 'latitude',
               use_attributes = list(data = "Variables"))
  wf2 <- AddStep(list(data = data), step2)

suppressWarnings(
  res2 <- Compute(workflow = wf2,
              chunks = list(sdate = 2))
)

expect_equal(
attr(data, 'Dimensions'),
c(dat = 1, var = 1, sdate = 2, ensemble = 2, time = 7, latitude = 10, longitude = 15)
)
expect_equal(
dim(res2$output),
c(latitude = 10, dat = 1, var = 1, sdate = 2, ensemble = 2, time = 7, longitude = 15)
)
expect_equal(
mean(res2$output),
39.84091,
tolerance = 0.0001
)
expect_equal(
res2$output[2,1,1,,1,7,2],
c(25.40159, 25.40265),
tolerance = 0.0001
)

})
}) #suppressMessages
