suppressMessages({

test_that("1. The data has units like time", {


suppressWarnings(
FD <- Start(dat = '/esarchive/scratch/aho/startR_unittest_files/esarchive/obs/ukmo/hadex3/original_files/1961-90/HadEX3_$var$_MON.nc',
            var = 'FD',  # units: days
            time = indices(1),
            longitude = indices(1), 
            latitude = indices(1),
            num_procs = 1, 
            return_vars = list(time = NULL),
            retrieve = TRUE)
)
suppressWarnings(
FD2 <- Start(dat = '/esarchive/scratch/aho/startR_unittest_files/esarchive/obs/ukmo/hadex3/original_files/1961-90/HadEX3_$var$_MON.nc',
            var = 'FD',  # units: days
            time = indices(1),
            longitude = indices(1),
            latitude = indices(1),
            num_procs = 1,
#            return_vars = list(time = NULL),
            retrieve = TRUE)
)
expect_equal(
attr(FD, 'Variables')$common$FD$units,
'days'
)
expect_equal(
attr(FD2, 'Variables')$common$FD$units,
'days'
)


})

test_that("2. The metadata variable name is not time", {
# VITIGEOOS

vari <- "rsds"
anlgs <- paste0("/esarchive/scratch/aho/startR_unittest_files/esarchive/oper/VITIGEOSS","/output/cfsv2/weekly_mean/",
                "$var$/$var$-vitigeoss-cat","_1999-2018_", "$file_date$.nc")

file_date_array <- array(dim = c(sweek = 2, sday = 3))
file_date_array[, 1] <- c(paste0('04', c('04', '07')))
file_date_array[, 2] <- c(paste0('04', c('07', '11')))
file_date_array[, 3] <- c(paste0('04', c('11', '14')))

suppressWarnings(
  hcst <- Start(dat = anlgs,
                var = vari,
                latitude = indices(1), #'all', 
                longitude= indices(1), #'all', 
                member= indices(1), #'all', 
                time = 'all',  # inner dim!!
                syear = 'all', #inner dim!!
                file_date = file_date_array,
                split_multiselected_dims = TRUE,
                retrieve = T,
                return_vars = list(leadtimes = 'file_date'),
                synonims = list(longitude = c('lon', 'longitude'),
                                latitude = c('lat', 'latitude'),
                                syear = c('sdate','syear'),
                                member = c('ensemble','member')))
)
time_attr <- attr(hcst, 'Variables')$common$leadtimes

expect_equal(
dim(time_attr),
c(sweek = 2, sday = 3, syear = 20, time = 4)
)
expect_equal(
time_attr[,1,1,1],
as.POSIXct(c("1999-04-08","1999-04-11"), tz = "UTC")
)
expect_equal(
time_attr[2,,1,1],
as.POSIXct(c("1999-04-11","1999-04-15", "1999-04-18"), tz = "UTC")
)
expect_equal(
time_attr[1,1,20,],
as.POSIXct(c("2018-04-08", "2018-04-15", "2018-04-22 UTC", "2018-04-29 UTC"), tz = "UTC")
)

})


#test_that("3. Time dimension is implicit", {
# See test-Start-implicit_inner_dim.R
#})
}) #suppressMessages
