suppressMessages({
# No transform, test reorder function Sort() and CircularSort() with selector indices().

#---------------------------------------------------------------
# cdo is used to verify the data values
library(easyNCDF)
path <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/tas_f6h/tas_20000101.nc"
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)
file <- NcOpen(path)
arr <- NcToArray(file,
                 dim_indices = list(time = 1, ensemble = 1,
                                    latitude = 1:640, longitude = 1:1296),
                 vars_to_read = 'tas')

#lat is from 90 to -90.
#lats <- NcToArray(file,
#                  dim_indices = list(latitude = 1:640), vars_to_read = 'latitude')
#lon is from 0 to 360.
#lons <- NcToArray(file,
#                  dim_indices = list(longitude = 1:1296), vars_to_read = 'longitude')
NcClose(file)
#---------------------------------------------------------------

path <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

test_that("1. lat", {
# lon_reorder = CircularSort(0, 360)

# lat should be ascending
suppressWarnings(
res1 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = indices(1:640),
             latitude_reorder = Sort(),
             longitude = indices(1:1296), 
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'sdate'),
             retrieve = T)
)

# Because Sort() is not specified, it follows the original order (descending).
suppressWarnings(
res2 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = indices(1:640),
#             latitude_reorder = Sort(),
             longitude = indices(1:1296),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = NULL, #'dat',
                                longitude = NULL, #'dat',
                                time = 'sdate'),
             retrieve = T)
)

# lat should be descending
suppressWarnings(
res3 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = indices(1:640),
             latitude_reorder = Sort(decreasing = T),
             longitude = indices(1:1296),
             longitude_reorder = CircularSort(0, 360),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'sdate'),
             retrieve = T)
)

# longitude_reorder = CircularSort(-180, 180)
suppressWarnings(
res4 <- Start(dat = path,
             var = 'tas',
             sdate = '20000101',
             ensemble = indices(1),
             time = indices(1),
             latitude = indices(1:640),
             latitude_reorder = Sort(decreasing = T),
             longitude = indices(1:1296),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('longitude', 'lon')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = 'sdate'),
             retrieve = T)
)

expect_equal(
all(diff(attr(res1, 'Variables')$dat1$latitude) > 0),
TRUE
)
expect_equal(
as.vector(drop(res1)[640:1, ]),
as.vector(arr),
tolerance = 0.0001
)
expect_equal(
all(diff(attr(res2, 'Variables')$common$latitude) < 0),
TRUE
)
expect_equal(
as.vector(res2),
as.vector(arr),
tolerance = 0.0001
)
expect_equal(
all(diff(attr(res3, 'Variables')$dat1$latitude) < 0),
TRUE
)
expect_equal(
as.vector(res3),
as.vector(arr),
tolerance = 0.0001
)

expect_equal(
range(attr(res4, 'Variables')$dat1$longitude),
c(-180, 179.7222),
tolerance = 0.0001
)
expect_equal(
as.vector(drop(res4)[, c(649:1296, 1:648)]),
as.vector(arr),
tolerance = 0.0001
)

})

}) #suppressMessages
