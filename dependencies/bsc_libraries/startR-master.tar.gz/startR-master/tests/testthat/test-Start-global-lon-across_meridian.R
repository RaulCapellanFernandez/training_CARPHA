suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

test_that("first test", {

  repos <- "/esarchive/exp/ecmwf/system5_m1/monthly_mean/tas_f6h/$var$_$sdate$.nc"
  repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)
  var <- 'tas'
  lon.min <- 0
  lon.max <- 359.723 #360
  lat.min <- -90
  lat.max <- 90

suppressWarnings(
  data <- Start(dat = repos,
                var = var,
                sdate = c('20170101'),
                ensemble = indices(1),
                time = indices(1),
                latitude = values(list(lat.min, lat.max)),
                latitude_reorder = Sort(decreasing = T),
                longitude = values(list(lon.min, lon.max)),
                longitude_reorder = CircularSort(-180, 180),
                return_vars = list(time = 'sdate',
                                   longitude = 'dat',
                                   latitude = 'dat'),
                retrieve = FALSE
               )
)
suppressWarnings(
  data2 <- Start(dat = repos,
                var = var,
                sdate = c('20170101'),
                ensemble = indices(1),
                time = indices(1),
                latitude = values(list(lat.min, lat.max)),
                latitude_reorder = Sort(decreasing = T),
                longitude = values(list(lon.min, lon.max)),
                longitude_reorder = CircularSort(0, 360),
                return_vars = list(time = 'sdate',
                                   longitude = 'dat',
                                   latitude = 'dat'),
                retrieve = FALSE
               )
)

  expect_equal(
  attr(data, 'Dimensions'),
  c(dat = 1, var = 1, sdate = 1, ensemble = 1,
                  time = 1, latitude = 640, longitude = 1296)
  )
  expect_equal(
  attr(data, 'Dimensions'),
  attr(data2, 'Dimensions')
  )

})
}) #suppressMessages
