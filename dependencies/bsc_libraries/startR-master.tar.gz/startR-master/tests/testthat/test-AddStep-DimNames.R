suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

test_that("Single File - Local execution", {
suppressWarnings( 
  data <- Start(dataset = '/esarchive/scratch/aho/startR_unittest_files/esarchive/recon/jma/jra55/monthly_mean/$var$_f6h/$var$_$sdate$$month$.nc',
                var = 'tas',
                sdate = '2000',
                month = indices(1),
                lat = values(list(0, 14)),
                lat_reorder = Sort(),
                lon = values(list(0, 28)),
                lon_reorder = CircularSort(0, 360),
                synonims = list(lat = c('lat','latitude'), 
                                lon = c('lon','longitude')),
                return_vars = list(lat = 'dataset', lon = 'dataset'),
                num_procs = 1, retrieve = FALSE)
)
  
  fun <- function(x) {
    return(x)
  }
  step <- Step(fun = fun,
               target_dims = c('member'), 
               output_dims = c('member'))
  # Checking error because of dimension name doesn't exist:
  expect_error(AddStep(inputs = data,
                       step_fun = step),
               "The target dimensions required by 'step_fun' for the input 1 are not present in the corresponding provided object in 'inputs'.")
  
})
}) #suppressMessages
