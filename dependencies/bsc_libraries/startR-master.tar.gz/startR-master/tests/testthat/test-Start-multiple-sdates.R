suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

# When certain values in one observation file are required more than once,
# and 'merge_across_dims' + 'split_multiselected_dims' are used, the values may be misplaced. 
# It might happen when reading experimental data with many start dates, 
# and the corresponding observations are required to have the same data structure.

ecmwf_path_hc <- paste0('/esarchive/exp/ecmwf/s2s-monthly_ensforhc/daily_mean/$var$_f6h/$sdate$/$var$_$syear$.nc')
ecmwf_path_hc <- paste0('/esarchive/scratch/aho/startR_unittest_files/', ecmwf_path_hc)
obs_path <-paste0('/esarchive/recon/ecmwf/era5/daily/$var$-r240x121/$var$_$file_date$.nc')
obs_path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', obs_path)

var_name <- 'tas'
var100_name <- 'windagl100'

sdates.seq <- c("20161222","20161229","20170105","20170112")

test_that("1. ", {
suppressWarnings(
hcst <- Start(dat = ecmwf_path_hc,
              var = var_name,
              sdate = sdates.seq,
              syear =  'all',
              time = 'all',            
              latitude = indices(1),
              longitude = indices(1),
              ensemble = 'all',
              syear_depends = 'sdate',
              return_vars = list(latitude = 'dat',
                                 longitude = 'dat',
                                 time = c('sdate','syear')
                                  ),
              retrieve = F)
)
dates <- attr(hcst, 'Variables')$common$time
file_date <- unique(sapply(dates, format, '%Y%m'))
suppressWarnings(
obs <- Start(dat = obs_path,
             var = var100_name,
             latitude = indices(1),
             longitude = indices(1),
             file_date= file_date,
             time = values(dates),    # 'sdate' 'syear' 'time'
             time_var = 'time',
             time_across = 'file_date',
             merge_across_dims= TRUE,
             merge_across_dims_narm = TRUE,
             split_multiselected_dims = TRUE,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',#
                                time = c('file_date')),
             retrieve = T)
)
  expect_equal(
  dim(obs),
  c(dat = 1, var = 1, latitude = 1, longitude = 1, sdate = 4, syear = 20, time = 46)
  )
  expect_equal(
  obs[1, 1, 1, 1, 1, 1, 8:15],
  c(10.727190, 21.909714, 3.220845, 7.524321, 7.308463, 2.337417, 7.127212, 3.592193),
  tolerance = 0.0001
  )
  expect_equal(
  obs[1, 1, 1, 1, 2, 1, 1:5],
  c(10.727190, 21.909714,  3.220845,  7.524321,  7.308463),
  tolerance = 0.0001
  )
  expect_equal(
  obs[1, 1, 1, 1, 2, 1, 31:38],
  c(10.680604, 4.843633, 4.981896, 4.833428, 1.426522, 3.625800, 7.037229, 2.911440),
  tolerance = 0.0001
  )
  expect_equal(
  obs[1, 1, 1, 1, 1, 2, 9:15],
  c(11.189878, 11.198478, 8.868102, 10.766751, 19.929094, 20.872601, 14.304168),
  tolerance = 0.0001
  )
  expect_equal(
  mean(obs),
  8.627518,
  tolerance = 0.0001
  )
  expect_equal(
  length(obs[which(is.na(obs))]),
  0
  )
})

test_that("2. change the file_date order", {
suppressWarnings(
hcst <- Start(dat = ecmwf_path_hc,
              var = var_name,
              sdate = sdates.seq,
              syear =  indices(1:20),
              time = 'all',
              latitude = indices(1),
              longitude = indices(1),
              ensemble = 'all',
              syear_depends = 'sdate',
              return_vars = list(latitude = 'dat',
                                 longitude = 'dat',
                                 time = c('sdate','syear')
                                  ),
              retrieve = F)
)

  dates <- attr(hcst, 'Variables')$common$time
  file_date <- sort(unique(sapply(dates, format, '%Y%m')))

suppressWarnings(
obs <- Start(dat = obs_path,
             var = var100_name,
             latitude = indices(1),
             longitude = indices(1),
             file_date= file_date,
             time = values(dates),    # 'sdate' 'syear' 'time'
             time_var = 'time',
             time_across = 'file_date',
             merge_across_dims= TRUE,
             merge_across_dims_narm = TRUE,
             split_multiselected_dims = TRUE,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',#
                                time = c('file_date')),
             retrieve = T)
)

  expect_equal(
  dim(obs),
  c(dat = 1, var = 1, latitude = 1, longitude = 1, sdate = 4, syear = 20, time = 46)
  )
  expect_equal(
  obs[1, 1, 1, 1, 1, 1, 8:15],
  c(10.727190, 21.909714, 3.220845, 7.524321, 7.308463, 2.337417, 7.127212, 3.592193),
  tolerance = 0.0001
  )
  expect_equal(
  obs[1, 1, 1, 1, 2, 1, 1:5],
  c(10.727190, 21.909714,  3.220845,  7.524321,  7.308463),
  tolerance = 0.0001
  )
  expect_equal(
  obs[1, 1, 1, 1, 2, 1, 31:38],
  c(10.680604, 4.843633, 4.981896, 4.833428, 1.426522, 3.625800, 7.037229, 2.911440),
  tolerance = 0.0001
  )
  expect_equal(
  obs[1, 1, 1, 1, 1, 2, 9:15],
  c(11.189878, 11.198478, 8.868102, 10.766751, 19.929094, 20.872601, 14.304168),
  tolerance = 0.0001
  )
  expect_equal(
  mean(obs),
  8.627518,
  tolerance = 0.0001
  )
  expect_equal(
  length(obs[which(is.na(obs))]),
  0
  )
})
}) #suppressMessages
