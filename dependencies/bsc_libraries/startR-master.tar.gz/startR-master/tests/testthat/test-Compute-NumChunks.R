suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

test_that("Single File - Local execution", {

path <- '/esarchive/recon/jma/jra55/monthly_mean/$var$_f6h/$var$_$sdate$$month$.nc'
path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path)

suppressWarnings(
data <- Start(dataset = path,
              var = 'tas',
              sdate = '2000',
              month = indices(1),
              lat = values(list(0, 14)),
              lat_reorder = Sort(),
              lon = values(list(0, 28)),
              lon_reorder = CircularSort(0, 360),
              synonims = list(lat = c('lat','latitude'), 
                              lon = c('lon','longitude')),
              return_vars = list(lat = 'dataset', lon = 'dataset'),
              num_procs = 1, 
              retrieve = FALSE)
)

fun <- function(x) {
  return(x)
}
step <- Step(fun = fun,
             target_dims = c('month'), 
             output_dims = c('month'))

wf <- AddStep(inputs = data, 
             step_fun = step)

suppressWarnings(
res1 <- Compute(workflow = wf,
                chunks = list(lat = 2, lon = 2),
                threads_load = 1,
                threads_compute = 2)
)
suppressWarnings(
res2 <- Compute(workflow = wf,
                chunks = list(lat = 3, lon = 3),
                threads_load = 1,
                threads_compute = 2)
)

expect_equal(
res1,
res2,
ignore_attr = TRUE
)

})
}) #suppressMessages
