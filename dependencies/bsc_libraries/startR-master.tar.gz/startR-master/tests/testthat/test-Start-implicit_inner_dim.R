suppressMessages({
# The unit test is for the implicit inner dimension. If the inner dimension length is 1,
# startR allows it not to be specified in the call. Users can still define it in 
# 'return_vars'.
#---------------------------------------------------------------
#NOTE: Also useful for test-Start-time_unit.R test3

test_that("1. time = 1", {

obs.path <- "/esarchive/recon/ecmwf/era5/monthly_mean/$var$_f1h-r1440x721cds/$var$_$file_date$.nc"
obs.path <- paste0('/esarchive/scratch/aho/startR_unittest_files/', obs.path)
variable <- "prlr"
dates_file <- c("201311","201312")

suppressWarnings(
obs <- Start(dat = obs.path,
             var = variable,
             file_date = dates_file,
             latitude = values(list(35.6, 40)),
             latitude_reorder = Sort(decreasing = TRUE),
             longitude = values(list(-10, 10)),
             longitude_reorder = CircularSort(-180, 180),
             synonims = list(latitude = c('lat', 'latitude'),
                             longitude = c('lon', 'longitude')), 
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = 'file_date'),
             split_multiselected_dims = TRUE,
             retrieve = FALSE)
)

expect_equal(
attr(obs, 'Dimensions'),
c(dat = 1, var = 1, file_date = 2, latitude = 18, longitude = 81)
)
expect_equal(
dim(attr(obs, 'Variables')$common$time),
c(file_date = 2, time = 1)
)
expect_equal(
attr(obs, 'Variables')$common$time[1, 1],
as.POSIXct('2013-11-15', tz = 'UTC')
)

})


}) #suppressMessages
