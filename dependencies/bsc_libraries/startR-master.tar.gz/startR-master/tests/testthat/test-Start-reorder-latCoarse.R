suppressMessages({
#if (identical(Sys.getenv("NOT_CRAN"), "")) Sys.setenv(NOT_CRAN='true')

#1 selector type	1-values(list)	2-values(vector)  3-indices     4-'all'  5-mix
#2 selector range	1-[10, 20]	2-[20, 10]	  3-[-10, -20]	4-[-20, -10]
#3 resolution		1-1	2-<1	3->1  4-> mixed	
#4 returns_var		1-NULL	2-'dat' 		
#5 lat_reorder/Sort()	1-No	2-Yes,decreasing = F	3-Yes,decreasing = T	
#6 lon_reorder/CircularSort()	1-No	2-Yes,(0, 360)	3-Yes,(-180, 180)	
#7 transform		1-NO	2-YES		
#8 transform_crop	1-T	2-F	3-region	


## mixed resolution indicates lower than 1 degree resolution for longitude and higer for latitude.
##############################################
#path_exp <- '/esarchive/exp/ecmwf/system5_m1/daily_mean/$var$_f6h/$var$_$sdate$.nc'
path_exp <- '/esarchive/exp/ncar/cesm-dple/monthly_mean/$var$/$var$_$sdate$.nc'
path_exp <- paste0('/esarchive/scratch/aho/startR_unittest_files/', path_exp)
## Origin longitude in file: [0:358.75] step 1.25 degrees #288 values
## latitude:  -90 o 90 {-90, -89.05759 ...} #192 values
##############################################
test_that("1-1-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path = path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.83770, 19.31937),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  10 
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

# lon
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(40, 45),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  5 
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )

})

##############################################
test_that("1-2-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 20
lats.max <- 10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.83770, 19.31937),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  10 
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

})

##############################################
test_that("1-3-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -10
lats.max <- -20
suppressWarnings(
res <- Start(dat = list(list(path = path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-19.31937, -10.83770),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  10 
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-4-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -20
lats.max <- -10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-19.31937, -10.83770),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  10
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})

##############################################
test_that("2-1-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20

suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(9.895288, 20.261780),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

# lon
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(40, 45),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  5 
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )

})

##############################################
test_that("2-2-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 20
lats.max <- 10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(9.895288, 20.261780),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("2-3-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -10
lats.max <- -20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-20.261780,  -9.895288),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("2-4-4-2-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- -20
lats.max <- -10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(-20.261780,  -9.895288),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-4-3-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20

suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$common$latitude)),
  c(10.83770, 19.31937),
  tolerance = 0.0001
  )
  expect_equal(
  attr(res, 'Variables')$dat1$latitude,
  NULL
  )
  expect_equal(
  (attr(res, 'Variables')$common$latitude)[1] < (attr(res, 'Variables')$common$latitude)[2],
  TRUE
  )
  expect_equal(
  class(attr(res, 'Variables')$common$latitude),
  'array'
  )
})

##############################################
test_that("2-1-4-3-1-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = NULL,
                                longitude = NULL,
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$common$latitude)),
  c(9.895288, 20.261780),
  tolerance = 0.0001
  )
  expect_equal(
  attr(res, 'Variables')$dat1$latitude,
  NULL
  )
  expect_equal(
  (attr(res, 'Variables')$common$latitude)[1] < (attr(res, 'Variables')$common$latitude)[2],
  TRUE
  )
  expect_equal(
  class(attr(res, 'Variables')$common$latitude),
  'array'
  )
})
##############################################
##############################################
test_that("1-1-4-2-2-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.83770, 19.31937),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  10
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )

# lon
  expect_equal(
  range((attr(res, 'Variables')$dat1$longitude)),
  c(40, 45),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$longitude)[1] < (attr(res, 'Variables')$dat1$longitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$longitude),
  5
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$longitude),
  'array'
  )

})
##############################################
test_that("1-2-4-2-2-1-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 20
lats.max <- 10
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.83770, 19.31937),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  10
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-4-2-2-3-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10.83770, 19.31937),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  10 
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("2-1-4-2-2-3-1-x", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(c(lats.min:lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(9.895288, 20.261780),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})


##############################################
#1 selector type        1-values(list)  2-values(vector)  3-indices     4-'all'  5-mix
#2 selector range       1-[10, 20]      2-[20, 10]        3-[-10, -20]  4-[-20, -10]
#3 resolution           1-1     2-<1    3->1   4 -> mixed4 -> mixed4 -> mixed4 -> mixed 
#4 returns_var          1-NULL  2-'dat' 
#5 lat_reorder/Sort()   1-No    2-Yes,decreasing = F    3-Yes,decreasing = T    
#6 lon_reorder/CircularSort()   1-No    2-Yes,(0, 360)  3-Yes,(-180, 180)       
#7 transform            1-NO    2-YES           
#8 transform_crop       1-T     2-F     3-region        


##############################################
test_that("1-1-4-2-1-1-2-3", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  TRUE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})

##############################################
test_that("1-1-4-2-3-1-2-3", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-4-2-3-2-2-3", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             longitude_reorder = CircularSort(0, 360),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = c(lons.min,lons.max,
                                              lats.min,lats.max)),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})
##############################################
test_that("1-1-4-2-3-1-2-1", {
lons.min <- 40
lons.max <- 45
lats.min <- 10
lats.max <- 20
suppressWarnings(
res <- Start(dat = list(list(path=path_exp)),
             var = 'psl',
             member = 'all',
             sdate = '20001101',
             time = indices(3:4),
             latitude = values(list(lats.min, lats.max)),
             latitude_reorder = Sort(decreasing = T),
             longitude = values(list(lons.min, lons.max)),
             transform = CDORemapper,
             transform_params = list(grid ='r360x181',
                                     method = 'con',
                                     crop = T),
             transform_vars = c('longitude', 'latitude'),
             transform_extra_cells = 2,
             synonims = list(latitude=c('lat','latitude'),
                             longitude=c('lon','longitude'),
                             member=c('ensemble','realization')),
             return_vars = list(latitude = 'dat',
                                longitude = 'dat',
                                time = NULL),
             retrieve = F)
)
# lat
  expect_equal(
  range((attr(res, 'Variables')$dat1$latitude)),
  c(10, 20),
  tolerance = 0.0001
  )
  expect_equal(
  (attr(res, 'Variables')$dat1$latitude)[1] < (attr(res, 'Variables')$dat1$latitude)[2],
  FALSE
  )
  expect_equal(
  length(attr(res, 'Variables')$dat1$latitude),
  11
  )
  expect_equal(
  class(attr(res, 'Variables')$dat1$latitude),
  'array'
  )
})

##############################################
#test_that("1-3. Selector type: indices(list)", {
#
#})
##############################################
#test_that("1-4. Selector type: indices(vector)", {
#
#})
##############################################
#test_that("1-4. Selector type: indices(vector)", {
#
#})

}) #suppressMessages
