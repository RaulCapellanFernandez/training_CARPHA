suppressMessages({
# When inner dimension selector is an array with filedim dimension name (e.g., time = [sdate = 2, time = 4], 
# or *_across is used, the inner dim has dependency on file dim. In this case, return_vars must 
# specify this relationship, i.e., return_vars = list(time = 'sdate').


# Preparation: Get the time values
repos <- '/esarchive/exp/ecmwf/system5_m1/monthly_mean/$var$_f6h/$var$_$sdate$.nc'
repos <- paste0('/esarchive/scratch/aho/startR_unittest_files/', repos)

suppressWarnings(
data <- Start(dat = repos,
              var = 'tas',
              sdate = c('20170101', '20180101'),
              ensemble = indices(1),
              time = indices(1:4),
              latitude = indices(1), longitude = indices(1),
              return_vars = list(time = 'sdate'),
              silent = TRUE,
              retrieve = FALSE)
)
time_val <- attr(data, 'Variables')$common$time
time_val_vector <- time_val[c(1, 3, 5, 7, 2, 4, 6, 8)]

#---------------------------------------------------------------

test_that("1. Selector is values()", {

#================== values() with dimensions ===================
  suppressWarnings(
    test4 <- Start(
      dat = repos,
      var = 'tas',
      sdate = c('20170101', '20180101'),
      time = time_val,
    #  time_across = 'sdate',
      ensemble = c(1, 3),
      latitude = indices(1:3),
      longitude = indices(1:2),
      return_vars = list(time = 'sdate'),
      retrieve = TRUE)
  )
  time4 <- attr(test4, 'Variables')$common$time

expect_equal(
  dim(time4),
  c(sdate = 2, time = 4)
)
expect_equal(
  time4[2, 2],
  as.POSIXct("2018-03-01", tz = 'UTC')
)

#----------------------------------------

  suppressWarnings(
    test6 <- Start(
      dat = repos,
      var = 'tas',
      sdate = c('20170101', '20180101'),
      time = time_val,
    #  time_across = 'sdate',
      ensemble = c(1, 3),
      latitude = indices(1:3),
      longitude = indices(1:2),
      return_vars = list(time = NULL),
      retrieve = TRUE)
  )
  time6 <- attr(test6, 'Variables')$common$time

expect_equal(
  dim(time6),
  c(sdate = 2, time = 4)
)
expect_equal(
  time6,
  time4
)
expect_equal(
  as.vector(test6),
  as.vector(test4)
)

expect_equal(
  test6,
  test4,
  ignore_attr = TRUE
)

#----------------------------------------

  suppressWarnings(
    test6a <- Start(
      dat = repos,
      var = 'tas',
      sdate = c('20170101', '20180101'),
      time = time_val,
      time_across = 'sdate',
      ensemble = c(1, 3),
      latitude = indices(1:3),
      longitude = indices(1:2),
      return_vars = list(time = NULL),
      retrieve = TRUE)
  )
  time6a <- attr(test6a, 'Variables')$common$time

expect_equal(
  dim(time6a),
  c(sdate = 2, time = 4)
)
expect_equal(
  time6,
  time6a
)
expect_equal(
  as.vector(test6),
  as.vector(test4)
)

expect_equal(
  test6,
  test6a,
  ignore_attr = TRUE
)

#----------------------------------------

#================== values() is vector ===================

  suppressWarnings(
    test14a <- Start(
      dat = repos,
      var = 'tas',
      sdate = c('20170101', '20180101'),
      time = time_val_vector,
      time_across = 'sdate',
      ensemble = c(1, 3),
      latitude = indices(1:3),
      longitude = indices(1:2),
      return_vars = list(time = NULL),
      retrieve = TRUE)
  )
  time14a <- attr(test14a, 'Variables')$common$time

expect_equal(
  dim(time14a),
  c(sdate = 2, time = 4)
)
expect_equal(
  time14a,
  time6a
)
expect_equal(
  as.vector(test14a),
  as.vector(test4)
)

expect_equal(
  test14a,
  test6a,
  ignore_attr = TRUE
)

#-------------------------------------------------

  suppressWarnings(
    test15a <- Start(
      dat = repos,
      var = 'tas',
      sdate = c('20170101', '20180101'),
      time = time_val_vector,
      time_across = 'sdate',
      ensemble = c(1, 3),
      latitude = indices(1:3),
      longitude = indices(1:2),
      return_vars = list(time = 'sdate'),
      retrieve = TRUE)
  )
  time15a <- attr(test15a, 'Variables')$common$time

expect_equal(
  dim(time15a),
  c(sdate = 2, time = 4)
)
expect_equal(
  time15a,
  time6a
)
expect_equal(
  as.vector(test15a),
  as.vector(test4)
)

expect_equal(
  test15a,
  test6a,
  ignore_attr = TRUE
)

})
}) #suppressMessages
