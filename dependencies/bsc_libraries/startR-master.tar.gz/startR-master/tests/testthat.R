library(testthat)
library(startR)
library(SpecsVerification)
library(plyr)
library(dplyr)
library(easyNCDF)
library(s2dv)

test_check("startR")

