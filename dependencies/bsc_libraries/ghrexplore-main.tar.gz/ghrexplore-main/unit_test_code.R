
test_file("tests/testthat/test-plot_map.R", reporter = "summary")

file_coverage("R/plot_map.R", "tests/testthat/test-plot_map.R")

